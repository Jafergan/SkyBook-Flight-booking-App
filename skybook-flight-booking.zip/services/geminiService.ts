import { GoogleGenAI, Type } from "@google/genai";

/**
 * Interface for chat message part.
 */
interface MessagePart {
  text: string;
}

/**
 * Interface for chat history entry.
 */
interface HistoryEntry {
  role: 'user' | 'model';
  parts: MessagePart[];
}

/**
 * Sends a message to the Gemini model and returns the response text.
 */
export const chatWithAssistant = async (message: string, history: HistoryEntry[]) => {
  try {
    // Initialize right before call to ensure up-to-date API key usage
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: [
        ...history,
        { role: 'user', parts: [{ text: message }] }
      ],
      config: {
        systemInstruction: `You are SkyBook Intelligence (Agent v5.0), an elite AI travel strategist.
        Your capabilities exceed standard bots; you provide deep insights into travel planning.`,
        temperature: 0.8,
      },
    });

    return response.text;
  } catch (error) {
    console.error("SkyBook AI Error:", error);
    return "I'm currently recalibrating my flight data engines. Please try again in a moment.";
  }
};

/**
 * Generates perfect flight results based on user search parameters.
 */
export const searchFlightsWithAI = async (origin: string, destination: string, date: string, passengers: string) => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Search flights from ${origin} to ${destination} on ${date} for ${passengers}.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              airline: { type: Type.STRING },
              airlineLogo: { type: Type.STRING, description: "Use a valid logo URL for the airline" },
              flightNumber: { type: Type.STRING },
              aircraft: { type: Type.STRING },
              departure: { type: Type.STRING, description: "3-letter IATA code" },
              departureAirport: { type: Type.STRING },
              arrival: { type: Type.STRING, description: "3-letter IATA code" },
              arrivalAirport: { type: Type.STRING },
              departureTime: { type: Type.STRING, description: "HH:MM format" },
              arrivalTime: { type: Type.STRING, description: "HH:MM format" },
              duration: { type: Type.STRING, description: "e.g. 5h 30m" },
              price: { type: Type.NUMBER },
              netPrice: { type: Type.NUMBER },
              stops: { type: Type.NUMBER },
              stopLocation: { type: Type.STRING },
              type: { type: Type.STRING, enum: ["DOMESTIC", "INTERNATIONAL"] },
              baggage: { type: Type.STRING },
              cabin: { type: Type.STRING },
              meal: { type: Type.BOOLEAN },
              refundable: { type: Type.STRING, enum: ["Refundable", "Non-Refundable", "Partially Refundable"] },
              class: { type: Type.STRING, enum: ["Economy", "Premium Economy", "Business", "First"] }
            },
            propertyOrdering: ["id", "airline", "flightNumber", "departure", "arrival", "departureTime", "arrivalTime", "price", "class"]
          }
        },
        systemInstruction: "You are the SkyBook v5.0 GDS Simulator. Generate realistic flight options. Price range: $200-$1500 depending on distance."
      }
    });

    const results = JSON.parse(response.text || '[]');
    return results.map((f: any) => ({
      ...f,
      airlineLogo: f.airlineLogo || `https://ui-avatars.com/api/?name=${f.airline}&background=random&color=fff`
    }));
  } catch (error) {
    console.error("Flight AI Synthesis Error:", error);
    throw error;
  }
};

/**
 * Fetches structured travel intelligence for a specific location.
 */
export const getTravelIntelligence = async (location: string) => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Provide travel intelligence for ${location}.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            locationName: { type: Type.STRING },
            weather: {
              type: Type.OBJECT,
              properties: {
                temp: { type: Type.STRING },
                condition: { type: Type.STRING },
                icon: { type: Type.STRING, description: "FontAwesome icon name" }
              },
            },
            advisories: {
              type: Type.OBJECT,
              properties: {
                safetyLevel: { type: Type.STRING },
                alertText: { type: Type.STRING }
              },
            },
            essentials: {
              type: Type.OBJECT,
              properties: {
                currency: { type: Type.STRING },
                timezone: { type: Type.STRING },
                visa: { type: Type.STRING },
                language: { type: Type.STRING }
              },
            },
            insights: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          },
          propertyOrdering: ["locationName", "weather", "advisories", "essentials", "insights"]
        },
        systemInstruction: "You are the SkyBook v5.0 Travel Intelligence Engine. Provide realistic insights."
      }
    });

    return JSON.parse(response.text || '{}');
  } catch (error) {
    console.error("Intelligence Retrieval Error:", error);
    throw error;
  }
};

/**
 * Fetches AI-driven support resolutions for the Help Center.
 */
export const getSupportResolution = async (query: string) => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Query: ${query}`,
      config: {
        systemInstruction: "You are the SkyBook Executive Support Concierge. Provide a concise, professional answer."
      }
    });
    return response.text;
  } catch (error) {
    console.error("Support Resolution AI Error:", error);
    return "Our support link is temporarily congested. Please check the documentation.";
  }
};