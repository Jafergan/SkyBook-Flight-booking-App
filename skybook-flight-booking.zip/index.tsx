import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

/**
 * Main Entry Point for SkyBook Terminal v5.0
 * Initializes the React application root and mounts the core App shell.
 */
const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Target container 'root' not found in the DOM.");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);