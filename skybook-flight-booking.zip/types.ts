export enum UserRole {
  ADMIN = 'ADMIN',
  AGENT = 'AGENT',
  USER = 'USER'
}

export enum LeadStatus {
  NEW = 'NEW',
  FOLLOW_UP = 'FOLLOW_UP',
  QUOTED = 'QUOTED',
  BOOKED = 'BOOKED',
  CANCELLED = 'CANCELLED',
  CONVERTED = 'CONVERTED',
  LOST = 'LOST'
}

export enum BookingStatus {
  CONFIRMED = 'CONFIRMED',
  CANCELLED = 'CANCELLED',
  RESCHEDULED = 'RESCHEDULED',
  PENDING = 'PENDING'
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar: string;
  status: 'Active' | 'Inactive' | 'Suspended';
  lastActive?: string;
}

export interface Notification {
  id: string;
  type: 'Flight Update' | 'Lead' | 'System';
  title: string;
  description: string;
  timestamp: string;
  isRead: boolean;
  priority?: 'High' | 'Normal';
}

export interface LeadActivity {
  id: string;
  type: 'note' | 'status_change' | 'call' | 'created';
  content: string;
  timestamp: string;
  metadata?: any;
}

export interface Lead {
  id: string;
  customerName: string;
  email: string;
  phone: string;
  origin: string;
  destination: string;
  route: string;
  date: string;
  budget: number;
  status: LeadStatus;
  tripType: 'International' | 'Domestic';
  passengers: {
    adults: number;
    children: number;
  };
  assignedTo?: string; // User ID
  notes: string[];
  activities: LeadActivity[];
  createdAt: string;
}

export interface Flight {
  id: string;
  airline: string;
  airlineLogo: string;
  flightNumber: string;
  aircraft: string;
  departure: string;
  departureAirport: string;
  arrival: string;
  arrivalAirport: string;
  departureTime: string;
  arrivalTime: string;
  duration: string;
  price: number;
  netPrice: number;
  stops: number;
  stopLocation?: string;
  type: 'DOMESTIC' | 'INTERNATIONAL';
  baggage: string;
  cabin: string;
  meal: boolean;
  refundable: 'Refundable' | 'Non-Refundable' | 'Partially Refundable';
  class: 'Economy' | 'Premium Economy' | 'Business' | 'First';
}

export interface Booking {
  id: string;
  leadId: string;
  pnr: string;
  flightId: string;
  status: BookingStatus;
  totalFare: number;
  baseFare: number;
  taxes: number;
  serviceFee: number;
  paymentStatus: 'PAID' | 'UNPAID' | 'PARTIAL';
  createdAt: string;
}

export interface Offer {
  id: string;
  code: string;
  description: string;
  discount: number;
  type: 'PERCENT' | 'FLAT';
  expiryDate: string;
}