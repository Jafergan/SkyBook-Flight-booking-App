import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Chatbot from './components/Chatbot';
import Dashboard from './pages/Dashboard';
import FlightSearch from './pages/FlightSearch';
import LandingPage from './pages/LandingPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import VerificationPage from './pages/VerificationPage';
import ProfileSetupPage from './pages/ProfileSetupPage';
import TravelPreferencesPage from './pages/TravelPreferencesPage';
import OnboardingPage from './pages/OnboardingPage';
import LeadListPage from './pages/LeadListPage';
import LeadDetailsPage from './pages/LeadDetailsPage';
import ProfilePage from './pages/ProfilePage';
import PassengerDetailsPage from './pages/PassengerDetailsPage';
import BookingSummaryPage from './pages/BookingSummaryPage';
import MapSearchPage from './pages/MapSearchPage';
import PaymentPage from './pages/PaymentPage';
import BookingConfirmationPage from './pages/BookingConfirmationPage';
import BookingManagementPage from './pages/BookingManagementPage';
import OffersPage from './pages/OffersPage';
import TravelInfoPage from './pages/TravelInfoPage';
import ReportsPage from './pages/ReportsPage';
import NotificationsPage from './pages/NotificationsPage';
import AdminUserManagementPage from './pages/AdminUserManagementPage';
import AdminSettingsPage from './pages/AdminSettingsPage';
import SupportPage from './pages/SupportPage';
import LegalPage from './pages/LegalPage';
import NotFoundPage from './pages/NotFoundPage';
import MaintenancePage from './pages/MaintenancePage';
import MaintenanceStatusPage from './pages/MaintenanceStatusPage';
import ComingSoonPage from './pages/ComingSoonPage';
import WhySkyBookPage from './pages/WhySkyBookPage';
import ScheduleDemoPage from './pages/ScheduleDemoPage';
import NetworkStatusPage from './pages/NetworkStatusPage';
import RecoveryPage from './pages/RecoveryPage';
import { UserRole, Lead, Booking, User, Flight, BookingStatus } from './types';
import { MOCK_LEADS, MOCK_BOOKINGS, MOCK_USERS, MOCK_FLIGHTS } from './constants';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState('landing');
  const [legalSubTab, setLegalSubTab] = useState<any>('Privacy Policy');
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [selectedLeadId, setSelectedLeadId] = useState<string | null>(null);
  const [selectedFlight, setSelectedFlight] = useState<Flight | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  
  const [regEmail, setRegEmail] = useState('');
  const [regRole, setRegRole] = useState<'user' | 'agency'>('user');
  const [tempProfile, setTempProfile] = useState<any>(null);

  const [isMaintenanceMode, setIsMaintenanceMode] = useState(false);
  const [leads, setLeads] = useState<Lead[]>(MOCK_LEADS);
  const [bookings, setBookings] = useState<Booking[]>(MOCK_BOOKINGS);

  const addLead = (newLead: Lead) => setLeads(prev => [newLead, ...prev]);
  const addBooking = (newBooking: Booking) => setBookings(prev => [newBooking, ...prev]);

  const handleLoginSuccess = (role: UserRole) => {
    const user = MOCK_USERS.find(u => u.role === role) || MOCK_USERS[0];
    setCurrentUser({ ...user, status: 'Active' });
    setActiveTab('dashboard');
  };

  /**
   * Finalized Session Purge
   * Destroys current user context and forces UI back to Landing state.
   */
  const handleLogout = () => {
    // 1. Clear session 
    setCurrentUser(null);
    
    // 2. Clear stateful identifiers
    setSelectedLeadId(null);
    setSelectedFlight(null);
    setRegEmail('');
    setRegRole('user');
    setTempProfile(null);
    
    // 3. Force redirection
    setActiveTab('landing');
    setIsSidebarOpen(false);
    
    // 4. Reset viewport
    window.scrollTo({ top: 0, behavior: 'instant' });
  };
  
  const goHome = () => setActiveTab('landing');
  const goDashboard = () => setActiveTab('dashboard');

  const finalizeRegistration = () => {
    const newUser: User = {
      id: `U-${Date.now()}`,
      name: tempProfile?.name || 'New Traveler',
      email: regEmail,
      role: regRole === 'agency' ? UserRole.AGENT : UserRole.USER,
      avatar: tempProfile?.avatar || 'https://i.pravatar.cc/150?u=newuser',
      status: 'Active'
    };
    setCurrentUser(newUser);
    setActiveTab('dashboard');
  };

  const isEffectiveMaintenance = isMaintenanceMode && 
                               currentUser?.role !== UserRole.ADMIN && 
                               !['landing', 'maintenance-status', 'login', 'recovery'].includes(activeTab);

  const renderContent = () => {
    if (isEffectiveMaintenance) {
      return (
        <MaintenancePage 
          onBack={handleLogout} 
          onViewStatus={() => setActiveTab('maintenance-status')}
          onContactSupport={() => setActiveTab('help-support')}
          onAdminLogin={() => setActiveTab('login')}
          onPrivacyPolicy={() => { setActiveTab('legal'); setLegalSubTab('Privacy Policy'); }}
          onTermsOfService={() => { setActiveTab('legal'); setLegalSubTab('Terms of Service'); }}
          onHelpCenter={() => setActiveTab('help-support')}
        />
      );
    }

    switch (activeTab) {
      case 'landing': return <LandingPage currentUser={currentUser} onLogout={handleLogout} onGoDashboard={goDashboard} onGetStarted={() => setActiveTab('register')} onLogin={() => setActiveTab('login')} onOffers={() => { const element = document.getElementById('offers'); element?.scrollIntoView({ behavior: 'smooth' }); }} onWhySkyBook={() => setActiveTab('why-skybook')} onNetworkStatus={() => setActiveTab('network-status')} onLegal={(tab) => { setLegalSubTab(tab); setActiveTab('public-legal'); }} />;
      case 'why-skybook': return <WhySkyBookPage onBack={goHome} onJoin={() => setActiveTab('register')} onScheduleDemo={() => setActiveTab('schedule-demo')} />;
      case 'network-status': return <NetworkStatusPage onBack={goHome} />;
      case 'maintenance-status': return <MaintenanceStatusPage onBack={() => setActiveTab(isMaintenanceMode ? 'maintenance' : 'dashboard')} />;
      case 'schedule-demo': return <ScheduleDemoPage onBack={() => setActiveTab('why-skybook')} onComplete={goHome} />;
      case 'login': return <LoginPage onLogin={handleLoginSuccess} onJoinUs={() => setActiveTab('register')} onBack={goHome} onRecovery={() => setActiveTab('recovery')} />;
      case 'recovery': return <RecoveryPage onBack={() => setActiveTab('login')} onComplete={() => setActiveTab('login')} />;
      case 'register': return <RegisterPage onRegister={(role) => { setRegRole(role); setActiveTab('reg-verify'); }} onLogin={() => setActiveTab('login')} onBack={goHome} onLegal={(tab) => { setLegalSubTab(tab); setActiveTab('public-legal'); }} onEmailChange={setRegEmail} />;
      case 'reg-verify': return <VerificationPage email={regEmail} onVerify={() => setActiveTab('reg-profile')} onBack={() => setActiveTab('register')} />;
      case 'reg-profile': return <ProfileSetupPage onContinue={(data) => { setTempProfile(data); setActiveTab('reg-prefs'); }} />;
      case 'reg-prefs': return <TravelPreferencesPage onComplete={finalizeRegistration} />;
      case 'onboarding': return <OnboardingPage onComplete={goHome} />;
      case 'dashboard': return <Dashboard role={currentUser?.role || UserRole.USER} setActiveTab={setActiveTab} onSelectLead={(id) => { setSelectedLeadId(id); setActiveTab('lead-details'); }} leads={leads} onAddLead={addLead} bookings={bookings} onAddBooking={addBooking} />;
      case 'leads': return <LeadListPage currentRole={currentUser?.role || UserRole.USER} leads={leads} onAddLead={addLead} onSelectLead={(id) => { setSelectedLeadId(id); setActiveTab('lead-details'); }} onBack={goDashboard} />;
      case 'lead-details': return <LeadDetailsPage leadId={selectedLeadId || 'L3'} leads={leads} onBack={() => setActiveTab('leads')} onSearchFlights={() => setActiveTab('flights')} />;
      case 'flights': return <FlightSearch onSelectFlight={(f) => { setSelectedFlight(f); setActiveTab('passenger-details'); }} onBack={goDashboard} />;
      case 'passenger-details': return <PassengerDetailsPage flight={selectedFlight || MOCK_FLIGHTS[0]} onContinue={(data) => setActiveTab('booking-summary')} onBack={() => setActiveTab('flights')} />;
      case 'booking-summary': return <BookingSummaryPage flight={selectedFlight || MOCK_FLIGHTS[0]} onConfirm={() => setActiveTab('payment')} onBack={() => setActiveTab('passenger-details')} />;
      case 'payment': return <PaymentPage flight={selectedFlight || MOCK_FLIGHTS[0]} onPaymentSuccess={() => { const newBooking: Booking = { id: `B${Date.now()}`, leadId: selectedLeadId || 'DIRECT', pnr: Math.random().toString(36).substring(2, 8).toUpperCase(), flightId: selectedFlight?.id || 'F1', status: BookingStatus.CONFIRMED, totalFare: (selectedFlight?.price || 0) + 200, baseFare: selectedFlight?.price || 0, taxes: 185, serviceFee: 15, paymentStatus: 'PAID', createdAt: new Date().toISOString() }; addBooking(newBooking); setActiveTab('confirmation'); }} onCancel={() => setActiveTab('booking-summary')} />;
      case 'confirmation': return <BookingConfirmationPage flight={selectedFlight || MOCK_FLIGHTS[0]} onDone={() => setActiveTab('manage-bookings')} />;
      case 'manage-bookings': return <BookingManagementPage onBack={goDashboard} />;
      case 'offers': return <OffersPage onBack={goDashboard} />;
      case 'travel-info': return <TravelInfoPage onBack={goDashboard} />;
      case 'reports': return <ReportsPage onBack={goDashboard} />;
      case 'notifications': return <NotificationsPage onBack={goDashboard} />;
      case 'admin-users': return <AdminUserManagementPage onBack={goDashboard} />;
      case 'admin-settings': return <AdminSettingsPage onBack={goDashboard} maintenanceMode={isMaintenanceMode} onToggleMaintenance={() => setIsMaintenanceMode(!isMaintenanceMode)} />;
      case 'help-support': return <SupportPage onBack={goDashboard} />;
      case 'legal': return <LegalPage onBack={goDashboard} initialTab={legalSubTab} />;
      case 'public-legal': return <LegalPage onBack={goHome} initialTab={legalSubTab} isPublic={true} />;
      case 'maintenance': return <MaintenancePage onBack={goDashboard} onAdminLogin={() => setActiveTab('login')} onViewStatus={() => setActiveTab('maintenance-status')} onContactSupport={() => setActiveTab('help-support')} onPrivacyPolicy={() => { setActiveTab('legal'); setLegalSubTab('Privacy Policy'); }} onTermsOfService={() => { setActiveTab('legal'); setLegalSubTab('Terms of Service'); }} onHelpCenter={() => setActiveTab('help-support')} />;
      case 'coming-soon': return <ComingSoonPage onBack={goDashboard} />;
      case 'profile': return currentUser ? <ProfilePage user={currentUser} onUpdate={(u) => setCurrentUser(u)} onLogout={handleLogout} onBack={goDashboard} /> : <NotFoundPage onReturn={goHome} />;
      default: return <NotFoundPage onReturn={goHome} />;
    }
  };

  const isIsolatedPage = ['landing', 'why-skybook', 'network-status', 'maintenance-status', 'schedule-demo', 'login', 'register', 'reg-verify', 'reg-profile', 'reg-prefs', 'onboarding', 'maintenance', 'coming-soon', 'not-found', 'public-legal', 'recovery'].includes(activeTab);

  const shouldShowAppShell = !isIsolatedPage && currentUser && !isEffectiveMaintenance;
  const shouldShowChatbot = !['login', 'register', 'reg-verify', 'reg-profile', 'reg-prefs', 'onboarding', 'recovery'].includes(activeTab) && !isEffectiveMaintenance;

  return (
    <div className="flex h-screen bg-slate-50 font-sans relative overflow-hidden">
      {shouldShowAppShell && currentUser && (
        <Sidebar 
          activeTab={activeTab} 
          setActiveTab={(tab) => { setActiveTab(tab); setIsSidebarOpen(false); }} 
          currentRole={currentUser.role} 
          isOpen={isSidebarOpen}
          onLogout={handleLogout}
        />
      )}
      
      <main className="flex-1 min-w-0 flex flex-col h-screen overflow-hidden">
        {shouldShowAppShell && currentUser && (
          <header className="h-16 bg-white/80 backdrop-blur-md border-b border-slate-100 shrink-0 px-4 md:px-8 lg:px-10 flex items-center justify-between shadow-sm z-40">
            <div className="flex items-center gap-3 md:gap-4">
               <button 
                onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                className="lg:hidden w-10 h-10 flex items-center justify-center text-slate-500 hover:bg-slate-50 rounded-xl transition-colors"
               >
                 <i className={`fas ${isSidebarOpen ? 'fa-times' : 'fa-bars'}`}></i>
               </button>
               <div className={`hidden sm:flex items-center gap-3 font-black uppercase tracking-widest text-[9px] md:text-[10px] px-3 md:px-4 py-1.5 md:py-2 rounded-xl ${isMaintenanceMode ? 'bg-orange-50 text-orange-600 border border-orange-100' : 'bg-blue-50 text-blue-600 border border-blue-50'}`}>
                  <i className={`fas ${isMaintenanceMode ? 'fa-tools' : 'fa-shield-halved'} animate-pulse`}></i>
                  <span className="hidden md:inline">{isMaintenanceMode ? 'Maintenance Active' : 'Terminal v5.0 Secured'}</span>
                  <span className="md:hidden">v5.0</span>
               </div>
            </div>

            <div className="flex items-center gap-2 md:gap-5">
              <div className="flex items-center gap-1 md:gap-2 pr-2 md:pr-4 border-r border-slate-100">
                <button 
                  onClick={() => setActiveTab('maintenance')}
                  className={`w-8 h-8 md:w-10 md:h-10 flex items-center justify-center transition-all rounded-xl ${isMaintenanceMode ? 'bg-orange-500 text-white' : 'text-slate-300 hover:text-orange-500 hover:bg-orange-50'}`}
                >
                  <i className="fas fa-tools text-xs"></i>
                </button>
                <button 
                  onClick={() => setActiveTab('notifications')}
                  className="w-8 h-8 md:h-10 flex items-center justify-center relative text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all"
                >
                  <i className="fas fa-bell text-xs"></i>
                  <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
                </button>
              </div>
              
              <button 
                onClick={() => setActiveTab('profile')} 
                className={`flex items-center gap-2 md:gap-3 cursor-pointer group px-1 md:px-4 py-1.5 rounded-2xl transition-all border ${activeTab === 'profile' ? 'bg-blue-50 border-blue-100' : 'bg-white border-transparent hover:bg-slate-50'}`}
              >
                <div className="text-right hidden sm:block">
                  <p className="text-xs md:text-sm font-black text-slate-800 leading-tight">{currentUser.name.split(' ')[0]}</p>
                  <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mt-0.5">
                    {currentUser.role}
                  </p>
                </div>
                <div className="relative">
                  <img 
                    src={currentUser.avatar} 
                    alt="Avatar" 
                    className={`w-8 h-8 md:w-11 md:h-11 rounded-xl object-cover border shadow-sm ${activeTab === 'profile' ? 'border-blue-500' : 'border-white'}`} 
                  />
                  <div className="absolute -bottom-1 -right-1 w-2.5 h-2.5 bg-emerald-500 border-2 border-white rounded-full"></div>
                </div>
              </button>
            </div>
          </header>
        )}

        <div key={activeTab + (isEffectiveMaintenance ? '-maintenance' : '')} className="relative flex-1 overflow-y-auto scrollbar-hide">
          {renderContent()}
        </div>
      </main>

      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 lg:hidden animate-fadeIn" 
          onClick={() => setIsSidebarOpen(false)}
        ></div>
      )}

      {shouldShowChatbot && <Chatbot />}
    </div>
  );
};

export default App;