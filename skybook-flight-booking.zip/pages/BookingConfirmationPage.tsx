import React from 'react';
import { Flight } from '../types';

interface BookingConfirmationPageProps {
  flight: Flight;
  onDone: () => void;
}

const BookingConfirmationPage: React.FC<BookingConfirmationPageProps> = ({ flight, onDone }) => {
  return (
    <div className="p-4 md:p-8 max-w-5xl mx-auto space-y-6 md:space-y-8 animate-fadeIn">
       <nav className="flex items-center gap-3 text-xs font-black uppercase tracking-widest text-slate-400">
        <span>Dashboard</span>
        <i className="fas fa-chevron-right text-[8px]"></i>
        <span>Leads</span>
        <i className="fas fa-chevron-right text-[8px]"></i>
        <span className="text-blue-600">Confirmation</span>
      </nav>

      <div className="bg-white rounded-[2rem] md:rounded-[3rem] border border-slate-100 shadow-2xl shadow-blue-500/5 overflow-hidden border-t-4 border-t-blue-600">
        <div className="p-8 md:p-16 text-center space-y-6">
           <div className="w-16 h-16 md:w-24 md:h-24 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center text-2xl md:text-4xl mx-auto shadow-inner relative">
              <i className="fas fa-check"></i>
              <div className="absolute -inset-2 rounded-full border-2 border-dashed border-blue-200 animate-spin-slow"></div>
           </div>
           <div className="space-y-3">
             <h2 className="text-3xl md:text-5xl font-black text-slate-900 tracking-tight">Booking Confirmed</h2>
             <p className="text-slate-500 font-medium text-sm md:text-lg max-w-2xl mx-auto leading-relaxed">
                Great job! Your booking to {flight.arrivalAirport.split(' - ')[0]} has been successfully confirmed. A confirmation email has been queued for the client.
             </p>
           </div>

           <div className="flex flex-col md:flex-row gap-4 md:gap-6 justify-center pt-4 md:pt-8">
              <div className="bg-blue-50/50 p-6 md:p-8 rounded-[1.5rem] md:rounded-[2rem] border border-blue-100 flex-1">
                 <p className="text-[10px] font-black text-blue-400 uppercase tracking-[0.2em] mb-2">PNR Reference</p>
                 <p className="text-2xl md:text-4xl font-black text-blue-600 tracking-tight uppercase">AX9KQ2</p>
              </div>
              <div className="bg-slate-50/50 p-6 md:p-8 rounded-[1.5rem] md:rounded-[2rem] border border-slate-100 flex-1">
                 <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2">Ticket Number</p>
                 <p className="text-2xl md:text-3xl font-black text-slate-900 tracking-tight">ETK-789456</p>
              </div>
           </div>
        </div>

        <div className="p-6 md:p-12 bg-slate-50/50 border-t border-slate-100">
           <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-6 md:mb-8">Flight Summary</h3>
           <div className="bg-white p-6 md:p-8 rounded-[1.5rem] md:rounded-[2rem] border border-slate-100 shadow-sm flex flex-col gap-6 md:gap-10 relative">
              <div className="md:absolute top-6 right-8 bg-emerald-50 text-emerald-600 px-3 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest border border-emerald-100 w-fit">
                 Confirmed
              </div>
              
              <div className="flex-1 space-y-6">
                 <div className="flex items-center gap-3 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                    <i className="far fa-calendar-alt"></i>
                    <span>Mon, 12 Aug 2024</span>
                 </div>
                 <div className="flex flex-col lg:flex-row lg:items-center gap-8 lg:gap-12">
                   <div className="flex items-center gap-4 md:gap-6 shrink-0">
                      <div>
                        <p className="font-black text-slate-900 text-sm md:text-base">{flight.airline}</p>
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{flight.flightNumber} • {flight.class}</p>
                      </div>
                   </div>

                   <div className="flex-1 flex items-center justify-between gap-4 md:gap-12 w-full">
                      <div className="text-center md:text-left min-w-[60px]">
                        <p className="text-2xl md:text-3xl font-black text-slate-900 leading-none">{flight.departureTime}</p>
                        <p className="text-sm md:text-lg font-black text-blue-600 mt-1">{flight.departure}</p>
                        <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest hidden md:block">Mumbai</p>
                      </div>

                      <div className="flex-1 flex flex-col items-center">
                        <span className="text-[8px] font-black text-slate-300 uppercase tracking-widest mb-2">{flight.duration}</span>
                        <div className="w-full flex items-center gap-1">
                          <div className="h-px bg-slate-100 flex-1"></div>
                          <i className="fas fa-plane text-slate-300 text-[10px] transform md:rotate-90"></i>
                          <div className="h-px bg-slate-100 flex-1"></div>
                        </div>
                        <span className="text-[8px] font-black text-slate-300 uppercase tracking-widest mt-2">{flight.stops === 0 ? 'Non-stop' : `${flight.stops} Stop`}</span>
                      </div>

                      <div className="text-center md:text-right min-w-[60px]">
                        <p className="text-2xl md:text-3xl font-black text-slate-900 leading-none">{flight.arrivalTime}</p>
                        <p className="text-sm md:text-lg font-black text-blue-600 mt-1">{flight.arrival}</p>
                        <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest hidden md:block">Singapore</p>
                      </div>
                   </div>
                 </div>
              </div>
           </div>
        </div>

        <div className="p-6 md:p-12 space-y-6">
           <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Manifest Identity (2)</h3>
           <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                { name: 'Mr. Rajesh Kumar', ticket: '789456', seat: '12A' },
                { name: 'Mrs. Priya Kumar', ticket: '789457', seat: '12B' }
              ].map((p, i) => (
                <div key={i} className="bg-white p-4 md:p-6 rounded-2xl border border-slate-100 flex items-center justify-between group hover:border-blue-200 transition-all">
                   <div className="flex items-center gap-3 md:gap-4">
                      <div>
                         <p className="font-black text-slate-900 text-sm">{p.name}</p>
                         <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Adult • Ticket: {p.ticket}</p>
                      </div>
                   </div>
                   <div className="bg-slate-50 px-2 md:px-3 py-1 rounded-lg text-[9px] font-black text-slate-600 border border-slate-100 uppercase tracking-widest">
                      Seat {p.seat}
                   </div>
                </div>
              ))}
           </div>
        </div>
      </div>

      <div className="flex justify-center pt-4">
         <button 
          onClick={onDone}
          className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] flex items-center gap-3 hover:text-blue-600 transition-all"
         >
            <i className="fas fa-arrow-left"></i> Make another booking
         </button>
      </div>
      
      <div className="max-w-2xl mx-auto text-center space-y-6 pt-12 border-t border-slate-100 mt-12">
         <div className="inline-flex items-center gap-3 px-4 py-2 bg-slate-50 rounded-full border border-slate-100 text-slate-900 font-black uppercase tracking-widest text-[9px]">
            <i className="fas fa-headset text-blue-600"></i>
            Elite Support Concierge
         </div>
         <p className="text-[11px] text-slate-500 font-medium leading-relaxed max-w-md mx-auto">
            Need to modify your itinerary or request a special service? Our 24/7 support team is standing by. Quote PNR <span className="text-blue-600 font-black">AX9KQ2</span> for priority assistance.
         </p>
         <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-4 pt-2">
            <button className="flex items-center gap-2 text-[10px] font-black text-blue-600 uppercase tracking-widest hover:text-blue-700 transition-colors">
               <i className="fas fa-comments text-[12px]"></i>
               Live Chat
            </button>
            <div className="hidden sm:block w-1 h-1 bg-slate-200 rounded-full"></div>
            <button className="flex items-center gap-2 text-[10px] font-black text-blue-600 uppercase tracking-widest hover:text-blue-700 transition-colors">
               <i className="fas fa-phone-alt text-[12px]"></i>
               +1 (800) SKY-BOOK
            </button>
            <div className="hidden sm:block w-1 h-1 bg-slate-200 rounded-full"></div>
            <button className="flex items-center gap-2 text-[10px] font-black text-blue-600 uppercase tracking-widest hover:text-blue-700 transition-colors">
               <i className="fas fa-envelope text-[12px]"></i>
               Support Hub
            </button>
         </div>
      </div>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .animate-spin-slow {
          animation: spin-slow 8s linear infinite;
        }
      `}} />
    </div>
  );
};

export default BookingConfirmationPage;