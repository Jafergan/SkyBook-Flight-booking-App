import React, { useState } from 'react';
import { Flight } from '../types';

interface PaymentPageProps {
  flight: Flight;
  onPaymentSuccess: () => void;
  onCancel: () => void;
}

const PaymentPage: React.FC<PaymentPageProps> = ({ flight, onPaymentSuccess, onCancel }) => {
  const [activeMethod, setActiveMethod] = useState<'card' | 'upi' | 'net' | 'wallet'>('card');
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedBank, setSelectedBank] = useState<string | null>(null);
  const [selectedWallet, setSelectedWallet] = useState<string | null>(null);

  const handlePayment = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      onPaymentSuccess();
    }, 2500);
  };

  const banks = [
    { name: 'SBI', icon: 'fa-building-columns', color: 'blue' },
    { name: 'HDFC', icon: 'fa-building-columns', color: 'blue' },
    { name: 'ICICI', icon: 'fa-building-columns', color: 'blue' },
    { name: 'Axis', icon: 'fa-building-columns', color: 'blue' },
    { name: 'Kotak', icon: 'fa-building-columns', color: 'blue' },
    { name: 'PNB', icon: 'fa-building-columns', color: 'blue' },
  ];

  const wallets = [
    { name: 'Paytm', icon: 'fa-wallet', desc: 'Fastest Checkout' },
    { name: 'PhonePe', icon: 'fa-mobile-screen', desc: 'Secure UPI' },
    { name: 'Amazon Pay', icon: 'fa-amazon', desc: 'Pay with Balance' },
    { name: 'Mobikwik', icon: 'fa-bolt', desc: 'Extra Cashback' },
  ];

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8 animate-fadeIn">
      <nav className="flex items-center gap-3 text-xs font-black uppercase tracking-widest text-slate-400">
        <span>Bookings</span>
        <i className="fas fa-chevron-right text-[8px]"></i>
        <span>Confirm Flight</span>
        <i className="fas fa-chevron-right text-[8px]"></i>
        <span className="text-blue-600">Payment</span>
      </nav>

      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight leading-none">Secure Payment</h1>
          <p className="text-slate-500 font-medium mt-3">Complete your transaction to confirm booking ID #BK-2024-88</p>
        </div>
        <div className="flex gap-3">
          <button onClick={onCancel} className="px-6 py-2.5 bg-white border border-slate-200 rounded-xl font-bold text-slate-700 hover:bg-slate-50 transition-all">Cancel</button>
          <div className="px-6 py-2.5 bg-emerald-50 text-emerald-600 rounded-xl font-black text-xs uppercase tracking-widest flex items-center gap-2 border border-emerald-100">
            <i className="fas fa-lock"></i> Encrypted & Secure
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Payment Methods */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden">
            <div className="grid grid-cols-4 border-b border-slate-100">
              {[
                { id: 'card', label: 'Card', icon: 'fa-credit-card' },
                { id: 'upi', label: 'UPI / QR', icon: 'fa-qrcode' },
                { id: 'net', label: 'Net Banking', icon: 'fa-university' },
                { id: 'wallet', label: 'Wallet', icon: 'fa-wallet' },
              ].map((m) => (
                <button
                  key={m.id}
                  onClick={() => setActiveMethod(m.id as any)}
                  className={`py-6 flex flex-col items-center gap-2 transition-all border-b-2 ${
                    activeMethod === m.id ? 'bg-blue-50/50 text-blue-600 border-blue-600' : 'text-slate-400 border-transparent hover:text-slate-600'
                  }`}
                >
                  <i className={`fas ${m.icon} text-lg`}></i>
                  <span className="text-[10px] font-black uppercase tracking-widest">{m.label}</span>
                </button>
              ))}
            </div>

            <div className="p-10">
              {activeMethod === 'card' && (
                <div className="flex flex-col lg:flex-row gap-12 items-center animate-fadeIn">
                  <div className="flex-1 w-full space-y-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Card Number</label>
                      <div className="relative">
                        <i className="fas fa-credit-card absolute left-5 top-1/2 -translate-y-1/2 text-slate-300"></i>
                        <input type="text" placeholder="0000 0000 0000 0000" className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-12 py-4 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all font-bold text-slate-800" />
                        <div className="absolute right-4 top-1/2 -translate-y-1/2 flex gap-1">
                          <i className="fab fa-cc-mastercard text-slate-300 text-xl"></i>
                          <i className="fab fa-cc-visa text-slate-300 text-xl"></i>
                        </div>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Cardholder Name</label>
                      <input type="text" placeholder="e.g. Alex Johnson" className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all font-bold text-slate-800" />
                    </div>
                    <div className="grid grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Expiry Date</label>
                        <input type="text" placeholder="MM / YY" className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all font-bold text-slate-800" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">CVV / CVC <i className="fas fa-question-circle opacity-50"></i></label>
                        <input type="text" placeholder="123" className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all font-bold text-slate-800" />
                      </div>
                    </div>
                    <label className="flex items-center gap-3 cursor-pointer group pt-2">
                      <input type="checkbox" className="w-4 h-4 rounded border-slate-200 text-blue-600 focus:ring-blue-500" />
                      <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest group-hover:text-slate-900">Save this card for faster payments</span>
                    </label>
                  </div>

                  <div className="w-full lg:w-[380px] h-[220px] bg-slate-900 rounded-[1.5rem] p-8 text-white flex flex-col justify-between shadow-2xl relative overflow-hidden group">
                    <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent pointer-events-none"></div>
                    <div className="flex justify-between items-start relative z-10">
                      <div className="w-12 h-10 bg-gradient-to-br from-amber-400 to-amber-200 rounded-lg shadow-inner"></div>
                      <i className="fas fa-wifi rotate-90 text-slate-400/50"></i>
                    </div>
                    <div className="space-y-1 relative z-10">
                      <p className="text-xl font-mono tracking-[0.3em] font-black">4242 •••• •••• ••••</p>
                      <div className="flex justify-between items-end pt-4">
                        <div>
                          <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">Card Holder</p>
                          <p className="text-sm font-black tracking-tight uppercase">Alex Johnson</p>
                        </div>
                        <div>
                          <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">Expires</p>
                          <p className="text-sm font-black tracking-tight">12/26</p>
                        </div>
                        <i className="fab fa-cc-visa text-4xl opacity-80"></i>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeMethod === 'upi' && (
                <div className="flex flex-col md:flex-row gap-12 items-center animate-fadeIn">
                  <div className="w-full md:w-64 space-y-6 text-center">
                    <div className="bg-slate-50 p-6 rounded-[2.5rem] border border-slate-100 flex flex-col items-center gap-4 shadow-inner">
                      <div className="w-40 h-40 bg-white p-4 rounded-3xl border border-slate-200 flex items-center justify-center relative overflow-hidden group">
                         <i className="fas fa-qrcode text-8xl text-slate-900 group-hover:scale-110 transition-transform"></i>
                         <div className="absolute inset-0 bg-blue-600/5 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                           <i className="fas fa-expand text-blue-600"></i>
                         </div>
                      </div>
                      <div className="space-y-1">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Scan with any UPI App</p>
                        <div className="flex justify-center gap-2 opacity-40">
                          <i className="fab fa-google-pay text-xl"></i>
                          <i className="fas fa-mobile-screen text-lg"></i>
                          <i className="fas fa-wallet text-lg"></i>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex-1 w-full space-y-8">
                    <div className="space-y-4">
                      <h3 className="text-xl font-black text-slate-900">Pay via UPI ID</h3>
                      <p className="text-sm font-medium text-slate-500">Enter your VPA / UPI ID to receive a payment request on your mobile.</p>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Your UPI ID</label>
                      <div className="relative">
                        <i className="fas fa-at absolute left-5 top-1/2 -translate-y-1/2 text-[10px] text-slate-300"></i>
                        <input type="text" placeholder="username@upi" className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-12 py-4 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all font-bold text-slate-800" />
                        <span className="absolute right-5 top-1/2 -translate-y-1/2 text-[10px] font-black text-blue-600 uppercase tracking-widest">Verify</span>
                      </div>
                    </div>
                    <div className="bg-blue-50 p-4 rounded-2xl border border-blue-100 flex items-center gap-4">
                       <i className="fas fa-info-circle text-blue-600"></i>
                       <p className="text-[10px] font-bold text-blue-700 uppercase tracking-wider">Please accept the request on your UPI app within 5 minutes.</p>
                    </div>
                  </div>
                </div>
              )}

              {activeMethod === 'net' && (
                <div className="space-y-8 animate-fadeIn">
                  <div className="space-y-4">
                    <h3 className="text-xl font-black text-slate-900">Popular Banks</h3>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      {banks.map((bank) => (
                        <button
                          key={bank.name}
                          onClick={() => setSelectedBank(bank.name)}
                          className={`p-6 rounded-[2rem] border transition-all flex flex-col items-center gap-3 ${
                            selectedBank === bank.name 
                              ? 'bg-blue-600 border-blue-600 text-white shadow-xl shadow-blue-500/20' 
                              : 'bg-slate-50 border-slate-100 text-slate-600 hover:bg-white hover:border-blue-200'
                          }`}
                        >
                          <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${selectedBank === bank.name ? 'bg-white/20' : 'bg-white shadow-sm'}`}>
                            <i className={`fas ${bank.icon} ${selectedBank === bank.name ? 'text-white' : 'text-blue-600'}`}></i>
                          </div>
                          <span className="text-xs font-black uppercase tracking-widest">{bank.name}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Other Banks</label>
                    <select className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 font-bold text-slate-800 outline-none appearance-none">
                      <option>Select another bank</option>
                      <option>Bank of Baroda</option>
                      <option>Canara Bank</option>
                      <option>Standard Chartered</option>
                      <option>DBS Bank</option>
                    </select>
                  </div>
                </div>
              )}

              {activeMethod === 'wallet' && (
                <div className="space-y-8 animate-fadeIn">
                  <div className="space-y-4">
                    <h3 className="text-xl font-black text-slate-900">Select Wallet</h3>
                    <div className="space-y-3">
                      {wallets.map((wallet) => (
                        <button
                          key={wallet.name}
                          onClick={() => setSelectedWallet(wallet.name)}
                          className={`w-full p-5 rounded-[1.5rem] border transition-all flex items-center justify-between group ${
                            selectedWallet === wallet.name 
                              ? 'bg-blue-50 border-blue-600' 
                              : 'bg-white border-slate-100 hover:bg-slate-50'
                          }`}
                        >
                          <div className="flex items-center gap-4">
                             <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-xl ${selectedWallet === wallet.name ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-400 group-hover:bg-blue-50'}`}>
                                <i className={`fas ${wallet.icon}`}></i>
                             </div>
                             <div className="text-left">
                                <p className="text-sm font-black text-slate-900">{wallet.name}</p>
                                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{wallet.desc}</p>
                             </div>
                          </div>
                          <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${selectedWallet === wallet.name ? 'border-blue-600 bg-blue-600' : 'border-slate-200'}`}>
                             {selectedWallet === wallet.name && <i className="fas fa-check text-[10px] text-white"></i>}
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="px-10 py-8 bg-slate-50/50 border-t border-slate-100">
               <button 
                onClick={handlePayment}
                disabled={isProcessing}
                className="w-full bg-blue-600 text-white font-black py-5 rounded-2xl shadow-xl shadow-blue-500/20 hover:bg-blue-700 transition-all flex items-center justify-center gap-3 uppercase tracking-widest text-xs"
               >
                 {isProcessing ? (
                   <>
                     <i className="fas fa-circle-notch animate-spin"></i> Initializing Secure Gateway...
                   </>
                 ) : (
                   `Confirm & Pay $1,240.50`
                 )}
               </button>
            </div>
          </div>

          <div className="flex items-center justify-center gap-6 text-slate-400 text-[10px] font-black uppercase tracking-widest">
             <div className="flex items-center gap-2">
                <i className="fas fa-shield-halved text-blue-500"></i>
                <span>Secure Payments</span>
             </div>
             <div className="flex items-center gap-2">
                <i className="fas fa-headset opacity-30"></i>
                <span>24/7 Support</span>
             </div>
          </div>
        </div>

        {/* Sidebar Summary */}
        <div className="space-y-6">
          <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm p-8">
            <h3 className="text-lg font-black text-slate-900 mb-6">Booking Summary</h3>
            
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="text-center">
                  <p className="text-2xl font-black text-slate-900">LHR</p>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">London</p>
                </div>
                <div className="flex-1 flex flex-col items-center px-4">
                   <span className="text-[8px] font-black text-slate-300 uppercase tracking-widest mb-1">10h 25m</span>
                   <div className="w-full flex items-center gap-1">
                      <div className="h-px bg-slate-100 flex-1 border-dashed"></div>
                      <i className="fas fa-plane text-blue-500 text-[10px]"></i>
                      <div className="h-px bg-slate-100 flex-1"></div>
                   </div>
                   <span className="text-[8px] font-black text-slate-300 uppercase tracking-widest mt-1">Direct</span>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-black text-slate-900">JFK</p>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">New York</p>
                </div>
              </div>

              <div className="p-4 bg-slate-50/50 rounded-2xl space-y-3">
                 <div className="flex items-center gap-3">
                    <i className="far fa-calendar-alt text-slate-400 text-sm"></i>
                    <div>
                       <p className="text-xs font-black text-slate-800">Fri, 24 Nov 2024</p>
                       <p className="text-[9px] font-bold text-slate-400">10:00 AM - 08:25 PM</p>
                    </div>
                 </div>
                 <div className="flex items-center gap-3">
                    <i className="fas fa-user-friends text-slate-400 text-sm"></i>
                    <div>
                       <p className="text-xs font-black text-slate-800">2 Passengers</p>
                       <p className="text-[9px] font-bold text-slate-400">Economy Class</p>
                    </div>
                 </div>
              </div>

              <div className="h-px bg-slate-50"></div>

              <div className="space-y-3">
                <div className="flex justify-between items-center text-sm font-bold">
                  <span className="text-slate-400">Base Fare (x2)</span>
                  <span className="text-slate-900">$1,080.00</span>
                </div>
                <div className="flex justify-between items-center text-sm font-bold">
                  <span className="text-slate-400">Taxes & Fees</span>
                  <span className="text-slate-900">$145.50</span>
                </div>
                <div className="flex justify-between items-center text-sm font-bold">
                  <span className="text-slate-400">Service Charge</span>
                  <span className="text-slate-900">$15.00</span>
                </div>
              </div>

              <div className="flex justify-between items-center pt-4 border-t border-slate-50">
                 <span className="text-sm font-black text-slate-900">Total Payable</span>
                 <span className="text-2xl font-black text-blue-600">$1,240.50</span>
              </div>
            </div>
          </div>

          <div className="bg-emerald-50 rounded-[2rem] border border-emerald-100 p-8 space-y-4">
            <div className="flex items-center gap-4">
               <div className="w-8 h-8 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center shadow-sm">
                  <i className="fas fa-check text-xs"></i>
               </div>
               <div>
                  <h4 className="text-sm font-black text-emerald-800">Neural Trust Active</h4>
                  <p className="text-[10px] font-bold text-emerald-600">Secure Protocol v5.0</p>
               </div>
            </div>
            <p className="text-[10px] font-medium text-emerald-700 leading-relaxed">
               All transactions are monitored by SkyBook AI for fraud prevention and zero-latency routing.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PaymentPage;