
import React, { useRef, useState } from 'react';
import { Flight } from '../types';

interface PassengerDetailsPageProps {
  flight: Flight;
  onContinue: (passengerData: any) => void;
  onBack: () => void;
}

interface Passenger {
  id: string;
  firstName: string;
  lastName: string;
  dob: string;
  gender: string;
  passport: string;
  expiry: string;
  passportFile: string | null;
}

const PassengerDetailsPage: React.FC<PassengerDetailsPageProps> = ({ flight, onContinue, onBack }) => {
  const [passengers, setPassengers] = useState<Passenger[]>([
    {
      id: '1',
      firstName: "Rahul",
      lastName: "Verma",
      dob: "06/12/1992",
      gender: "Male",
      passport: "M1234567",
      expiry: "",
      passportFile: null
    }
  ]);

  const fileInputRefs = useRef<{ [key: string]: HTMLInputElement | null }>({});

  const handleAddPassenger = () => {
    const newPassenger: Passenger = {
      id: Math.random().toString(36).substr(2, 9),
      firstName: "",
      lastName: "",
      dob: "",
      gender: "Male",
      passport: "",
      expiry: "",
      passportFile: null
    };
    setPassengers([...passengers, newPassenger]);
  };

  const handleRemovePassenger = (id: string) => {
    if (passengers.length > 1) {
      setPassengers(passengers.filter(p => p.id !== id));
    }
  };

  const updatePassenger = (id: string, field: keyof Passenger, value: string | null) => {
    setPassengers(passengers.map(p => p.id === id ? { ...p, [field]: value } : p));
  };

  const handleUploadClick = (id: string) => {
    fileInputRefs.current[id]?.click();
  };

  const handleFileChange = (id: string, event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      updatePassenger(id, 'passportFile', file.name);
    }
  };

  const handleSubmit = () => {
    onContinue({ passengers });
  };

  return (
    <div className="p-8 max-w-5xl mx-auto space-y-8 animate-fadeIn">
      {/* Breadcrumbs */}
      <nav className="flex items-center gap-3 text-xs font-black uppercase tracking-widest text-slate-400">
        <span>Search</span>
        <i className="fas fa-chevron-right text-[8px]"></i>
        <span>Flight Selection</span>
        <i className="fas fa-chevron-right text-[8px]"></i>
        <span className="text-blue-600">Passenger Details</span>
        <i className="fas fa-chevron-right text-[8px]"></i>
        <span>Payment</span>
      </nav>

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight">Passenger Details</h1>
          <p className="text-slate-500 font-medium mt-1 flex items-center gap-3">
             <i className="fas fa-plane text-blue-500"></i>
             Flight {flight.departure} to {flight.arrival} • {passengers.length} Traveler{passengers.length > 1 ? 's' : ''}
          </p>
        </div>
        <div className="bg-blue-50 text-blue-600 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest border border-blue-100">
          {passengers.length} Adult{passengers.length > 1 ? 's' : ''}
        </div>
      </div>

      <div className="space-y-8">
        {passengers.map((passenger, index) => (
          <div key={passenger.id} className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden animate-slideUp">
            <div className="p-8 border-b border-slate-50 bg-slate-50/30 flex items-center justify-between">
               <div className="flex items-center gap-4">
                  <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-black text-xs">{index + 1}</div>
                  <h3 className="text-lg font-black text-slate-900">
                    Adult {index + 1} {index === 0 ? '- Primary Traveler' : ''}
                  </h3>
               </div>
               <div className="flex items-center gap-4">
                 {index === 0 ? (
                   <span className="text-[10px] font-black text-emerald-600 bg-emerald-50 px-3 py-1 rounded-lg uppercase tracking-widest border border-emerald-100 flex items-center gap-2">
                      <i className="fas fa-check-circle"></i> Pre-filled
                   </span>
                 ) : (
                   <button 
                    onClick={() => handleRemovePassenger(passenger.id)}
                    className="text-[10px] font-black text-red-500 bg-red-50 px-3 py-1 rounded-lg uppercase tracking-widest border border-red-100 flex items-center gap-2 hover:bg-red-100 transition-colors"
                   >
                      <i className="fas fa-trash-alt"></i> Remove
                   </button>
                 )}
               </div>
            </div>

            <div className="p-10 grid grid-cols-1 lg:grid-cols-3 gap-12">
               <div className="lg:col-span-2 space-y-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">First & Middle Name</label>
                      <input 
                        type="text" 
                        value={passenger.firstName} 
                        onChange={(e) => updatePassenger(passenger.id, 'firstName', e.target.value)}
                        placeholder="John"
                        className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all font-bold text-slate-800" 
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Last Name</label>
                      <input 
                        type="text" 
                        value={passenger.lastName} 
                        onChange={(e) => updatePassenger(passenger.id, 'lastName', e.target.value)}
                        placeholder="Doe"
                        className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all font-bold text-slate-800" 
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Date of Birth</label>
                      <div className="relative">
                        <input 
                          type="text" 
                          value={passenger.dob} 
                          onChange={(e) => updatePassenger(passenger.id, 'dob', e.target.value)}
                          placeholder="DD/MM/YYYY"
                          className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all font-bold text-slate-800" 
                        />
                        <i className="far fa-calendar absolute right-6 top-1/2 -translate-y-1/2 text-slate-300"></i>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Gender</label>
                      <select 
                        value={passenger.gender}
                        onChange={(e) => updatePassenger(passenger.id, 'gender', e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all font-bold text-slate-800 appearance-none"
                      >
                        <option>Male</option>
                        <option>Female</option>
                        <option>Other</option>
                      </select>
                    </div>
                  </div>

                  <div className="h-px bg-slate-50"></div>
                  <p className="text-[10px] font-black text-slate-300 uppercase tracking-[0.2em] pt-2">Passport Details</p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Passport Number</label>
                      <input 
                        type="text" 
                        value={passenger.passport} 
                        onChange={(e) => updatePassenger(passenger.id, 'passport', e.target.value)}
                        placeholder="M1234567"
                        className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all font-bold text-slate-800" 
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Expiry Date</label>
                      <div className="relative">
                        <input 
                          type="text" 
                          value={passenger.expiry} 
                          onChange={(e) => updatePassenger(passenger.id, 'expiry', e.target.value)}
                          placeholder="MM/DD/YYYY"
                          className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all font-bold text-slate-800" 
                        />
                        <i className="far fa-calendar absolute right-6 top-1/2 -translate-y-1/2 text-slate-300"></i>
                      </div>
                    </div>
                  </div>
               </div>

               <div className="space-y-4">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Travel Document</label>
                  <div 
                    onClick={() => handleUploadClick(passenger.id)}
                    className={`border-2 border-dashed rounded-[2rem] p-10 flex flex-col items-center justify-center text-center gap-4 transition-all cursor-pointer group ${
                      passenger.passportFile ? 'bg-emerald-50 border-emerald-200' : 'border-slate-100 bg-slate-50/30 hover:bg-white hover:border-blue-300'
                    }`}
                  >
                     <input 
                      type="file" 
                      // Fixed ref callback to return void
                      ref={(el) => { fileInputRefs.current[passenger.id] = el; }}
                      className="hidden" 
                      onChange={(e) => handleFileChange(passenger.id, e)}
                      accept=".pdf,.jpg,.jpeg,.png"
                     />
                     <div className={`w-16 h-16 rounded-full flex items-center justify-center shadow-sm transition-transform group-hover:scale-110 ${
                       passenger.passportFile ? 'bg-emerald-500 text-white' : 'bg-white text-blue-500'
                     }`}>
                        <i className={`fas ${passenger.passportFile ? 'fa-check' : 'fa-cloud-upload-alt'} text-2xl`}></i>
                     </div>
                     <div>
                        <p className={`text-sm font-black ${passenger.passportFile ? 'text-emerald-900' : 'text-slate-800'}`}>
                          {passenger.passportFile ? passenger.passportFile : 'Click to upload'}
                        </p>
                        <p className="text-[10px] font-bold text-slate-400 mt-1">
                          {passenger.passportFile ? 'Document successfully attached' : 'or drag and drop passport scan'}
                        </p>
                     </div>
                     {!passenger.passportFile && <p className="text-[9px] font-black text-slate-300 uppercase tracking-widest">PDF, JPG or PNG (Max 5MB)</p>}
                  </div>
               </div>
            </div>
          </div>
        ))}

        {/* Add Passenger Button */}
        <button 
          onClick={handleAddPassenger}
          className="w-full py-8 border-2 border-dashed border-slate-200 rounded-[2.5rem] bg-slate-50 text-slate-400 hover:bg-white hover:border-blue-300 hover:text-blue-600 transition-all flex flex-col items-center justify-center gap-3 group"
        >
          <div className="w-12 h-12 rounded-2xl bg-white border border-slate-100 flex items-center justify-center shadow-sm group-hover:bg-blue-50 group-hover:text-blue-600 transition-all">
            <i className="fas fa-plus"></i>
          </div>
          <p className="text-sm font-black uppercase tracking-widest">Add Another Adult Traveler</p>
        </button>
      </div>

      <div className="bg-slate-900 rounded-[2.5rem] p-8 flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl shadow-slate-900/10">
         <div>
            <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] mb-1">Estimated Settlement</p>
            <p className="text-3xl font-black text-white">${(620 * passengers.length).toLocaleString()}.00 <span className="text-slate-500 text-xs font-bold uppercase tracking-widest ml-1">USD</span></p>
         </div>
         <div className="flex gap-4">
            <button 
              onClick={onBack}
              className="px-8 py-4 bg-slate-800 text-white font-black rounded-2xl hover:bg-slate-700 transition-all uppercase tracking-widest text-[10px]"
            >
              Back
            </button>
            <button 
              onClick={handleSubmit}
              className="px-8 py-4 bg-blue-600 text-white font-black rounded-2xl shadow-xl shadow-blue-500/20 hover:bg-blue-700 transition-all uppercase tracking-widest text-[10px]"
            >
              Continue to Review
            </button>
         </div>
      </div>
    </div>
  );
};

export default PassengerDetailsPage;
