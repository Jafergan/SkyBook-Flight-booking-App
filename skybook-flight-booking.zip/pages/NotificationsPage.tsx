import React, { useState } from 'react';

interface NotificationsPageProps {
  onBack: () => void;
}

const NotificationsPage: React.FC<NotificationsPageProps> = ({ onBack }) => {
  const [filter, setFilter] = useState('All');
  
  const notifications = [
    { id: '1', type: 'Flight Update', title: 'Price dropped for DEL → BOM', description: 'Flight AI-304 is now ₹4,500 (was ₹5,200). Book now to save 15%.', timestamp: '2 hours ago', isRead: false },
    { id: '2', type: 'Lead', title: 'Follow up pending for Lead #128', description: 'John Doe requested a callback regarding the Dubai Luxury Package.', timestamp: '4 hours ago', isRead: false, priority: 'High' },
    { id: '3', type: 'Flight Update', title: 'Booking Confirmed', description: 'PNR: YH78JK for Singapore Airlines has been successfully ticketed.', timestamp: 'Yesterday at 2:30 PM', isRead: true },
    { id: '4', type: 'System', title: 'Subscription Renewal', description: 'Your monthly subscription for the Agency Pro plan is due in 3 days.', timestamp: 'Yesterday at 9:00 AM', isRead: true },
  ];

  return (
    <div className="p-8 max-w-5xl mx-auto space-y-8 animate-fadeIn">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <button 
            onClick={onBack}
            className="mb-4 flex items-center gap-2 text-slate-400 hover:text-blue-600 transition-all group font-black text-[10px] uppercase tracking-widest w-fit"
          >
            <i className="fas fa-arrow-left group-hover:-translate-x-1 transition-transform"></i>
            Return to Dashboard
          </button>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight leading-none">Notifications</h1>
          <p className="text-slate-500 font-medium mt-3">Stay updated on your flights and leads</p>
        </div>
        <button className="px-6 py-2.5 bg-white border border-slate-200 rounded-xl font-black text-xs uppercase tracking-widest text-slate-700 flex items-center gap-2 hover:bg-slate-50 transition-all shadow-sm">
          <i className="fas fa-check-double text-[10px]"></i> Mark all as read
        </button>
      </div>

      <div className="space-y-10">
        <div>
          <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-6">Activity Feed</h3>
          <div className="space-y-4">
            {notifications.map(n => (
              <div key={n.id} className={`bg-white rounded-[2rem] p-8 border border-slate-100 shadow-sm relative overflow-hidden group hover:border-blue-200 transition-all ${!n.isRead ? 'border-l-4 border-l-blue-600' : ''}`}>
                <div className="flex gap-6 items-start">
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-xl shrink-0 ${
                    n.type === 'Flight Update' ? 'bg-blue-50 text-blue-600' : 
                    n.type === 'Lead' ? 'bg-orange-50 text-orange-600' : 'bg-slate-50 text-slate-600'
                  }`}>
                    <i className={`fas ${n.type === 'Flight Update' ? 'fa-chart-line' : n.type === 'Lead' ? 'fa-clock' : 'fa-cog'}`}></i>
                  </div>
                  <div className="flex-1 space-y-2">
                    <div className="flex justify-between items-start">
                      <h4 className="text-lg font-black text-slate-900 tracking-tight leading-tight">{n.title}</h4>
                      {!n.isRead && <span className="w-2.5 h-2.5 bg-blue-600 rounded-full animate-pulse"></span>}
                    </div>
                    <p className="text-sm font-medium text-slate-500 leading-relaxed pr-10">{n.description}</p>
                    <p className="text-[10px] font-bold text-slate-400">{n.timestamp}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default NotificationsPage;