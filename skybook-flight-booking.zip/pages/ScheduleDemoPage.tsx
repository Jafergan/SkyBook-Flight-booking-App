
import React, { useState } from 'react';

interface ScheduleDemoPageProps {
  onBack: () => void;
  onComplete: () => void;
}

const ScheduleDemoPage: React.FC<ScheduleDemoPageProps> = ({ onBack, onComplete }) => {
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [isPrivacyOpen, setIsPrivacyOpen] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
    }, 1500);
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6 animate-fadeIn">
        <div className="max-w-md w-full bg-white rounded-[3rem] p-12 text-center shadow-2xl border border-slate-100">
           <div className="w-20 h-20 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center text-3xl mx-auto mb-8 shadow-inner">
              <i className="fas fa-calendar-check"></i>
           </div>
           <h2 className="text-3xl font-black text-slate-900 tracking-tight mb-4">Request Received!</h2>
           <p className="text-slate-500 font-medium leading-relaxed mb-10">
              One of our product specialists will reach out to you within 24 hours to coordinate your personalized v5.0 platform tour.
           </p>
           <button 
            onClick={onComplete}
            className="w-full bg-blue-600 text-white font-black py-5 rounded-2xl shadow-xl hover:bg-blue-700 transition-all uppercase tracking-widest text-xs"
           >
              Back to Home
           </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 font-sans flex flex-col animate-fadeIn">
      <header className="bg-white border-b border-slate-100 px-6 md:px-12 py-6 flex items-center justify-between">
        <button onClick={onBack} className="flex items-center gap-2 group text-slate-400 hover:text-blue-600 transition-colors">
          <i className="fas fa-arrow-left group-hover:-translate-x-1 transition-transform"></i>
          <span className="text-[10px] font-black uppercase tracking-widest">Back to Why SkyBook</span>
        </button>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white">
            <i className="fas fa-plane-departure text-sm"></i>
          </div>
          <span className="text-xl font-extrabold tracking-tight text-slate-900">SkyBook</span>
        </div>
        <div className="hidden md:block w-24"></div> 
      </header>

      <div className="flex-1 max-w-7xl mx-auto w-full px-6 py-12 md:py-16 grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
         <div className="space-y-8">
            <div className="inline-block bg-blue-100 text-blue-700 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest mb-2">
               Enterprise Access
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-black text-slate-900 tracking-tight leading-tight">
               Experience the <br/> <span className="text-blue-600">v5.0 Engine</span> <br/> First-Hand.
            </h1>
            <p className="text-slate-500 font-medium text-lg leading-relaxed max-w-xl">
               Book a 1:1 discovery call with our solutions team to learn how SkyBook's AI can optimize your booking workflow and increase revenue margins.
            </p>
            <div className="space-y-4 pt-4">
               {[
                 { icon: 'fa-brain', text: 'Neural Search Training' },
                 { icon: 'fa-chart-network', text: 'Pipeline Integration Audit' },
                 { icon: 'fa-shield-check', text: 'Security & Compliance Overview' }
               ].map((item, i) => (
                 <div key={i} className="flex items-center gap-4 text-slate-700 font-bold">
                    <div className="w-8 h-8 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center text-xs">
                       <i className={`fas ${item.icon}`}></i>
                    </div>
                    {item.text}
                 </div>
               ))}
            </div>
         </div>

         <div className="bg-white rounded-[2.5rem] shadow-2xl border border-slate-100 p-8 md:p-10 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 opacity-5">
              <i className="fas fa-id-card text-8xl text-blue-600"></i>
            </div>
            <form onSubmit={handleSubmit} className="space-y-6 relative z-10">
               <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Professional Name</label>
                  <input required type="text" placeholder="John Doe" className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 font-bold text-slate-800 outline-none focus:ring-4 focus:ring-blue-500/10 transition-all" />
               </div>
               <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Agency / User Email</label>
                  <input required type="email" placeholder="john@global-travel.com" className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 font-bold text-slate-800 outline-none focus:ring-4 focus:ring-blue-500/10 transition-all" />
               </div>
               <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                     <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Monthly Bookings</label>
                     <select className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 font-bold text-slate-800 outline-none appearance-none">
                        <option>0-100</option>
                        <option>100-500</option>
                        <option>500-2000</option>
                        <option>2000+</option>
                     </select>
                  </div>
                  <div className="space-y-2">
                     <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Timezone</label>
                     <select className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 font-bold text-slate-800 outline-none appearance-none">
                        <option>UTC+5:30 (IST)</option>
                        <option>UTC+0:00 (GMT)</option>
                        <option>UTC-5:00 (EST)</option>
                     </select>
                  </div>
               </div>
               <button 
                  disabled={loading}
                  type="submit"
                  className="w-full bg-blue-600 text-white font-black py-5 rounded-2xl shadow-xl hover:bg-blue-700 transition-all uppercase tracking-widest text-xs flex items-center justify-center gap-3 mt-4"
               >
                  {loading ? <i className="fas fa-circle-notch animate-spin"></i> : 'Request Platform Tour'}
               </button>
               <p className="text-[9px] text-center text-slate-400 font-bold uppercase tracking-widest">
                  By clicking, you agree to our <button type="button" onClick={() => setIsPrivacyOpen(true)} className="text-blue-600 hover:underline">Privacy Policy</button>
               </p>
            </form>
         </div>
      </div>

      {/* Privacy Policy Modal */}
      {isPrivacyOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
          <div 
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-md animate-fadeIn"
            onClick={() => setIsPrivacyOpen(false)}
          ></div>
          <div className="bg-white w-full max-w-2xl rounded-[2.5rem] shadow-2xl relative z-10 animate-slideUp border border-slate-100 overflow-hidden flex flex-col max-h-[85vh]">
            <div className="bg-slate-900 p-8 flex justify-between items-center text-white shrink-0">
               <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center">
                    <i className="fas fa-shield-alt"></i>
                  </div>
                  <div>
                    <h3 className="text-xl font-black tracking-tight">Data Sovereignty Commitment</h3>
                    <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest">SkyBook Security Protocol v5.0</p>
                  </div>
               </div>
               <button onClick={() => setIsPrivacyOpen(false)} className="w-10 h-10 rounded-xl hover:bg-white/10 flex items-center justify-center transition-all">
                  <i className="fas fa-times"></i>
               </button>
            </div>
            
            <div className="p-10 overflow-y-auto space-y-8 scrollbar-hide">
               <div className="space-y-3">
                  <h4 className="text-sm font-black text-slate-900 uppercase tracking-widest">1. Data Collection Purpose</h4>
                  <p className="text-sm text-slate-500 font-medium leading-relaxed">
                    We collect your professional name, email, and business metrics solely to prepare a tailored demonstration of the SkyBook v5.0 platform. This allows our specialists to configure relevant flight routes and regional settings before the discovery call.
                  </p>
               </div>

               <div className="space-y-3">
                  <h4 className="text-sm font-black text-slate-900 uppercase tracking-widest">2. Banking-Grade Protection</h4>
                  <p className="text-sm text-slate-500 font-medium leading-relaxed">
                    All data transmitted through our "Enterprise Access" gateway is protected by AES-256 bit encryption. Your information is stored on secure, partitioned nodes that meet the same PCI-DSS compliance standards we use for processing global airline transactions.
                  </p>
               </div>

               <div className="space-y-3">
                  <h4 className="text-sm font-black text-slate-900 uppercase tracking-widest">3. Zero-Share Policy</h4>
                  <p className="text-sm text-slate-500 font-medium leading-relaxed">
                    SkyBook maintains a strict non-disclosure policy. We <span className="text-blue-600 font-bold">never</span> sell or share your business data, lead pipelines, or email addresses with third-party aggregators or competitive travel marketing agencies.
                  </p>
               </div>

               <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100 flex items-start gap-4">
                  <i className="fas fa-info-circle text-blue-600 mt-1"></i>
                  <p className="text-[11px] font-bold text-slate-600 leading-relaxed uppercase tracking-wide">
                    By submitting this request, you consent to being contacted by a SkyBook Enterprise Solution Specialist via the provided email address for the sole purpose of scheduling a platform demonstration.
                  </p>
               </div>
            </div>

            <div className="p-8 border-t border-slate-100 bg-slate-50/50 flex justify-center shrink-0">
               <button 
                onClick={() => setIsPrivacyOpen(false)}
                className="px-12 py-4 bg-slate-900 text-white font-black rounded-2xl text-[10px] uppercase tracking-widest hover:bg-slate-800 transition-all shadow-xl"
               >
                  Acknowledged & Secure
               </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ScheduleDemoPage;
