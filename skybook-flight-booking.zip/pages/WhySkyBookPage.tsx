import React from 'react';

interface WhySkyBookPageProps {
  onBack: () => void;
  onJoin: () => void;
  onScheduleDemo: () => void;
}

const WhySkyBookPage: React.FC<WhySkyBookPageProps> = ({ onBack, onJoin, onScheduleDemo }) => {
  return (
    <div className="min-h-screen bg-white font-sans text-slate-900 animate-fadeIn relative selection:bg-blue-100 selection:text-blue-900">
      {/* Subtle Global Background Pattern */}
      <div className="fixed inset-0 pointer-events-none opacity-[0.03] z-0">
         <img src="https://www.transparenttextures.com/patterns/cubes.png" className="w-full h-full repeat" alt="" />
      </div>

      {/* Dynamic Header */}
      <nav className="flex items-center justify-between px-12 py-8 max-w-7xl mx-auto relative z-20">
        <button onClick={onBack} className="flex items-center gap-2 group text-slate-400 hover:text-blue-600 transition-colors">
          <i className="fas fa-arrow-left group-hover:-translate-x-1 transition-transform"></i>
          <span className="text-xs font-black uppercase tracking-widest">Back to Home</span>
        </button>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white">
            <i className="fas fa-plane-departure text-sm"></i>
          </div>
          <span className="text-xl font-extrabold tracking-tight text-slate-900">SkyBook</span>
        </div>
        <button onClick={onJoin} className="bg-blue-600 text-white px-8 py-3 rounded-xl font-black text-xs uppercase tracking-widest shadow-xl shadow-blue-500/20 hover:bg-blue-700 transition-all">
          Register
        </button>
      </nav>

      {/* Hero Section with Enhanced Background */}
      <section className="relative h-[700px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1530521954074-e64f6810b32d?auto=format&fit=crop&q=80&w=2000" 
            className="w-full h-full object-cover transform scale-105"
            alt="Premium aviation wing at sunset"
          />
          <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-[2px]"></div>
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-white/10 to-white"></div>
        </div>

        <div className="relative z-10 text-center max-w-4xl px-6 space-y-6">
          <div className="inline-block px-4 py-1.5 bg-blue-600 text-white rounded-full text-[10px] font-black uppercase tracking-[0.3em] mb-4 shadow-xl shadow-blue-500/20 animate-bounce-subtle">
             Heritage Meets Innovation
          </div>
          <h1 className="text-6xl md:text-8xl font-black text-slate-900 tracking-tighter leading-none drop-shadow-sm">
            The Pinnacle <br/> of <span className="text-blue-600">Travel Tech.</span>
          </h1>
          <p className="text-xl text-slate-700 font-medium max-w-2xl mx-auto leading-relaxed">
            Discover why global travel agencies and elite travelers choose SkyBook for their most critical journeys.
          </p>
        </div>
      </section>

      {/* Content Grid */}
      <section className="max-w-7xl mx-auto px-6 py-32 space-y-32 relative z-10">
        {/* Excellence Pillar 1 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
          <div className="space-y-8">
            <div className="w-16 h-16 bg-blue-50 rounded-[2rem] flex items-center justify-center text-blue-600 text-2xl shadow-inner border border-blue-100">
               <i className="fas fa-microchip"></i>
            </div>
            <h2 className="text-4xl font-black text-slate-900 tracking-tight">Intelligence That Understands You.</h2>
            <p className="text-lg text-slate-500 leading-relaxed font-medium">
              Powered by our proprietary v5.0 Neural Engine, SkyBook analyzes millions of route combinations in milliseconds. Our AI doesn't just find flights; it anticipates price fluctuations, weather risks, and connection delays before you even hit search.
            </p>
            <ul className="space-y-4">
               {['Predictive Fare Analytics', 'Real-time Route Optimization', 'Smart Connection Monitoring'].map(item => (
                 <li key={item} className="flex items-center gap-4 text-slate-900 font-bold">
                   <i className="fas fa-check-circle text-blue-500"></i>
                   {item}
                 </li>
               ))}
            </ul>
          </div>
          <div className="relative group">
            <div className="absolute -inset-4 bg-blue-100/50 rounded-[3rem] -rotate-3 group-hover:rotate-0 transition-transform duration-500"></div>
            <img 
              src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=1000" 
              className="relative rounded-[3rem] shadow-2xl z-10 w-full aspect-video object-cover" 
              alt="Data visualization"
            />
          </div>
        </div>

        {/* Excellence Pillar 2 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
          <div className="order-2 lg:order-1 relative group">
            <div className="absolute -inset-4 bg-amber-100/50 rounded-[3rem] rotate-3 group-hover:rotate-0 transition-transform duration-500"></div>
            <img 
              src="https://images.unsplash.com/photo-1544016768-982d1554f0b9?auto=format&fit=crop&q=80&w=1000" 
              className="relative rounded-[3rem] shadow-2xl z-10 w-full aspect-video object-cover" 
              alt="Luxury airplane cabin interior"
            />
          </div>
          <div className="space-y-8 order-1 lg:order-2">
            <div className="w-16 h-16 bg-amber-50 rounded-[2rem] flex items-center justify-center text-amber-600 text-2xl shadow-inner border border-amber-100">
               <i className="fas fa-crown"></i>
            </div>
            <h2 className="text-4xl font-black text-slate-900 tracking-tight">Luxury and Reliability, Inseparable.</h2>
            <p className="text-lg text-slate-500 leading-relaxed font-medium">
              We partner exclusively with premium and reliability-ranked airlines. From the Changi terminal to Heathrow's VIP lounges, SkyBook ensures your journey is defined by comfort, safety, and prestige.
            </p>
            <div className="grid grid-cols-2 gap-8">
               <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100 shadow-sm">
                  <p className="text-2xl font-black text-slate-900">99.9%</p>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">Uptime Reliability</p>
               </div>
               <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100 shadow-sm">
                  <p className="text-2xl font-black text-slate-900">24/7</p>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">Platinum Support</p>
               </div>
            </div>
          </div>
        </div>
      </section>

      {/* Global Presence Section */}
      <section className="bg-slate-950 py-32 text-white overflow-hidden relative">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-blue-600/10 rounded-full blur-[100px] -mr-32 -mt-32"></div>
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
           <div className="space-y-10 relative z-10">
              <h2 className="text-5xl font-black tracking-tight leading-tight">Global Network. <br/> Local Heart.</h2>
              <p className="text-slate-400 text-lg leading-relaxed font-medium">
                SkyBook operates in over 190 countries, processing $50M+ in bookings monthly. Yet, we maintain a localized approach for every agency partner, offering dedicated account managers and localized currency processing.
              </p>
              <div className="flex gap-10">
                 <div>
                    <p className="text-4xl font-black text-blue-500 tracking-tighter">500+</p>
                    <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 mt-2">Airlines</p>
                 </div>
                 <div className="w-px h-16 bg-white/10"></div>
                 <div>
                    <p className="text-4xl font-black text-blue-500 tracking-tighter">1.2M</p>
                    <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 mt-2">Passengers / Year</p>
                 </div>
              </div>
           </div>
           <div className="relative">
              <div className="w-full aspect-square bg-blue-500/5 rounded-full border border-white/5 flex items-center justify-center p-12">
                 <div className="w-full h-full bg-blue-600/20 rounded-full blur-3xl absolute animate-pulse"></div>
                 <i className="fas fa-globe-americas text-[150px] opacity-10"></i>
                 <div className="absolute inset-0 flex items-center justify-center">
                    <div className="grid grid-cols-3 gap-10">
                       {[
                         { city: 'DEL', status: 'Online' },
                         { city: 'LHR', status: 'Online' },
                         { city: 'JFK', status: 'Online' },
                         { city: 'SIN', status: 'Online' },
                         { city: 'DXB', status: 'Online' },
                         { city: 'SYD', status: 'Online' },
                       ].map(node => (
                         <div key={node.city} className="flex flex-col items-center gap-2">
                            <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center border border-white/10 text-xs font-black">
                               {node.city}
                            </div>
                            <div className="flex items-center gap-1.5">
                               <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full shadow-[0_0_8px_#10b981]"></div>
                               <span className="text-[8px] font-black uppercase text-slate-500 tracking-widest">{node.status}</span>
                            </div>
                         </div>
                       ))}
                    </div>
                 </div>
              </div>
           </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="max-w-5xl mx-auto px-6 py-32 text-center space-y-10 relative z-10">
         <h2 className="text-5xl font-black text-slate-900 tracking-tight">Ready to elevate your travel?</h2>
         <p className="text-slate-500 text-lg font-medium max-w-xl mx-auto leading-relaxed">
            Join thousands of professionals and luxury travelers who have already shifted to the SkyBook ecosystem.
         </p>
         <div className="flex flex-col sm:flex-row items-center justify-center gap-6 pt-4">
            <button onClick={onJoin} className="w-full sm:w-auto px-12 py-5 bg-blue-600 text-white rounded-[2rem] font-black text-sm uppercase tracking-widest shadow-2xl shadow-blue-500/20 hover:scale-105 active:scale-95 transition-all">
               Get Started for Free
            </button>
            <button 
              onClick={onScheduleDemo}
              className="w-full sm:w-auto px-12 py-5 bg-white border-2 border-slate-100 text-slate-900 rounded-[2rem] font-black text-sm uppercase tracking-widest hover:bg-slate-50 transition-all hover:border-blue-200"
            >
               Schedule a Demo
            </button>
         </div>
      </section>

      <footer className="bg-slate-50 border-t border-slate-200 py-12 relative z-10">
        <div className="max-w-7xl mx-auto px-12 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white">
              <i className="fas fa-plane-departure text-sm"></i>
            </div>
            <span className="text-xl font-extrabold tracking-tight text-slate-900">SkyBook</span>
          </div>
          <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest">© 2025 SkyBook Global Operations. All rights reserved.</p>
        </div>
      </footer>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes bounce-subtle {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-5px); }
        }
        .animate-bounce-subtle {
          animation: bounce-subtle 3s ease-in-out infinite;
        }
      `}} />
    </div>
  );
};

export default WhySkyBookPage;