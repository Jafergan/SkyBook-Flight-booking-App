
import React, { useState, useEffect } from 'react';

interface MaintenancePageProps {
  onBack?: () => void;
  onViewStatus?: () => void;
  onContactSupport?: () => void;
  onAdminLogin?: () => void;
  onPrivacyPolicy?: () => void;
  onTermsOfService?: () => void;
  onHelpCenter?: () => void;
}

const MaintenancePage: React.FC<MaintenancePageProps> = ({ 
  onBack, 
  onViewStatus, 
  onContactSupport,
  onAdminLogin,
  onPrivacyPolicy,
  onTermsOfService,
  onHelpCenter
}) => {
  const [timeLeft, setTimeLeft] = useState(7200); // 2 hours in seconds
  const [statusMessage, setStatusMessage] = useState('Initializing System Check...');
  const [progress, setProgress] = useState(66);
  const [isSupportModalOpen, setIsSupportModalOpen] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => (prev > 0 ? prev - 1 : 0));
    }, 1000);

    const messages = [
      'Optimizing Neural Search Engines...',
      'Recalibrating Flight Data Feeds...',
      'Upgrading SSL Matrix Security...',
      'Synchronizing Global Node Cache...',
      'Finalizing API Connectivity Tests...'
    ];
    
    let msgIndex = 0;
    const msgInterval = setInterval(() => {
      setStatusMessage(messages[msgIndex]);
      msgIndex = (msgIndex + 1) % messages.length;
      setProgress(prev => Math.min(prev + 1, 98));
    }, 5000);

    return () => {
      clearInterval(timer);
      clearInterval(msgInterval);
    };
  }, []);

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50/50 animate-fadeIn overflow-hidden relative">
      <header className="h-16 bg-white border-b border-slate-100 px-8 flex items-center justify-between shadow-sm z-10">
        <div className="flex items-center gap-4">
          {onBack && (
            <button 
              onClick={onBack}
              className="flex items-center gap-2 text-slate-400 hover:text-blue-600 transition-all group font-black text-[10px] uppercase tracking-widest"
            >
              <i className="fas fa-arrow-left group-hover:-translate-x-1 transition-transform"></i>
              Back
            </button>
          )}
        </div>
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2 px-3 py-1 bg-orange-50 rounded-full border border-orange-100">
             <span className="w-2 h-2 bg-orange-500 rounded-full animate-pulse"></span>
             <span className="text-[8px] font-black text-orange-600 uppercase tracking-widest">Maintenance Active</span>
          </div>
        </div>
      </header>

      <div className="flex-1 flex flex-col items-center justify-center p-8 z-0">
        <div className="max-w-3xl w-full text-center space-y-10">
          <div className="relative mx-auto w-full max-w-lg aspect-video bg-white rounded-[3rem] overflow-hidden border border-slate-100 shadow-xl group">
            <img 
              src="https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&q=80&w=1000" 
              alt="Airplane in hangar" 
              className="w-full h-full object-cover opacity-90 group-hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900/40 to-transparent"></div>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center text-orange-600 shadow-2xl animate-pulse">
                <i className="fas fa-tools text-2xl"></i>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h1 className="text-5xl font-black text-slate-900 tracking-tight leading-none">System Maintenance in Progress</h1>
            <p className="text-slate-500 font-medium text-lg max-w-2xl mx-auto leading-relaxed">
              We're currently updating our flight tracking engine to serve you better. We apologize for the turbulence and appreciate your patience while we complete these necessary checks.
            </p>
          </div>

          <div className="bg-white p-10 rounded-[2.5rem] border border-slate-100 shadow-sm inline-block min-w-[380px] animate-slideUp relative overflow-hidden">
            <div className="absolute top-0 left-0 h-1 bg-gradient-to-r from-orange-400 to-blue-500 transition-all duration-1000" style={{ width: `${progress}%` }}></div>
            
            <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center mx-auto mb-6 shadow-inner">
              <i className="fas fa-clock"></i>
            </div>
            
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2">Estimated Restoration Time</p>
            <p className="text-5xl font-black text-slate-900 tracking-tighter mb-4">{formatTime(timeLeft)}</p>
            
            <div className="space-y-4">
              <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-blue-600 rounded-full transition-all duration-1000" style={{ width: `${progress}%` }}></div>
              </div>
              <div className="flex justify-between items-center px-1">
                 <p className="text-[10px] font-black text-blue-600 uppercase tracking-widest">{statusMessage}</p>
                 <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{progress}%</p>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-center gap-8 pt-4">
            <button 
              onClick={() => setIsSupportModalOpen(true)}
              className="flex items-center gap-2 text-xs font-black text-blue-600 uppercase tracking-widest hover:underline"
            >
              <i className="fas fa-headset"></i> Contact Support
            </button>
            <div className="h-4 w-px bg-slate-200"></div>
            <button 
              onClick={onViewStatus}
              className="flex items-center gap-2 text-xs font-black text-blue-600 uppercase tracking-widest hover:underline"
            >
              <i className="fas fa-globe"></i> View Status Page
            </button>
            {onAdminLogin && (
              <>
                <div className="h-4 w-px bg-slate-200"></div>
                <button 
                  onClick={onAdminLogin}
                  className="flex items-center gap-2 text-xs font-black text-slate-400 uppercase tracking-widest hover:text-slate-900 transition-colors"
                >
                  <i className="fas fa-shield-halved"></i> Admin Terminal
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      <footer className="pt-12 pb-12 border-t border-slate-200 flex flex-col items-center gap-6 bg-white z-10">
        <div className="flex gap-8 text-[10px] font-black text-slate-400 uppercase tracking-widest">
          <button onClick={onPrivacyPolicy} className="hover:text-slate-900 transition-colors">Privacy Policy</button>
          <button onClick={onTermsOfService} className="hover:text-slate-900 transition-colors">Terms of Service</button>
          <button onClick={onHelpCenter} className="hover:text-slate-900 transition-colors">Help Center</button>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 bg-blue-600 rounded flex items-center justify-center text-white text-[10px]">
            <i className="fas fa-plane-departure text-sm"></i>
          </div>
          <p className="text-[10px] font-bold text-slate-300 uppercase tracking-widest">SkyBook Management Systems</p>
        </div>
        <p className="text-[10px] font-bold text-slate-300">© 2025 SkyBook Management Systems. All rights reserved.</p>
      </footer>

      {/* Emergency Support Modal */}
      {isSupportModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
          <div 
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-md animate-fadeIn"
            onClick={() => setIsSupportModalOpen(false)}
          ></div>
          <div className="bg-white w-full max-w-md rounded-[3rem] shadow-2xl relative z-10 animate-slideUp p-10 border border-slate-100 overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-2 bg-blue-600"></div>
            <div className="flex justify-between items-start mb-8">
              <div className="space-y-1">
                <h3 className="text-2xl font-black text-slate-900 tracking-tight">Emergency Support</h3>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Protocol v5.0 Active</p>
              </div>
              <button 
                onClick={() => setIsSupportModalOpen(false)}
                className="w-10 h-10 bg-slate-50 text-slate-400 hover:text-red-500 rounded-xl flex items-center justify-center transition-all"
              >
                <i className="fas fa-times"></i>
              </button>
            </div>

            <div className="space-y-4">
              <div className="p-6 bg-blue-50 rounded-2xl border border-blue-100 flex items-center gap-4 hover:scale-[1.02] transition-transform cursor-pointer">
                <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-blue-600 shadow-sm">
                  <i className="fas fa-envelope"></i>
                </div>
                <div>
                  <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest mb-1">Direct Email</p>
                  <p className="text-sm font-black text-slate-900">ops-maintenance@skybook.com</p>
                </div>
              </div>

              <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100 flex items-center gap-4 hover:scale-[1.02] transition-transform cursor-pointer">
                <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-slate-600 shadow-sm">
                  <i className="fas fa-phone-alt"></i>
                </div>
                <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Hotline (24/7)</p>
                  <p className="text-sm font-black text-slate-900">+1 (800) SKY-BOOK-OPS</p>
                </div>
              </div>

              <div className="p-6 bg-emerald-50 rounded-2xl border border-emerald-100 flex items-center gap-4 hover:scale-[1.02] transition-transform cursor-pointer">
                <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-emerald-600 shadow-sm">
                  <i className="fab fa-whatsapp"></i>
                </div>
                <div>
                  <p className="text-[10px] font-black text-emerald-400 uppercase tracking-widest mb-1">WhatsApp Business</p>
                  <p className="text-sm font-black text-slate-900">Start Emergency Chat</p>
                </div>
              </div>
            </div>

            <p className="text-center text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-8 leading-relaxed px-4">
              Our support engineers are standing by to assist with critical bookings while the main interface is recalibrated.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default MaintenancePage;
