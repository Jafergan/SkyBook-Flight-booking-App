
import React, { useState, useEffect } from 'react';
import { getTravelIntelligence } from '../services/geminiService';

interface TravelInfoPageProps {
  onBack: () => void;
}

const TravelInfoPage: React.FC<TravelInfoPageProps> = ({ onBack }) => {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSearch = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!query.trim()) return;

    setLoading(true);
    setError(null);
    try {
      const result = await getTravelIntelligence(query);
      setData(result);
    } catch (err) {
      setError("Unable to retrieve neural data for this sector. Please check the identifier.");
    } finally {
      setLoading(false);
    }
  };

  // Default load
  useEffect(() => {
    setQuery('Singapore');
    const loadDefault = async () => {
      setLoading(true);
      try {
        const result = await getTravelIntelligence('Singapore');
        setData(result);
      } catch (err) {}
      setLoading(false);
    };
    loadDefault();
  }, []);

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-6 md:space-y-8 animate-fadeIn">
      <nav className="flex items-center gap-3 text-xs font-black uppercase tracking-widest text-slate-400">
        <button onClick={onBack} className="hover:text-blue-600 transition-colors">Dashboard</button>
        <i className="fas fa-chevron-right text-[8px]"></i>
        <span className="text-blue-600">Travel Info</span>
      </nav>

      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-end gap-6">
        <div>
          <button 
            onClick={onBack}
            className="mb-4 flex items-center gap-2 text-slate-400 hover:text-blue-600 transition-all group font-black text-[10px] uppercase tracking-widest w-fit"
          >
            <i className="fas fa-arrow-left group-hover:-translate-x-1 transition-transform"></i>
            Back to Travel Hub
          </button>
          <h1 className="text-3xl md:text-4xl font-black text-slate-900 tracking-tight leading-none">Destination Intelligence</h1>
          <p className="text-slate-500 font-medium mt-3 text-sm md:text-base">Real-time weather, advisories, and travel data for your clients.</p>
        </div>
        <form onSubmit={handleSearch} className="relative w-full lg:w-96">
           <i className="fas fa-search absolute left-5 top-1/2 -translate-y-1/2 text-slate-300"></i>
           <input 
            type="text" 
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search City or Country..." 
            className="w-full bg-white border border-slate-100 rounded-2xl py-4 pl-14 pr-16 text-sm font-bold outline-none shadow-sm focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 transition-all" 
           />
           <button 
            type="submit"
            disabled={loading}
            className="absolute right-2 top-2 bottom-2 bg-blue-600 text-white w-12 h-12 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/20 hover:bg-blue-700 transition-all disabled:opacity-50"
           >
              {loading ? <i className="fas fa-circle-notch animate-spin"></i> : <i className="fas fa-search"></i>}
           </button>
        </form>
      </div>

      {loading && !data && (
        <div className="flex flex-col items-center justify-center py-20 space-y-4">
           <div className="w-16 h-16 border-4 border-blue-100 border-t-blue-600 rounded-full animate-spin"></div>
           <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Scanning Global GDS Nodes...</p>
        </div>
      )}

      {error && (
        <div className="bg-red-50 border border-red-100 p-8 rounded-[2.5rem] flex items-center gap-4 text-red-600 animate-slideUp">
           <i className="fas fa-exclamation-triangle text-xl"></i>
           <p className="font-bold text-sm">{error}</p>
        </div>
      )}

      {data && (
        <div className={`space-y-8 animate-slideUp ${loading ? 'opacity-50 grayscale' : ''}`}>
          {/* Main Hero Card */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <div className="h-[400px] md:h-[450px] bg-slate-900 rounded-[3rem] p-8 md:p-12 relative overflow-hidden flex flex-col justify-between text-white shadow-2xl border border-white/5">
                <img 
                  src={`https://images.unsplash.com/photo-1524661135-423995f22d0b?auto=format&fit=crop&q=80&w=2000&q=${data.locationName}`} 
                  className="absolute inset-0 w-full h-full object-cover opacity-40 mix-blend-overlay" 
                  alt="" 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent"></div>
                
                <div className="relative z-10 flex justify-between items-start">
                  <div className="bg-white/10 backdrop-blur-xl px-5 py-2.5 rounded-full border border-white/20 flex items-center gap-3">
                    <i className="fas fa-map-marker-alt text-blue-400"></i>
                    <span className="text-[11px] font-black uppercase tracking-[0.2em]">{data.locationName}</span>
                  </div>
                  <div className="bg-emerald-500/10 backdrop-blur-md px-4 py-2 rounded-xl border border-emerald-500/20 flex items-center gap-2">
                     <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse"></span>
                     <span className="text-[9px] font-black uppercase tracking-widest text-emerald-400">Neural Sync Active</span>
                  </div>
                </div>

                <div className="relative z-10 space-y-4">
                  <p className="text-6xl md:text-8xl font-black tracking-tighter">{data.weather.temp}</p>
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-white/10 backdrop-blur-md rounded-2xl flex items-center justify-center text-blue-300 text-2xl border border-white/10">
                      <i className={`fas fa-${data.weather.icon}`}></i>
                    </div>
                    <div>
                      <p className="text-xl md:text-2xl font-black">{data.weather.condition}</p>
                      <p className="text-[10px] font-black text-blue-300/60 uppercase tracking-widest mt-0.5">Live Meteorological Feed</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Sidebar Advisories */}
            <div className="space-y-6">
               <div className="bg-white rounded-[2.5rem] border border-slate-100 p-8 space-y-6 shadow-sm">
                  <h3 className="text-xs font-black text-slate-900 uppercase tracking-widest flex items-center gap-3">
                    <i className="fas fa-shield-alt text-blue-600"></i> Safety Advisory
                  </h3>
                  <div className={`p-5 rounded-2xl border ${data.advisories.safetyLevel.toLowerCase().includes('high') || data.advisories.safetyLevel.toLowerCase().includes('warning') ? 'bg-red-50 border-red-100 text-red-700' : 'bg-emerald-50 border-emerald-100 text-emerald-700'}`}>
                     <p className="text-[10px] font-black uppercase tracking-widest mb-1">Status</p>
                     <p className="text-sm font-black">{data.advisories.safetyLevel}</p>
                  </div>
                  <p className="text-sm font-medium text-slate-500 leading-relaxed">
                    {data.advisories.alertText}
                  </p>
               </div>

               <div className="bg-gradient-to-br from-indigo-900 to-blue-900 rounded-[2.5rem] p-8 text-white space-y-4 shadow-xl shadow-blue-500/10">
                  <div className="flex items-center gap-3">
                    <i className="fas fa-lightbulb text-amber-400"></i>
                    <h3 className="text-xs font-black uppercase tracking-widest">Neural Insights</h3>
                  </div>
                  <ul className="space-y-4">
                    {data.insights.map((insight: string, i: number) => (
                      <li key={i} className="flex gap-3 text-sm font-medium leading-snug">
                         <span className="text-blue-400 mt-1">•</span>
                         {insight}
                      </li>
                    ))}
                  </ul>
               </div>
            </div>
          </div>

          {/* Essentials Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { label: 'Currency', value: data.essentials.currency, icon: 'fa-coins' },
              { label: 'Timezone', value: data.essentials.timezone, icon: 'fa-clock' },
              { label: 'Visa Policy', value: data.essentials.visa, icon: 'fa-passport' },
              { label: 'Language', value: data.essentials.language, icon: 'fa-language' },
            ].map((item, i) => (
              <div key={i} className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm flex items-center gap-5 group hover:border-blue-200 transition-all">
                <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center text-slate-400 group-hover:bg-blue-600 group-hover:text-white transition-all shadow-inner">
                  <i className={`fas ${item.icon}`}></i>
                </div>
                <div>
                  <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-0.5">{item.label}</p>
                  <p className="text-sm font-black text-slate-900">{item.value}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      
      {!data && !loading && (
        <div className="text-center py-20 space-y-6">
           <div className="w-24 h-24 bg-slate-100 rounded-[2.5rem] flex items-center justify-center text-slate-300 text-3xl mx-auto shadow-inner">
              <i className="fas fa-globe-americas"></i>
           </div>
           <div className="space-y-2">
             <h3 className="text-xl font-black text-slate-900">Enter a Sector Code</h3>
             <p className="text-slate-500 font-medium">Search for any city or country to initialize intelligence retrieval.</p>
           </div>
        </div>
      )}
    </div>
  );
};

export default TravelInfoPage;
