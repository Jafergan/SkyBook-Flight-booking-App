import React, { useState } from 'react';
import { UserRole } from '../types';

interface LoginPageProps {
  onLogin: (role: UserRole) => void;
  onJoinUs: () => void;
  onBack: () => void;
  onRecovery: () => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin, onJoinUs, onBack, onRecovery }) => {
  const [activeTab, setActiveTab] = useState<UserRole>(UserRole.USER);
  const [showPassword, setShowPassword] = useState(false);

  const getTabStyles = (role: UserRole) => {
    if (activeTab !== role) return 'text-slate-400 border-transparent hover:text-slate-600';
    
    switch (role) {
      case UserRole.ADMIN: return 'border-slate-900 text-slate-900';
      case UserRole.AGENT: return 'border-indigo-600 text-indigo-600';
      case UserRole.USER: return 'border-blue-600 text-blue-600';
      default: return '';
    }
  };

  const getCardTheme = () => {
    switch (activeTab) {
      case UserRole.ADMIN:
        return {
          bg: 'bg-slate-950',
          border: 'border-slate-800',
          accent: 'bg-slate-900',
          text: 'text-white',
          muted: 'text-slate-400',
          button: 'bg-white text-slate-950 hover:bg-slate-200',
          input: 'bg-slate-900 border-slate-800 text-white focus:border-slate-500 focus:ring-slate-500/10',
          header: 'from-slate-800 to-slate-950',
          icon: 'bg-white text-slate-950'
        };
      case UserRole.AGENT:
        return {
          bg: 'bg-white',
          border: 'border-slate-100',
          accent: 'bg-indigo-50/50',
          text: 'text-slate-900',
          muted: 'text-slate-500',
          button: 'bg-indigo-600 text-white hover:bg-indigo-700',
          input: 'bg-slate-50 border-slate-200 text-slate-800 focus:border-indigo-500 focus:ring-indigo-500/10',
          header: 'from-indigo-600 to-blue-600',
          icon: 'bg-indigo-600 text-white'
        };
      default:
        return {
          bg: 'bg-white',
          border: 'border-slate-100',
          accent: 'bg-blue-50/50',
          text: 'text-slate-900',
          muted: 'text-slate-500',
          button: 'bg-blue-600 text-white hover:bg-blue-700',
          input: 'bg-slate-50 border-slate-200 text-slate-800 focus:border-blue-500 focus:ring-blue-500/10',
          header: 'from-blue-600 to-indigo-600',
          icon: 'bg-blue-600 text-white'
        };
    }
  };

  const theme = getCardTheme();

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 font-sans p-6 transition-colors duration-500 relative overflow-hidden">
      
      <div className="absolute inset-0 pointer-events-none opacity-5">
         <div className="absolute top-0 left-0 w-full h-full" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, #1e293b 1px, transparent 0)', backgroundSize: '40px 40px' }}></div>
      </div>

      <div className="max-w-md w-full mx-auto flex-1 flex flex-col justify-center relative z-10">
        <button 
          onClick={onBack}
          className="mb-8 flex items-center gap-2 text-slate-400 hover:text-blue-600 transition-all group font-black text-[10px] uppercase tracking-widest w-fit"
        >
          <i className="fas fa-arrow-left group-hover:-translate-x-1 transition-transform"></i>
          Exit to Homepage
        </button>

        <div className={`w-full ${theme.bg} rounded-[2.5rem] shadow-2xl shadow-slate-200/50 border ${theme.border} overflow-hidden transition-all duration-500`}>
          <div className={`h-2 bg-gradient-to-r ${theme.header}`}></div>
          
          <div className="p-10 md:p-12">
            <div className="flex items-center gap-2 mb-10 justify-center">
              <div className={`w-10 h-10 ${theme.icon} rounded-xl flex items-center justify-center transition-all duration-500`}>
                <i className={`fas ${activeTab === UserRole.ADMIN ? 'fa-shield-halved' : 'fa-plane-departure'} text-lg`}></i>
              </div>
              <span className={`text-2xl font-black tracking-tight ${theme.text}`}>SkyBook</span>
            </div>

            <div className="text-center mb-10">
              <h1 className={`text-3xl font-black ${theme.text} mb-2`}>
                {activeTab === UserRole.ADMIN ? 'Terminal Access' : 'Welcome back'}
              </h1>
              <p className={`${theme.muted} font-medium leading-relaxed`}>
                {activeTab === UserRole.ADMIN 
                  ? 'Authorized personnel only. Accessing System Hub.' 
                  : 'Log in to manage your flight bookings.'}
              </p>
            </div>

            <div className="flex border-b border-slate-100/10 mb-8">
              <button
                onClick={() => setActiveTab(UserRole.USER)}
                className={`flex-1 pb-4 text-[10px] font-black uppercase tracking-widest transition-all border-b-2 ${getTabStyles(UserRole.USER)}`}
              >
                Traveler
              </button>
              <button
                onClick={() => setActiveTab(UserRole.AGENT)}
                className={`flex-1 pb-4 text-[10px] font-black uppercase tracking-widest transition-all border-b-2 ${getTabStyles(UserRole.AGENT)}`}
              >
                Agent
              </button>
              <button
                onClick={() => setActiveTab(UserRole.ADMIN)}
                className={`flex-1 pb-4 text-[10px] font-black uppercase tracking-widest transition-all border-b-2 ${getTabStyles(UserRole.ADMIN)}`}
              >
                Super Admin
              </button>
            </div>

            <div className="space-y-6">
              <div className="space-y-2">
                <label className={`text-xs font-black uppercase tracking-widest ${theme.muted}`}>
                  Email Address
                </label>
                <div className="relative">
                  <i className={`fas fa-user absolute left-5 top-1/2 -translate-y-1/2 text-[10px] ${theme.muted}`}></i>
                  <input
                    type="email"
                    placeholder={
                      activeTab === UserRole.ADMIN ? "admin@skybook.com" : 
                      activeTab === UserRole.AGENT ? "agent@company.com" : "traveler@skybook.com"
                    }
                    className={`w-full ${theme.input} rounded-2xl pl-12 pr-5 py-4 outline-none border transition-all font-medium text-sm`}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className={`text-xs font-black uppercase tracking-widest ${theme.muted}`}>Access Key</label>
                  <button 
                    onClick={onRecovery}
                    className={`text-[10px] font-black uppercase tracking-widest ${activeTab === UserRole.ADMIN ? 'text-slate-500' : 'text-blue-600'} hover:underline`}
                  >
                    Recovery
                  </button>
                </div>
                <div className="relative">
                  <i className="fas fa-lock absolute left-5 top-1/2 -translate-y-1/2 text-[10px] text-slate-300"></i>
                  <input
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    className={`w-full ${theme.input} rounded-2xl pl-12 pr-12 py-4 outline-none border transition-all font-medium text-sm`}
                  />
                  <button
                    onClick={() => setShowPassword(!showPassword)}
                    className={`absolute right-4 top-1/2 -translate-y-1/2 ${theme.muted} hover:text-blue-600 transition-colors`}
                  >
                    <i className={`far ${showPassword ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                  </button>
                </div>
              </div>

              <button
                onClick={() => onLogin(activeTab)}
                className={`w-full ${theme.button} font-black py-5 rounded-2xl shadow-xl transition-all transform hover:-translate-y-0.5 active:translate-y-0 uppercase tracking-[0.2em] text-xs`}
              >
                {activeTab === UserRole.ADMIN ? 'Initialize System' : 'Sign In'}
              </button>
            </div>

            <p className={`mt-10 text-center text-xs font-bold ${theme.muted}`}>
              Don't have an account?{' '}
              <button onClick={onJoinUs} className="text-blue-600 font-black hover:underline uppercase tracking-widest ml-1">Join us</button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;