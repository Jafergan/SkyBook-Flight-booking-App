import React, { useState } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface ReportsPageProps {
  onBack: () => void;
}

const ReportsPage: React.FC<ReportsPageProps> = ({ onBack }) => {
  const [isExporting, setIsExporting] = useState(false);

  const handleExportPDF = () => {
    setIsExporting(true);
    // Prepare DOM for high-fidelity export
    setTimeout(() => {
      window.print();
      setIsExporting(false);
    }, 1500);
  };

  const revenueData = [
    { name: 'Jan', revenue: 42000 },
    { name: 'Feb', revenue: 38000 },
    { name: 'Mar', revenue: 56000 },
    { name: 'Apr', revenue: 47000 },
    { name: 'May', revenue: 89000 },
    { name: 'Jun', revenue: 72000 },
  ];

  // Map colors to static strings to ensure Tailwind JIT extractions
  const getColorClasses = (color: string) => {
    switch (color) {
      case 'blue': return { bg: 'bg-blue-50', text: 'text-blue-600' };
      case 'indigo': return { bg: 'bg-indigo-50', text: 'text-indigo-600' };
      case 'emerald': return { bg: 'bg-emerald-50', text: 'text-emerald-600' };
      case 'violet': return { bg: 'bg-violet-50', text: 'text-violet-600' };
      default: return { bg: 'bg-slate-50', text: 'text-slate-600' };
    }
  };

  return (
    <div className="p-10 space-y-10 animate-fadeIn max-w-[1600px] mx-auto print:p-0">
      <style>{`
        @media print {
          aside, header, nav, button, .no-print { display: none !important; }
          body { background: white !important; padding: 0 !important; margin: 0 !important; }
          .print-full { width: 100% !important; border: none !important; box-shadow: none !important; }
          .recharts-responsive-container { width: 100% !important; }
          .rounded-[3rem], .rounded-[2.5rem] { border-radius: 1rem !important; }
        }
      `}</style>
      
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-end gap-6 no-print">
        <div>
          <button 
            onClick={onBack}
            className="mb-4 flex items-center gap-2 text-slate-400 hover:text-blue-600 transition-all group font-black text-[10px] uppercase tracking-widest w-fit"
          >
            <i className="fas fa-arrow-left group-hover:-translate-x-1 transition-transform"></i>
            Back to Intelligence Hub
          </button>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight leading-none">Enterprise Intelligence</h1>
          <p className="text-slate-500 font-medium mt-3 text-lg">Real-time visualization of global booking performance.</p>
        </div>
        <div className="flex gap-4 w-full lg:w-auto">
          <button 
            onClick={handleExportPDF}
            disabled={isExporting}
            className="flex-1 lg:flex-none px-8 py-4 bg-white border border-slate-200 rounded-2xl font-black text-xs uppercase tracking-widest text-slate-700 flex items-center justify-center gap-3 hover:bg-slate-50 transition-all shadow-sm"
          >
            {isExporting ? <i className="fas fa-circle-notch animate-spin text-blue-600"></i> : <i className="fas fa-file-pdf text-red-500"></i>}
            {isExporting ? 'PREPARING DOCUMENT...' : 'EXPORT PDF'}
          </button>
        </div>
      </div>

      <div className="space-y-10 print-full">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            { label: 'Annual Revenue', value: '$842,500', trend: '+14.2%', color: 'blue' },
            { label: 'Avg. Order Value', value: '$1,240', trend: '+5.1%', color: 'indigo' },
            { label: 'Conversion Rate', value: '18.4%', trend: '-1.2%', color: 'emerald' },
            { label: 'Customer LTV', value: '$4,800', trend: '+8.9%', color: 'violet' },
          ].map((kpi, i) => {
            const theme = getColorClasses(kpi.color);
            return (
              <div key={i} className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm">
                <div className="flex justify-between items-start mb-6">
                  <div className={`w-14 h-14 rounded-2xl ${theme.bg} flex items-center justify-center ${theme.text} text-xl shadow-inner`}>
                    <i className="fas fa-chart-bar"></i>
                  </div>
                  <span className={`text-[10px] font-black px-3 py-1.5 rounded-xl uppercase tracking-widest ${kpi.trend.startsWith('+') ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'}`}>
                    {kpi.trend}
                  </span>
                </div>
                <p className="text-xs font-black text-slate-400 uppercase tracking-widest mb-1">{kpi.label}</p>
                <p className="text-3xl font-black text-slate-900 tracking-tight">{kpi.value}</p>
              </div>
            );
          })}
        </div>

        <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm h-[500px]">
          <h3 className="text-xl font-black text-slate-900 tracking-tight mb-10 uppercase tracking-widest">Revenue Cycle Analysis</h3>
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={revenueData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 11, fontWeight: 900}} dy={15} />
              <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 11, fontWeight: 900}} />
              <Tooltip contentStyle={{ borderRadius: '24px', border: 'none', boxShadow: '0 25px 50px -12px rgb(0 0 0 / 0.15)' }} />
              <Area type="monotone" dataKey="revenue" stroke="#2563eb" strokeWidth={5} fillOpacity={0.1} fill="#2563eb" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
      
      <div className="hidden print:flex items-center justify-between pt-12 border-t border-slate-100">
         <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-blue-600 rounded-lg flex items-center justify-center text-white text-[10px]">
               <i className="fas fa-plane-departure"></i>
            </div>
            <span className="text-sm font-black text-slate-900">SkyBook Terminal Intelligence Report</span>
         </div>
         <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Date Generated: {new Date().toLocaleDateString()}</p>
      </div>
    </div>
  );
};

export default ReportsPage;