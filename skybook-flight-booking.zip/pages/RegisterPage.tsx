import React, { useState } from 'react';

interface RegisterPageProps {
  onRegister: (role: 'user' | 'agency') => void;
  onLogin: () => void;
  onBack: () => void;
  onLegal: (tab: 'Privacy Policy' | 'Terms of Service') => void;
  onEmailChange: (email: string) => void;
}

const RegisterPage: React.FC<RegisterPageProps> = ({ onRegister, onLogin, onBack, onLegal, onEmailChange }) => {
  const [role, setRole] = useState<'user' | 'agency'>('user');
  const [email, setEmail] = useState('');
  const [isInitializing, setIsInitializing] = useState(false);
  const [initStatus, setInitStatus] = useState('Initialize Profile');

  const handleRegister = () => {
    if (!email) return;
    
    setIsInitializing(true);
    setInitStatus('Securing Identity Node...');
    
    // Simulating a professional high-end backend handshake
    setTimeout(() => {
      setInitStatus('Synchronizing Neural Link...');
      setTimeout(() => {
        onEmailChange(email);
        onRegister(role);
      }, 1000);
    }, 1000);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 font-sans">
      <header className="flex items-center justify-between px-8 py-6 bg-white border-b border-slate-100 shadow-sm">
        <div className="flex items-center gap-6">
          <button onClick={onBack} className="text-slate-400 hover:text-blue-600 transition-colors flex items-center gap-2 group">
            <i className="fas fa-arrow-left group-hover:-translate-x-1 transition-transform"></i>
            <span className="text-[10px] font-black uppercase tracking-widest">Home</span>
          </button>
          <div className="flex items-center gap-2 cursor-pointer" onClick={onBack}>
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white">
              <i className="fas fa-plane-departure text-sm"></i>
            </div>
            <span className="text-xl font-extrabold tracking-tight text-slate-900">SkyBook</span>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-sm font-medium text-slate-500 hidden sm:inline">Already have an account?</span>
          <button
            onClick={onLogin}
            className="px-6 py-2.5 bg-blue-50 text-blue-600 font-bold rounded-xl text-sm hover:bg-blue-100 transition-colors"
          >
            Log in
          </button>
        </div>
      </header>

      <div className="flex-1 flex items-center justify-center p-6">
        <div className="max-w-2xl w-full">
          <div className="bg-white rounded-[2.5rem] shadow-2xl shadow-slate-200/50 border border-slate-100 p-10 md:p-12">
            <div className="mb-10 text-center">
              <div className="inline-block px-3 py-1 bg-blue-50 text-blue-600 rounded-lg text-[9px] font-black uppercase tracking-[0.2em] mb-4">Phase 1: Account Access</div>
              <h2 className="text-3xl font-black text-slate-900 mb-2 leading-tight tracking-tight">Begin Your Journey.</h2>
              <p className="text-slate-500 font-medium">Initialize your traveler profile and secure your terminal access.</p>
            </div>

            <div className="space-y-8">
              <div className="space-y-4">
                <label className="text-xs font-black text-slate-400 uppercase tracking-widest block text-center">Identity Role</label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <button
                    onClick={() => setRole('user')}
                    className={`flex flex-col items-center justify-center gap-2 p-6 rounded-3xl border-2 transition-all group ${
                      role === 'user' ? 'border-blue-600 bg-blue-50/50 text-blue-600' : 'border-slate-100 text-slate-400 hover:border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <i className="fas fa-user-astronaut text-lg"></i>
                      <span className="font-black uppercase tracking-widest text-xs">Traveler</span>
                    </div>
                    <p className={`text-[9px] font-bold text-center mt-2 leading-relaxed uppercase tracking-tighter ${role === 'user' ? 'text-blue-500' : 'text-slate-400 opacity-60'}`}>
                      Personal access for individual flight booking, AI concierge, and travel history analytics.
                    </p>
                  </button>
                  <button
                    onClick={() => setRole('agency')}
                    className={`flex flex-col items-center justify-center gap-2 p-6 rounded-3xl border-2 transition-all group ${
                      role === 'agency' ? 'border-blue-600 bg-blue-50/50 text-blue-600' : 'border-slate-100 text-slate-400 hover:border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <i className="fas fa-satellite text-lg"></i>
                      <span className="font-black uppercase tracking-widest text-xs">Agent</span>
                    </div>
                    <p className={`text-[9px] font-bold text-center mt-2 leading-relaxed uppercase tracking-tighter ${role === 'agency' ? 'text-blue-500' : 'text-slate-400 opacity-60'}`}>
                      Professional terminal for high-volume lead management, global inventory, and GDS node sync.
                    </p>
                  </button>
                </div>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">
                    Email Address
                  </label>
                  <input
                    required
                    type="email"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    placeholder={role === 'user' ? "e.g. traveler@skybook.aero" : "e.g. agency.id@skybook.aero"}
                    className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all font-bold text-slate-800"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Access Key</label>
                  <input
                    required
                    type="password"
                    placeholder="••••••••"
                    className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all font-bold text-slate-800"
                  />
                </div>
              </div>

              <button
                onClick={handleRegister}
                disabled={!email || isInitializing}
                className="w-full bg-blue-600 text-white font-black py-5 rounded-2xl shadow-xl shadow-blue-500/20 hover:bg-blue-700 transition-all transform hover:-translate-y-0.5 active:translate-y-0 uppercase tracking-widest text-xs flex items-center justify-center gap-3 disabled:opacity-70 disabled:cursor-not-allowed"
              >
                {isInitializing ? (
                  <>
                    <i className="fas fa-circle-notch animate-spin"></i>
                    {initStatus}
                  </>
                ) : (
                  <>
                    Initialize Profile <i className="fas fa-arrow-right"></i>
                  </>
                )}
              </button>

              <p className="text-[10px] text-center text-slate-400 font-bold px-8 leading-relaxed uppercase tracking-widest">
                By initializing account, you agree to our <button onClick={() => onLegal('Terms of Service')} className="text-blue-600 hover:underline">Terms</button> and <button onClick={() => onLegal('Privacy Policy')} className="text-blue-600 hover:underline">Privacy Policy</button>.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RegisterPage;