import React, { useState, useMemo, useEffect, useRef } from 'react';
import { MOCK_FLIGHTS } from '../constants';
import { Flight } from '../types';
import { searchFlightsWithAI } from '../services/geminiService';

interface FlightSearchProps {
  onSelectFlight: (flight: Flight) => void;
  onBack: () => void;
}

const FlightSearch: React.FC<FlightSearchProps> = ({ onSelectFlight, onBack }) => {
  const [origin, setOrigin] = useState('Mumbai (BOM)');
  const [destination, setDestination] = useState('Singapore (SIN)');
  const [departureDate, setDepartureDate] = useState(new Date().toISOString().split('T')[0]);
  const [passengers, setPassengers] = useState('1 Adult, Economy');
  const [priceRange, setPriceRange] = useState(2500);
  const [activeSort, setActiveSort] = useState('cheapest');
  const [selectedStops, setSelectedStops] = useState<number[]>([0, 1, 2]);
  const [selectedTimes, setSelectedTimes] = useState<string[]>(['Morning', 'Day', 'Evening']);
  const [selectedAirlines, setSelectedAirlines] = useState<string[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [flights, setFlights] = useState<Flight[]>(MOCK_FLIGHTS);
  const [expandedFlightId, setExpandedFlightId] = useState<string | null>(null);

  const dateInputRef = useRef<HTMLInputElement>(null);
  const todayStr = new Date().toISOString().split('T')[0];

  const getDepartureTimeCategory = (timeStr: string) => {
    const hour = parseInt(timeStr.split(':')[0]);
    if (hour >= 5 && hour < 12) return 'Morning';
    if (hour >= 12 && hour < 18) return 'Day';
    return 'Evening';
  };

  const getDurationInMinutes = (durationStr: string) => {
    const hours = parseInt(durationStr.split('h')[0]) || 0;
    const minutes = parseInt(durationStr.split(' ')[1] || '0');
    return hours * 60 + minutes;
  };

  const filteredFlights = useMemo(() => {
    return flights.filter(f => {
      const matchesPrice = f.price <= priceRange;
      const matchesStops = selectedStops.includes(f.stops >= 2 ? 2 : f.stops);
      const matchesTime = selectedTimes.includes(getDepartureTimeCategory(f.departureTime));
      const matchesAirline = selectedAirlines.length === 0 || selectedAirlines.includes(f.airline);
      return matchesPrice && matchesStops && matchesTime && matchesAirline;
    }).sort((a, b) => {
      if (activeSort === 'cheapest') return a.price - b.price;
      if (activeSort === 'fastest') {
        return getDurationInMinutes(a.duration) - getDurationInMinutes(b.duration);
      }
      if (activeSort === 'best_value') {
        const scoreA = a.price + (getDurationInMinutes(a.duration) / 5);
        const scoreB = b.price + (getDurationInMinutes(b.duration) / 5);
        return scoreA - scoreB;
      }
      return 0;
    });
  }, [flights, priceRange, selectedStops, selectedTimes, selectedAirlines, activeSort]);

  const uniqueAirlines = useMemo(() => {
    const names = Array.from(new Set(flights.map(f => f.airline)));
    return names.map(name => ({
      name,
      logo: flights.find(f => f.airline === name)?.airlineLogo || ''
    }));
  }, [flights]);

  const toggleStop = (stop: number) => {
    setSelectedStops(prev => prev.includes(stop) ? prev.filter(s => s !== stop) : [...prev, stop]);
  };

  const toggleTime = (time: string) => {
    setSelectedTimes(prev => prev.includes(time) ? prev.filter(t => t !== time) : [...prev, time]);
  };

  const toggleAirline = (airline: string) => {
    setSelectedAirlines(prev => prev.includes(airline) ? prev.filter(a => a !== airline) : [...prev, airline]);
  };

  const toggleDetails = (id: string) => {
    setExpandedFlightId(expandedFlightId === id ? null : id);
  };

  const resetFilters = () => {
    setPriceRange(5000);
    setSelectedStops([0, 1, 2]);
    setSelectedTimes(['Morning', 'Day', 'Evening']);
    setSelectedAirlines([]);
  };

  const handleModifySearch = async () => {
    setIsSearching(true);
    setExpandedFlightId(null);
    try {
      const dateObj = new Date(departureDate);
      const formattedDate = isNaN(dateObj.getTime()) 
        ? departureDate 
        : dateObj.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
      
      const results = await searchFlightsWithAI(origin, destination, formattedDate, passengers);
      setFlights(results);
      
      if (results && results.length > 0) {
        const maxPrice = Math.max(...results.map((f: any) => f.price)) + 500;
        setPriceRange(maxPrice);
      }
    } catch (err) {
      console.error("AI Search failed, falling back to mock", err);
    } finally {
      setIsSearching(false);
    }
  };

  useEffect(() => {
    handleModifySearch();
  }, []);

  const handleContainerClick = () => {
    if (dateInputRef.current) {
      // Robust trigger for modern browsers
      if ('showPicker' in HTMLInputElement.prototype) {
        try {
          dateInputRef.current.showPicker();
        } catch (e) {
          dateInputRef.current.focus();
        }
      } else {
        dateInputRef.current.focus();
      }
    }
  };

  return (
    <div className="bg-slate-50 min-h-screen">
      <style>{`
        @keyframes results-pulse {
          0% { opacity: 1; }
          50% { opacity: 0.5; transform: translateY(2px); }
          100% { opacity: 1; }
        }
        .searching-pulse {
          animation: results-pulse 1.2s ease-in-out infinite;
        }
        /* Make the native calendar trigger fill the entire area for desktop clicks */
        input[type="date"]::-webkit-calendar-picker-indicator {
          position: absolute;
          left: 0;
          top: 0;
          width: 100%;
          height: 100%;
          margin: 0;
          padding: 0;
          cursor: pointer;
          opacity: 0;
        }
        input[type="date"]::-webkit-inner-spin-button {
          display: none;
          -webkit-appearance: none;
        }
      `}</style>

      {/* Top Search Bar */}
      <div className="bg-white border-b border-slate-200 sticky top-0 z-30 px-6 py-4 shadow-sm">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-end gap-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 flex-1 w-full">
            <div className="space-y-1.5">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">From</label>
              <div className="flex items-center gap-3 bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5">
                <i className="fas fa-plane-departure text-slate-400 text-sm"></i>
                <input type="text" value={origin} onChange={e => setOrigin(e.target.value)} className="bg-transparent font-bold text-slate-700 outline-none w-full text-sm" />
              </div>
            </div>
            <div className="space-y-1.5 relative">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">To</label>
              <div className="flex items-center gap-3 bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5">
                <i className="fas fa-plane-arrival text-slate-400 text-sm"></i>
                <input type="text" value={destination} onChange={e => setDestination(e.target.value)} className="bg-transparent font-bold text-slate-700 outline-none w-full text-sm" />
              </div>
              <button className="absolute -left-5 top-1/2 translate-y-1 w-8 h-8 bg-white border border-slate-200 rounded-full flex items-center justify-center text-slate-400 shadow-sm z-10 hidden md:flex">
                <i className="fas fa-exchange-alt text-[10px]"></i>
              </button>
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Departure</label>
              <div 
                onClick={handleContainerClick}
                className="flex items-center gap-3 bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 cursor-pointer hover:border-blue-300 transition-all group h-[46px] relative"
              >
                <i className="far fa-calendar text-slate-400 text-sm group-hover:text-blue-500 transition-colors pointer-events-none"></i>
                <div className="flex-1 flex flex-col justify-center pointer-events-none">
                  <span className="font-bold text-slate-700 text-sm leading-none">
                    {departureDate ? new Date(departureDate).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : 'Choose Date'}
                  </span>
                </div>
                {/* 
                  Native date input is positioned to cover the whole container.
                  The CSS override in the style tag above makes it robust on desktop Chrome.
                */}
                <input 
                  ref={dateInputRef}
                  type="date" 
                  min={todayStr}
                  value={departureDate} 
                  onChange={e => setDepartureDate(e.target.value)} 
                  className="absolute inset-0 opacity-0 cursor-pointer w-full h-full z-20" 
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Passengers & Class</label>
              <div className="flex items-center gap-3 bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5">
                <i className="far fa-user text-slate-400 text-sm"></i>
                <input type="text" value={passengers} onChange={e => setPassengers(e.target.value)} className="bg-transparent font-bold text-slate-700 outline-none w-full text-sm" />
              </div>
            </div>
          </div>
          <button 
            onClick={handleModifySearch}
            disabled={isSearching}
            className={`bg-blue-600 text-white font-black px-8 py-3 rounded-xl shadow-lg hover:bg-blue-700 transition-all flex items-center gap-3 uppercase tracking-widest text-[11px] h-[46px] min-w-[120px] justify-center ${isSearching ? 'opacity-80 cursor-not-allowed' : ''}`}
          >
            {isSearching ? (
              <>
                <i className="fas fa-circle-notch animate-spin"></i> Syncing
              </>
            ) : (
              <>
                <i className="fas fa-search"></i> Modify
              </>
            )}
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8 flex flex-col lg:flex-row gap-8">
        {/* Filter Sidebar */}
        <aside className="w-full lg:w-72 space-y-8 shrink-0">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-8 shadow-sm">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-black text-slate-800">Filters</h3>
              <button onClick={resetFilters} className="text-blue-600 text-[11px] font-bold hover:underline">Reset</button>
            </div>

            {/* Price Range */}
            <div className="space-y-5">
              <p className="text-[11px] font-black text-slate-800 uppercase">Price Range</p>
              <div className="space-y-2">
                <input type="range" min="0" max="10000" step="100" value={priceRange} onChange={e => setPriceRange(parseInt(e.target.value))} className="w-full h-1.5 bg-slate-100 rounded-full appearance-none cursor-pointer accent-blue-600" />
                <div className="flex justify-between text-[11px] font-bold text-slate-400">
                  <span>$0</span>
                  <span>${priceRange.toLocaleString()}</span>
                </div>
              </div>
            </div>

            {/* Stops */}
            <div className="space-y-4">
              <p className="text-[11px] font-black text-slate-800 uppercase">Stops</p>
              <div className="space-y-3">
                {[
                  { label: 'Non-stop', value: 0 },
                  { label: '1 Stop', value: 1 },
                  { label: '2+ Stops', value: 2 }
                ].map(stop => (
                  <label key={stop.value} className="flex items-center justify-between cursor-pointer group">
                    <div className="flex items-center gap-3">
                      <div onClick={() => toggleStop(stop.value)} className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-all ${selectedStops.includes(stop.value) ? 'bg-blue-600 border-blue-600' : 'border-slate-200 group-hover:border-blue-400'}`}>
                        {selectedStops.includes(stop.value) && <i className="fas fa-check text-[10px] text-white"></i>}
                      </div>
                      <span className="text-xs font-semibold text-slate-600">{stop.label}</span>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            {/* Departure Time */}
            <div className="space-y-4">
              <p className="text-[11px] font-black text-slate-800 uppercase">Departure Time</p>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { label: 'Morning', icon: 'fa-sun' },
                  { label: 'Day', icon: 'fa-sun-bright' },
                  { label: 'Evening', icon: 'fa-moon' }
                ].map(time => (
                  <button 
                    key={time.label} 
                    onClick={() => toggleTime(time.label)}
                    className={`flex flex-col items-center gap-2 p-3 rounded-xl border-2 transition-all ${selectedTimes.includes(time.label) ? 'border-blue-600 bg-blue-50 text-blue-600' : 'border-slate-100 text-slate-400 hover:border-slate-200'}`}
                  >
                    <i className={`fas ${time.icon} text-sm`}></i>
                    <span className="text-[9px] font-black uppercase">{time.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Airlines */}
            {uniqueAirlines.length > 0 && (
              <div className="space-y-4">
                <p className="text-[11px] font-black text-slate-800 uppercase">Airlines</p>
                <div className="space-y-3">
                  {uniqueAirlines.map(airline => (
                    <label key={airline.name} className="flex items-center gap-3 cursor-pointer group">
                      <div onClick={() => toggleAirline(airline.name)} className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-all ${selectedAirlines.includes(airline.name) ? 'bg-blue-600 border-blue-600' : 'border-slate-200 group-hover:border-blue-400'}`}>
                        {selectedAirlines.includes(airline.name) && <i className="fas fa-check text-[10px] text-white"></i>}
                      </div>
                      <div className="flex items-center gap-2 flex-1">
                        <span className="text-xs font-semibold text-slate-600 truncate max-w-[150px]">{airline.name}</span>
                      </div>
                    </label>
                  ))}
                </div>
              </div>
            )}
          </div>
        </aside>

        {/* Results Section */}
        <main className={`flex-1 space-y-6 ${isSearching ? 'searching-pulse' : ''}`}>
          {/* Sorting Tabs */}
          <div className="flex bg-white rounded-xl border border-slate-200 p-1 shadow-sm">
            <button 
              onClick={() => setActiveSort('cheapest')} 
              className={`flex-1 py-3 px-4 rounded-lg text-xs font-black uppercase tracking-widest transition-all ${activeSort === 'cheapest' ? 'bg-blue-600 text-white' : 'text-slate-500 hover:bg-slate-50'}`}
            >
              Cheapest
            </button>
            <button 
              onClick={() => setActiveSort('fastest')} 
              className={`flex-1 py-3 px-4 rounded-lg text-xs font-black uppercase tracking-widest transition-all ${activeSort === 'fastest' ? 'bg-blue-600 text-white' : 'text-slate-500 hover:bg-slate-50'}`}
            >
              Fastest
            </button>
            <button 
              onClick={() => setActiveSort('best_value')}
              className={`flex-1 py-3 px-4 rounded-lg text-xs font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2 ${activeSort === 'best_value' ? 'bg-blue-600 text-white' : 'text-slate-500 hover:bg-slate-50'}`}
            >
              Best Value <i className={`fas fa-star ${activeSort === 'best_value' ? 'text-white' : 'text-amber-400'}`}></i>
            </button>
          </div>

          <p className="text-xs font-bold text-slate-400">
            {isSearching ? 'Analyzing neural GDS nodes...' : `Showing ${filteredFlights.length} perfect matches for your route`}
          </p>

          <div className="space-y-4">
            {filteredFlights.map(flight => (
              <div key={flight.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all overflow-hidden group">
                <div className="p-8 flex flex-col md:flex-row items-center gap-8">
                  {/* Airline Info */}
                  <div className="flex items-center gap-6 md:w-56 shrink-0">
                    <div className="w-14 h-14 bg-slate-50 rounded-xl p-2.5 flex items-center justify-center border border-slate-100 shadow-inner">
                      <img src={flight.airlineLogo} className="w-full h-full object-contain" alt="" onError={(e) => { (e.target as HTMLImageElement).src = 'https://cdn-icons-png.flaticon.com/512/984/984233.png' }} />
                    </div>
                    <div>
                      <h4 className="text-sm md:text-base font-black text-slate-800 leading-tight">{flight.airline}</h4>
                      <p className="text-[10px] font-bold text-slate-400 mt-0.5">{flight.flightNumber} • {flight.aircraft}</p>
                    </div>
                  </div>

                  {/* Flight Times & Timeline */}
                  <div className="flex-1 flex items-center justify-between gap-4 w-full">
                    <div className="text-center md:text-left min-w-[70px]">
                      <p className="text-xl md:text-2xl font-black text-slate-800">{flight.departureTime}</p>
                      <p className="text-xs font-black text-blue-600 uppercase">{flight.departure}</p>
                    </div>

                    <div className="flex-1 flex flex-col items-center max-w-[140px] md:max-w-[200px]">
                      <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest mb-2">{flight.duration}</span>
                      <div className="w-full flex items-center gap-2">
                        <div className="w-1.5 h-1.5 rounded-full bg-slate-200"></div>
                        <div className="h-px bg-slate-200 flex-1 relative">
                          <i className="fas fa-plane absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-blue-500 text-[10px]"></i>
                        </div>
                        <div className="w-1.5 h-1.5 rounded-full bg-slate-200"></div>
                      </div>
                      <span className={`text-[10px] font-black uppercase mt-2 ${flight.stops === 0 ? 'text-emerald-500' : 'text-orange-500'}`}>
                        {flight.stops === 0 ? 'Non-stop' : `${flight.stops} Stop${flight.stopLocation ? ` (${flight.stopLocation})` : ''}`}
                      </span>
                    </div>

                    <div className="text-center md:text-right min-w-[70px]">
                      <p className="text-xl md:text-2xl font-black text-slate-800">{flight.arrivalTime}</p>
                      <p className="text-xs font-black text-blue-600 uppercase">{flight.arrival}</p>
                    </div>
                  </div>

                  {/* Pricing & Actions */}
                  <div className="flex items-center justify-between md:flex-col md:items-end gap-4 shrink-0 md:w-32">
                    <div className="text-right">
                      <p className="text-2xl md:text-3xl font-black text-slate-800">${flight.price.toLocaleString()}</p>
                      <p className="text-[10px] font-black text-emerald-500 uppercase tracking-widest mt-0.5">Net: ${flight.netPrice.toLocaleString()}</p>
                    </div>
                    <button onClick={() => onSelectFlight(flight)} className="bg-blue-600 text-white font-black px-6 py-2.5 rounded-xl hover:bg-blue-700 transition-all text-[11px] uppercase tracking-widest shadow-md">
                      Book Now
                    </button>
                  </div>
                </div>

                {/* Card Footer & Detail Expansion */}
                <div className="px-8 py-3 bg-slate-50/50 border-t border-slate-100 flex flex-col gap-4">
                  <div className="flex items-center justify-between">
                    <div className="flex gap-4">
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-3 py-1 bg-white border border-slate-200 rounded-lg">
                        {flight.refundable}
                      </span>
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-3 py-1 bg-white border border-slate-200 rounded-lg">
                        {flight.class}
                      </span>
                    </div>
                    <button 
                      onClick={() => toggleDetails(flight.id)}
                      className="text-[10px] font-black text-blue-600 uppercase tracking-widest flex items-center gap-1.5 hover:underline"
                    >
                      {expandedFlightId === flight.id ? 'Hide Details' : 'Flight Details'} 
                      <i className={`fas fa-chevron-down text-[8px] transition-transform ${expandedFlightId === flight.id ? 'rotate-180' : ''}`}></i>
                    </button>
                  </div>

                  {/* Expanded Detail Pane */}
                  {expandedFlightId === flight.id && (
                    <div className="py-6 border-t border-slate-100 animate-slideUp space-y-8">
                       <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                          <div className="space-y-4">
                             <div className="flex items-center gap-3">
                                <i className="fas fa-suitcase text-blue-500 text-xs"></i>
                                <h5 className="text-[10px] font-black text-slate-900 uppercase tracking-widest">Baggage Policy</h5>
                             </div>
                             <div className="space-y-2">
                                <div className="flex justify-between text-xs">
                                   <span className="text-slate-400 font-bold">Cabin Baggage</span>
                                   <span className="text-slate-700 font-black">{flight.cabin}</span>
                                </div>
                                <div className="flex justify-between text-xs">
                                   <span className="text-slate-400 font-bold">Check-in</span>
                                   <span className="text-slate-700 font-black">{flight.baggage}</span>
                                </div>
                             </div>
                          </div>

                          <div className="space-y-4">
                             <div className="flex items-center gap-3">
                                <i className="fas fa-utensils text-blue-500 text-xs"></i>
                                <h5 className="text-[10px] font-black text-slate-900 uppercase tracking-widest">In-Flight Services</h5>
                             </div>
                             <div className="space-y-2">
                                <div className="flex justify-between text-xs">
                                   <span className="text-slate-400 font-bold">Meal Service</span>
                                   <span className={`font-black ${flight.meal ? 'text-emerald-500' : 'text-slate-700'}`}>
                                      {flight.meal ? 'Complimentary' : 'Purchase Required'}
                                   </span>
                                </div>
                                <div className="flex justify-between text-xs">
                                   <span className="text-slate-400 font-bold">Entertainment</span>
                                   <span className="text-slate-700 font-black">Wi-Fi & Streaming</span>
                                </div>
                             </div>
                          </div>

                          <div className="space-y-4">
                             <div className="flex items-center gap-3">
                                <i className="fas fa-info-circle text-blue-500 text-xs"></i>
                                <h5 className="text-[10px] font-black text-slate-900 uppercase tracking-widest">Technical Spec</h5>
                             </div>
                             <div className="space-y-2">
                                <div className="flex justify-between text-xs">
                                   <span className="text-slate-400 font-bold">Aircraft</span>
                                   <span className="text-slate-700 font-black truncate max-w-[120px]">{flight.aircraft}</span>
                                </div>
                                <div className="flex justify-between text-xs">
                                   <span className="text-slate-700 font-black uppercase">{flight.type}</span>
                                </div>
                             </div>
                          </div>
                       </div>

                       <div className="p-4 bg-white border border-slate-100 rounded-2xl flex items-center gap-4">
                          <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center text-blue-600 shadow-inner">
                             <i className="fas fa-shield-halved text-xs"></i>
                          </div>
                          <div>
                             <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Fare Integrity Note</p>
                             <p className="text-[11px] font-medium text-slate-600 leading-relaxed">
                                This fare is ticketed via the {flight.airline} GDS node. Cancellation fees apply as per {flight.refundable} policy. Neural Search has verified this as the current lowest entry price for this sector.
                             </p>
                          </div>
                       </div>
                    </div>
                  )}
                </div>
              </div>
            ))}

            {filteredFlights.length === 0 && !isSearching && (
              <div className="bg-white rounded-2xl p-16 text-center border border-slate-200 shadow-sm">
                <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-300">
                  <i className="fas fa-search text-2xl"></i>
                </div>
                <h3 className="text-lg font-black text-slate-800">No matches found</h3>
                <p className="text-slate-500 text-sm mt-2">Adjust your filters or try a different GDS query.</p>
                <button onClick={resetFilters} className="mt-6 px-6 py-2.5 bg-blue-50 text-blue-600 rounded-xl font-bold text-xs uppercase tracking-widest">Clear All Filters</button>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
};

export default FlightSearch;