
import React, { useState } from 'react';
import { Flight } from '../types';

interface BookingSummaryPageProps {
  flight: Flight;
  onConfirm: () => void;
  onBack: () => void;
}

const BookingSummaryPage: React.FC<BookingSummaryPageProps> = ({ flight, onConfirm, onBack }) => {
  const [coupon, setCoupon] = useState('');
  const [applied, setApplied] = useState(false);

  const baseFare = flight.price * 2;
  const taxes = 185;
  const fee = 15;
  const discount = applied ? 25 : 0;
  const grandTotal = baseFare + taxes + fee - discount;

  return (
    <div className="px-4 md:px-8 lg:px-10 py-6 md:py-8 lg:py-10 space-y-6 md:space-y-8 animate-fadeIn max-w-6xl mx-auto">
       <div className="flex flex-col gap-4">
          <nav className="flex items-center gap-3 text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">
            <button onClick={onBack} className="hover:text-blue-600 transition-colors">Passenger Selection</button>
            <i className="fas fa-chevron-right text-[8px] opacity-30"></i>
            <span className="text-blue-600">Review & Settlement</span>
          </nav>
          <div>
            <h1 className="text-2xl md:text-3xl lg:text-4xl font-black text-slate-900 tracking-tight leading-none">Trip Validation</h1>
            <p className="text-slate-500 font-medium mt-2 md:mt-3 text-sm md:text-lg">Finalize the flight itinerary and verify the financial breakdown.</p>
          </div>
       </div>

       <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Flight Details & Passengers */}
          <div className="lg:col-span-2 space-y-6">
             <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-xl shadow-blue-500/5 overflow-hidden">
                <div className="p-8 flex items-center justify-between border-b border-slate-50">
                   <div className="flex items-center gap-6">
                      <div>
                         <h4 className="text-lg font-black text-slate-900 leading-tight">{flight.airline}</h4>
                         <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">{flight.flightNumber} • {flight.aircraft}</p>
                      </div>
                   </div>
                   <span className="bg-emerald-50 text-emerald-600 px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest border border-emerald-100 flex items-center gap-2">
                      <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
                      Seat Inventory Reserved
                   </span>
                </div>

                <div className="px-10 py-10 grid grid-cols-3 gap-8 items-center relative">
                   <div className="text-center md:text-left">
                      <p className="text-3xl md:text-4xl font-black text-slate-900 tracking-tighter">{flight.departureTime}</p>
                      <p className="text-sm font-black text-slate-800 mt-1 uppercase tracking-tighter">{flight.departure}</p>
                      <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-1">Confirmed Port</p>
                   </div>
                   <div className="flex flex-col items-center justify-center">
                      <span className="text-[9px] font-black text-slate-300 uppercase tracking-[0.2em] mb-4">{flight.duration} Non-stop</span>
                      <div className="w-full flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-slate-200"></div>
                        <div className="h-[2px] bg-slate-100 flex-1 relative">
                           <i className="fas fa-plane absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-blue-500 text-[10px]"></i>
                        </div>
                        <div className="w-2 h-2 rounded-full bg-slate-200"></div>
                      </div>
                   </div>
                   <div className="text-center md:text-right">
                      <p className="text-3xl md:text-4xl font-black text-slate-900 tracking-tighter">{flight.arrivalTime}</p>
                      <p className="text-sm font-black text-slate-800 mt-1 uppercase tracking-tighter">{flight.arrival}</p>
                      <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-1">Arrival Port</p>
                   </div>
                </div>

                <div className="h-40 relative">
                   <img src="https://images.unsplash.com/photo-1524661135-423995f22d0b?auto=format&fit=crop&q=80&w=1000" className="w-full h-full object-cover opacity-60" alt="Map" />
                   <div className="absolute inset-0 bg-gradient-to-t from-white via-white/10 to-transparent"></div>
                   <div className="absolute bottom-6 left-1/2 -translate-x-1/2 bg-white/90 backdrop-blur-md px-6 py-2 rounded-full shadow-lg border border-slate-200 flex items-center gap-3">
                      <div className="w-2 h-2 bg-emerald-500 rounded-full animate-ping"></div>
                      <span className="text-[9px] font-black uppercase tracking-widest text-slate-800">Secure Vector Tracking Active</span>
                   </div>
                </div>

                <div className="p-8 bg-slate-50/50 border-t border-slate-100">
                   <h5 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-6">Manifest Identity</h5>
                   <div className="flex items-center gap-4 p-5 bg-white rounded-2xl border border-slate-100 shadow-sm">
                      <div>
                         <p className="text-sm font-black text-slate-900">Rahul Verma</p>
                         <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Primary Traveler • Seat Selection: Pending</p>
                      </div>
                   </div>
                </div>
             </div>
          </div>

          {/* Right Column - Pricing */}
          <div className="space-y-6">
             <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-2xl shadow-blue-500/5 overflow-hidden">
                <div className="p-8 border-b border-slate-100 bg-slate-50/30">
                   <h3 className="text-xs font-black text-slate-900 uppercase tracking-widest">Financial Ledger</h3>
                </div>
                <div className="p-8 space-y-5">
                   <div className="flex justify-between items-center text-sm font-bold">
                      <span className="text-slate-400">Base Fare (x2)</span>
                      <span className="text-slate-900 tracking-tight">${baseFare.toLocaleString()}</span>
                   </div>
                   <div className="flex justify-between items-center text-sm font-bold">
                      <span className="text-slate-400">Taxes & Port Fees</span>
                      <span className="text-slate-900 tracking-tight">+${taxes}</span>
                   </div>
                   <div className="flex justify-between items-center text-sm font-bold pb-2">
                      <span className="text-slate-400">Merchant Service Fee</span>
                      <span className="text-slate-900 tracking-tight">+${fee}</span>
                   </div>
                   
                   <div className="py-5 border-y border-slate-100">
                      <div className="flex gap-2">
                         <div className="flex-1 relative">
                            <i className="fas fa-tag absolute left-4 top-1/2 -translate-y-1/2 text-emerald-500 text-xs opacity-40"></i>
                            <input 
                              type="text" 
                              placeholder="PROMO CODE" 
                              className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3.5 pl-10 pr-4 outline-none focus:border-blue-500 focus:bg-white transition-all text-[10px] font-black tracking-widest"
                              value={coupon}
                              onChange={(e) => setCoupon(e.target.value.toUpperCase())}
                            />
                            {applied && <i className="fas fa-check-circle absolute right-4 top-1/2 -translate-y-1/2 text-emerald-500 animate-fadeIn"></i>}
                         </div>
                         <button 
                          onClick={() => setApplied(!applied)}
                          className={`px-6 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${applied ? 'bg-emerald-500 text-white shadow-lg' : 'bg-slate-900 text-white hover:bg-black'}`}
                         >
                           {applied ? 'Active' : 'Apply'}
                         </button>
                      </div>
                      {applied && (
                         <div className="flex justify-between items-center text-[10px] font-black text-emerald-600 uppercase tracking-widest mt-4 px-2 animate-slideUp">
                           <span>Seasonal Benefit</span>
                           <span>-${discount}.00</span>
                         </div>
                      )}
                   </div>

                   <div className="flex justify-between items-end pt-5">
                      <div>
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Total Settlement</p>
                        <p className="text-4xl font-black text-slate-900 tracking-tighter">${grandTotal.toLocaleString()}</p>
                      </div>
                      <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600 shadow-inner">
                         <i className="fas fa-shield-check"></i>
                      </div>
                   </div>

                   <button 
                    onClick={onConfirm}
                    className="w-full bg-blue-600 text-white font-black py-5 rounded-2xl shadow-xl shadow-blue-500/20 hover:bg-blue-700 transition-all flex items-center justify-center gap-3 uppercase tracking-widest text-[10px] mt-4 active:scale-[0.98]"
                   >
                     Initialize Secure Payment <i className="fas fa-arrow-right"></i>
                   </button>
                </div>
             </div>

             <div className="p-4 flex items-center justify-center gap-3 text-slate-300">
                <i className="fas fa-lock text-[10px]"></i>
                <span className="text-[9px] font-black uppercase tracking-[0.2em]">SSL Encrypted • PCI Compliant</span>
             </div>
          </div>
       </div>
    </div>
  );
};

export default BookingSummaryPage;
