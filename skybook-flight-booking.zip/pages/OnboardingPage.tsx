import React, { useState, useRef } from 'react';

interface OnboardingPageProps {
  onComplete: () => void;
}

const OnboardingPage: React.FC<OnboardingPageProps> = ({ onComplete }) => {
  const [step, setStep] = useState(1);
  const [businessType, setBusinessType] = useState<'agency' | 'user'>('agency');
  const [currency, setCurrency] = useState('INR - Indian Rupee');
  const [markup, setMarkup] = useState('500');
  // airlines state is initialized but not used in the UI provided
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [airlines, setAirlines] = useState<string[]>(['IndiGo', 'Emirates']);
  const [brandColor, setBrandColor] = useState('#2563eb');
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Dynamic state for team invitations
  const [teamInvites, setTeamInvites] = useState([
    { id: 1, email: '', role: 'Agent Access' },
    { id: 2, email: '', role: 'Agent Access' },
    { id: 3, email: '', role: 'Agent Access' }
  ]);

  const addInvite = () => {
    setTeamInvites([...teamInvites, { id: Date.now(), email: '', role: 'Agent Access' }]);
  };

  const removeInvite = (id: number) => {
    if (teamInvites.length > 1) {
      setTeamInvites(teamInvites.filter(inv => inv.id !== id));
    }
  };

  const handleFile = (file: File) => {
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setLogoPreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const onDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const nextStep = () => {
    if (step === 1 && businessType === 'user') {
      setStep(4);
    } else if (step < 4) {
      setStep(step + 1);
    } else {
      onComplete();
    }
  };

  const prevStep = () => {
    if (step === 4 && businessType === 'user') {
      setStep(1);
    } else if (step > 1) {
      setStep(step - 1);
    }
  };

  const renderStepContent = () => {
    switch (step) {
      case 1:
        return (
          <div className="space-y-8 animate-fadeIn">
            <h1 className="text-4xl font-black text-slate-900 mb-4 leading-tight">
              {businessType === 'agency' 
                ? "Welcome! Let's get your agency ready." 
                : "Welcome! Let's get your journey ready."}
            </h1>
            <p className="text-slate-500 font-medium text-lg mb-10 max-w-2xl">
              {businessType === 'agency' 
                ? "Your basic business settings and financial default." 
                : "Your personal travel preferences and regional settings."}
            </p>
            <div className="space-y-8">
              <div className="space-y-3">
                <label className="text-sm font-bold text-slate-800">Business Type</label>
                <div className="flex p-1.5 bg-slate-100 rounded-2xl">
                  <button onClick={() => setBusinessType('agency')} className={`flex-1 py-3 text-sm font-bold rounded-xl transition-all ${businessType === 'agency' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-500'}`}>Travel Agency</button>
                  <button onClick={() => setBusinessType('user')} className={`flex-1 py-3 text-sm font-bold rounded-xl transition-all ${businessType === 'user' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-500'}`}>User Login</button>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-3">
                  <label className="text-sm font-bold text-slate-800">Default Currency</label>
                  <select value={currency} onChange={(e) => setCurrency(e.target.value)} className="w-full bg-white border border-slate-200 rounded-2xl py-4 px-4 focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all font-medium text-slate-800">
                    <option>INR - Indian Rupee</option>
                    <option>USD - US Dollar</option>
                    <option>EUR - Euro</option>
                  </select>
                </div>
                <div className="space-y-3">
                  <label className="text-sm font-bold text-slate-800">Standard Markup</label>
                  <input type="text" value={markup} onChange={(e) => setMarkup(e.target.value)} className="w-full bg-white border border-slate-200 rounded-2xl py-4 px-4 focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all font-medium text-slate-800" placeholder="500" />
                </div>
              </div>
            </div>
          </div>
        );
      case 2:
        return (
          <div className="space-y-8 animate-fadeIn">
            <h1 className="text-4xl font-black text-slate-900 mb-4 leading-tight">Branding & Identity</h1>
            <p className="text-slate-500 font-medium text-lg mb-10 max-w-2xl">
              Make SkyBook yours. Upload your logo and choose a theme that matches your brand identity.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <div className="space-y-4">
                <label className="text-sm font-bold text-slate-800">Company Logo</label>
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  className="hidden" 
                  accept="image/*"
                  onChange={(e) => e.target.files && handleFile(e.target.files[0])}
                />
                <div 
                  onDragOver={onDragOver}
                  onDrop={onDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={`w-full h-48 border-2 border-dashed rounded-[2rem] flex flex-col items-center justify-center gap-3 transition-all cursor-pointer group relative overflow-hidden ${logoPreview ? 'border-blue-400 bg-white' : 'border-slate-200 bg-slate-50/50 hover:bg-white hover:border-blue-300'}`}
                >
                  {logoPreview ? (
                    <>
                      <img src={logoPreview} alt="Logo Preview" className="w-full h-full object-contain p-4" />
                      <div className="absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-sm">
                        <p className="text-white text-xs font-black uppercase tracking-widest">Change Logo</p>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm text-slate-400 group-hover:text-blue-500 transition-colors">
                        <i className="fas fa-cloud-upload-alt text-xl"></i>
                      </div>
                      <p className="text-xs font-bold text-slate-400">Click or drag to upload</p>
                    </>
                  )}
                </div>
              </div>
              <div className="space-y-6">
                <label className="text-sm font-bold text-slate-800">Theme Color</label>
                <div className="flex flex-wrap gap-4">
                  {['#2563eb', '#7c3aed', '#db2777', '#059669', '#ea580c', '#0f172a'].map(color => (
                    <button 
                      key={color} 
                      onClick={() => setBrandColor(color)}
                      style={{ backgroundColor: color }}
                      className={`w-12 h-12 rounded-full border-4 transition-all transform hover:scale-110 ${brandColor === color ? 'border-white shadow-xl ring-2 ring-blue-500' : 'border-transparent opacity-70'}`}
                    />
                  ))}
                </div>
                <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100">
                  <p className="text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Preview</p>
                  <div className="flex items-center gap-3">
                    <div style={{ backgroundColor: brandColor }} className="w-8 h-8 rounded-lg"></div>
                    <span className="font-bold text-slate-900">Your App Interface</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      case 3:
        return (
          <div className="space-y-8 animate-fadeIn">
            <h1 className="text-4xl font-black text-slate-900 mb-4 leading-tight">Invite Your Team</h1>
            <p className="text-slate-500 font-medium text-lg mb-10 max-w-2xl">
              Add your team members and define their roles to start collaborating on leads.
            </p>
            <div className="space-y-4">
              {teamInvites.map((invite) => (
                <div key={invite.id} className="flex items-center gap-4 p-4 bg-white border border-slate-100 rounded-2xl shadow-sm group">
                  <div className="flex-1">
                    <input type="email" placeholder="Email Address" className="w-full bg-transparent border-none outline-none font-medium text-slate-800" />
                  </div>
                  <select className="bg-slate-50 border border-slate-100 rounded-xl px-4 py-2 text-xs font-bold text-slate-600 outline-none focus:ring-2 focus:ring-blue-500/10">
                    <option>Agent Access</option>
                    <option>Support Staff</option>
                    <option>Finance View</option>
                  </select>
                  <button 
                    onClick={() => removeInvite(invite.id)}
                    className="w-10 h-10 rounded-xl flex items-center justify-center text-slate-300 hover:text-red-500 hover:bg-red-50 transition-all"
                    title="Remove invitation"
                  >
                    <i className="fas fa-trash-alt text-sm"></i>
                  </button>
                </div>
              ))}
              <button 
                onClick={addInvite}
                className="text-blue-600 text-sm font-bold flex items-center gap-2 hover:underline p-2 transition-all"
              >
                <i className="fas fa-plus-circle"></i> Add another invitation
              </button>
            </div>
          </div>
        );
      case 4:
        return (
          <div className="space-y-8 animate-fadeIn text-center py-8">
            <div className="w-24 h-24 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center text-4xl mx-auto mb-6">
              <i className="fas fa-rocket"></i>
            </div>
            <h1 className="text-4xl font-black text-slate-900 mb-4 leading-tight">Ready for Takeoff!</h1>
            <p className="text-slate-500 font-medium text-lg mb-10 max-w-xl mx-auto">
              You're almost there! Review your settings and choose your notification preferences before we launch your workspace.
            </p>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col font-sans">
      <div className="flex-1 flex flex-col max-w-4xl mx-auto w-full px-8 py-12">
        {/* Progress Bar - Hidden for User Login flow */}
        {businessType !== 'user' && (
          <div className="flex gap-2 mb-12">
            {[1, 2, 3, 4].map((s) => (
              <div 
                key={s} 
                className={`h-1.5 flex-1 rounded-full transition-all duration-500 ${step >= s ? 'bg-blue-600' : 'bg-slate-100'}`}
              ></div>
            ))}
          </div>
        )}

        <div className="flex-1">
          {renderStepContent()}
        </div>

        {/* Footer Actions */}
        <div className="mt-12 pt-8 border-t border-slate-100 flex justify-between items-center">
          <div className="flex items-center gap-6">
            <button 
              onClick={prevStep}
              className={`text-sm font-bold text-slate-400 hover:text-slate-600 transition-colors ${step === 1 ? 'hidden' : 'block'}`}
            >
              <i className="fas fa-arrow-left mr-2"></i> Previous Step
            </button>
            {step === 1 && (
              <button 
                onClick={onComplete}
                className="text-sm font-bold text-slate-400 hover:text-blue-600 transition-colors"
              >
                Skip for now
              </button>
            )}
          </div>
          <button 
            onClick={nextStep}
            className="px-8 py-4 bg-blue-600 text-white font-black rounded-2xl shadow-xl shadow-blue-500/20 hover:bg-blue-700 transition-all flex items-center gap-3 active:scale-95"
          >
            {step === 4 ? 'Launch Dashboard' : 'Continue'}
            <i className={`fas ${step === 4 ? 'fa-check' : 'fa-arrow-right'}`}></i>
          </button>
        </div>
      </div>
    </div>
  );
};

export default OnboardingPage;