import React, { useState, useRef, useEffect } from 'react';

interface RecoveryPageProps {
  onBack: () => void;
  onComplete: () => void;
}

const RecoveryPage: React.FC<RecoveryPageProps> = ({ onBack, onComplete }) => {
  const [step, setStep] = useState(1);
  const [email, setEmail] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isResending, setIsResending] = useState(false);
  
  // Security Code Validity Timer (300 seconds = 5 minutes)
  const [timeLeft, setTimeLeft] = useState(300);
  
  // Advanced OTP State Management
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Focus synchronization for Step 2
  useEffect(() => {
    if (step === 2) {
      const firstEmpty = otp.findIndex(v => !v);
      const focusIndex = firstEmpty === -1 ? 5 : firstEmpty;
      const timer = setTimeout(() => {
        inputRefs.current[focusIndex]?.focus();
        inputRefs.current[focusIndex]?.select();
      }, 150);
      return () => clearTimeout(timer);
    }
  }, [step]);

  // Timer Logic
  useEffect(() => {
    let interval: number;
    if (step === 2 && timeLeft > 0) {
      interval = window.setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [step, timeLeft]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleNext = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setStep(prev => prev + 1);
    }, 1200);
  };

  const handleResend = () => {
    setIsResending(true);
    // Simulate API call for resending code
    setTimeout(() => {
      setOtp(['', '', '', '', '', '']);
      setTimeLeft(300);
      setIsResending(false);
      inputRefs.current[0]?.focus();
    }, 1000);
  };

  /**
   * Precise Input Logic: Only permits numeric entry and forces forward focus.
   * Handles overwriting existing digits for better UX.
   */
  const handleInputChange = (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    const digit = val.length > 0 ? val.slice(-1) : '';

    if (digit !== '' && !/^\d$/.test(digit)) return;

    const newOtp = [...otp];
    newOtp[index] = digit;
    setOtp(newOtp);

    // Auto-progression focus logic
    if (digit && index < 5) {
      inputRefs.current[index + 1]?.focus();
      inputRefs.current[index + 1]?.select();
    }
  };

  /**
   * Advanced Key Handling: 
   * - Backspace: Intelligently rewinds focus and clears content.
   * - Arrows: Navigates through segments.
   */
  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace') {
      if (!otp[index] && index > 0) {
        e.preventDefault();
        const newOtp = [...otp];
        newOtp[index - 1] = '';
        setOtp(newOtp);
        inputRefs.current[index - 1]?.focus();
      }
    } else if (e.key === 'ArrowLeft' && index > 0) {
      e.preventDefault();
      inputRefs.current[index - 1]?.focus();
      inputRefs.current[index - 1]?.select();
    } else if (e.key === 'ArrowRight' && index < 5) {
      e.preventDefault();
      inputRefs.current[index + 1]?.focus();
      inputRefs.current[index + 1]?.select();
    }
  };

  /**
   * Industrial Paste: Parses clipboard data and populates segments instantly.
   */
  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6);
    if (!pastedData) return;

    const newOtp = [...otp];
    pastedData.split('').forEach((char, i) => {
      if (i < 6) newOtp[i] = char;
    });
    setOtp(newOtp);

    const nextFocusIndex = Math.min(pastedData.length, 5);
    inputRefs.current[nextFocusIndex]?.focus();
    inputRefs.current[nextFocusIndex]?.select();
  };

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <form onSubmit={handleNext} className="space-y-6 animate-fadeIn">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-black text-slate-900 mb-2">Identify Account</h2>
              <p className="text-slate-500 font-medium text-sm">Enter your registered email or admin ID to receive a secure recovery code.</p>
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Identity Identifier</label>
              <div className="relative">
                <i className="fas fa-envelope absolute left-5 top-1/2 -translate-y-1/2 text-[10px] text-slate-300"></i>
                <input
                  required
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@skybook.com"
                  className="w-full bg-slate-50 border border-slate-200 rounded-2xl pl-12 pr-5 py-4 outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all font-bold text-sm"
                />
              </div>
            </div>
            <button
              type="submit"
              disabled={isProcessing}
              className="w-full bg-blue-600 text-white font-black py-5 rounded-2xl shadow-xl shadow-blue-500/20 hover:bg-blue-700 transition-all flex items-center justify-center gap-3 uppercase tracking-widest text-xs"
            >
              {isProcessing ? <i className="fas fa-circle-notch animate-spin"></i> : 'Request Recovery Code'}
            </button>
          </form>
        );
      case 2:
        return (
          <form onSubmit={handleNext} className="space-y-8 animate-fadeIn">
            <div className="text-center">
              <h2 className="text-3xl font-black text-slate-900 mb-2 tracking-tight">Terminal Verification</h2>
              <p className="text-slate-500 font-medium text-sm leading-relaxed">
                A secure transmission has been sent. <br/>
                Verify the <span className="text-blue-600 font-black">6-digit sequence</span> to continue.
              </p>
            </div>

            <div 
              className="flex justify-center items-center gap-2 sm:gap-3 px-2"
              onPaste={handlePaste}
            >
              {otp.map((digit, i) => (
                <React.Fragment key={i}>
                  <div className="relative group">
                    <input
                      ref={(el) => { inputRefs.current[i] = el; }}
                      type="text"
                      inputMode="numeric"
                      autoComplete="one-time-code"
                      maxLength={1}
                      value={digit}
                      onFocus={(e) => e.target.select()}
                      onChange={(e) => handleInputChange(i, e)}
                      onKeyDown={(e) => handleKeyDown(i, e)}
                      className={`w-11 h-14 sm:w-12 sm:h-16 text-center font-black text-2xl rounded-2xl transition-all outline-none border-2 shadow-sm ${
                        digit 
                          ? 'bg-blue-600 border-blue-600 text-white shadow-blue-500/20 scale-105' 
                          : 'bg-slate-50 border-slate-100 text-slate-900 focus:border-blue-400 focus:bg-white'
                      }`}
                      placeholder="•"
                    />
                    <div className={`absolute -bottom-1 left-2 right-2 h-1 rounded-full transition-all duration-300 ${digit ? 'bg-blue-400 opacity-100' : 'bg-transparent opacity-0'}`}></div>
                  </div>
                  {i === 2 && (
                    <div className="w-1.5 h-1.5 bg-slate-200 rounded-full mx-0.5 sm:mx-1 shrink-0"></div>
                  )}
                </React.Fragment>
              ))}
            </div>

            <div className="space-y-4 pt-4">
              <button
                type="submit"
                disabled={isProcessing || otp.some(v => !v) || timeLeft === 0}
                className="w-full bg-slate-900 text-white font-black py-5 rounded-2xl shadow-2xl hover:bg-blue-600 transition-all flex items-center justify-center gap-3 uppercase tracking-widest text-xs disabled:opacity-30 disabled:grayscale disabled:cursor-not-allowed group"
              >
                {isProcessing ? (
                  <i className="fas fa-circle-notch animate-spin"></i>
                ) : (
                  <>
                    <span>Initialize Session</span>
                    <i className="fas fa-shield-check group-hover:translate-x-1 transition-transform"></i>
                  </>
                )}
              </button>
              
              <div className="flex flex-col items-center gap-4">
                <button 
                  type="button" 
                  onClick={handleResend}
                  disabled={isResending}
                  className="text-[10px] font-black text-slate-400 uppercase tracking-widest hover:text-blue-600 transition-colors flex items-center gap-2 group disabled:opacity-50"
                >
                  <i className={`fas fa-redo ${isResending ? 'animate-spin' : 'group-hover:rotate-180'} transition-transform duration-700`}></i>
                  {isResending ? 'Transmitting...' : 'Resend Security Code'}
                </button>
                
                <div className="bg-slate-50 rounded-2xl px-5 py-3 border border-slate-100 flex items-center gap-3">
                   <div className="w-6 h-6 bg-white rounded-lg flex items-center justify-center text-blue-500 shadow-sm border border-slate-100">
                      <i className={`fas fa-clock text-[8px] ${timeLeft < 60 ? 'text-red-500 animate-pulse' : ''}`}></i>
                   </div>
                   <p className={`text-[9px] font-bold uppercase tracking-widest ${timeLeft < 60 ? 'text-red-500' : 'text-slate-400'}`}>
                      Valid for <span className={`${timeLeft < 60 ? 'text-red-600' : 'text-slate-900'}`}>{formatTime(timeLeft)}</span>
                   </p>
                </div>
              </div>
            </div>
          </form>
        );
      case 3:
        return (
          <form onSubmit={(e) => { e.preventDefault(); handleNext(e); }} className="space-y-6 animate-fadeIn">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-black text-slate-900 mb-2">New Access Key</h2>
              <p className="text-slate-500 font-medium text-sm">Create a new secure key to restore terminal access.</p>
            </div>
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">New Access Key</label>
                <input
                  required
                  type="password"
                  placeholder="••••••••"
                  className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all font-bold text-sm"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Confirm Key</label>
                <input
                  required
                  type="password"
                  placeholder="••••••••"
                  className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all font-bold text-sm"
                />
              </div>
            </div>
            <button
              type="submit"
              disabled={isProcessing}
              className="w-full bg-blue-600 text-white font-black py-5 rounded-2xl shadow-xl shadow-blue-500/20 hover:bg-blue-700 transition-all flex items-center justify-center gap-3 uppercase tracking-widest text-xs"
            >
              {isProcessing ? <i className="fas fa-circle-notch animate-spin"></i> : 'Update & Secure Account'}
            </button>
          </form>
        );
      case 4:
        return (
          <div className="text-center py-8 animate-fadeIn">
            <div className="w-20 h-20 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center text-3xl mx-auto mb-8 shadow-inner border border-emerald-100">
              <i className="fas fa-shield-check"></i>
            </div>
            <h2 className="text-3xl font-black text-slate-900 tracking-tight mb-4">Security Restored</h2>
            <p className="text-slate-500 font-medium leading-relaxed mb-10">
              Your access key has been successfully updated. You can now return to the login screen and initialize your session.
            </p>
            <button
              onClick={onComplete}
              className="w-full bg-slate-900 text-white font-black py-5 rounded-2xl shadow-xl hover:bg-slate-800 transition-all uppercase tracking-widest text-xs"
            >
              Return to Login
            </button>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-center p-6 transition-all duration-500">
      <div className="max-w-md w-full mx-auto space-y-8">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-slate-400 hover:text-blue-600 transition-all group font-black text-[10px] uppercase tracking-widest w-fit"
        >
          <i className="fas fa-arrow-left group-hover:-translate-x-1 transition-transform"></i>
          Back to Terminal
        </button>

        <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-2xl shadow-slate-200/50 overflow-hidden">
          <div className="h-2 bg-gradient-to-r from-blue-600 to-indigo-600"></div>
          
          <div className="p-10 md:p-12">
            {/* Stepper Indicator */}
            {step < 4 && (
              <div className="flex gap-2 mb-10 justify-center">
                {[1, 2, 3].map((i) => (
                  <div
                    key={i}
                    className={`h-1.5 rounded-full transition-all duration-500 ${
                      step >= i ? 'w-8 bg-blue-600' : 'w-4 bg-slate-100'
                    }`}
                  ></div>
                ))}
              </div>
            )}

            {renderStep()}
          </div>
        </div>

        <div className="text-center">
          <p className="text-[10px] font-black text-slate-300 uppercase tracking-[0.3em]">
            SkyBook Security Protocol v5.0
          </p>
        </div>
      </div>
    </div>
  );
};

export default RecoveryPage;