import React, { useState, useEffect } from 'react';

interface MaintenanceStatusPageProps {
  onBack: () => void;
}

const MaintenanceStatusPage: React.FC<MaintenanceStatusPageProps> = ({ onBack }) => {
  const [logs, setLogs] = useState<{ id: string, time: string, task: string, status: 'DONE' | 'WAIT' | 'RUN', progress: number }[]>([
    { id: '1', time: '14:20:01', task: 'Cloudflare Edge Cache Purge', status: 'DONE', progress: 100 },
    { id: '2', time: '14:20:05', task: 'Database Migration: Schema v5.0.2', status: 'DONE', progress: 100 },
    { id: '3', time: '14:21:10', task: 'Asset Optimization (CDN Propagating)', status: 'RUN', progress: 78 },
    { id: '4', time: '14:22:30', task: 'Neural Engine Model Reload', status: 'WAIT', progress: 0 },
    { id: '5', time: '14:22:45', task: 'Final API Gateway Health Check', status: 'WAIT', progress: 0 },
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      setLogs(prev => prev.map(log => {
        if (log.status === 'RUN') {
          const nextProgress = Math.min(log.progress + Math.floor(Math.random() * 5), 100);
          return { ...log, progress: nextProgress, status: nextProgress === 100 ? 'DONE' : 'RUN' };
        }
        if (log.status === 'WAIT' && prev.some(l => l.id === (parseInt(log.id) - 1).toString() && l.status === 'DONE')) {
          return { ...log, status: 'RUN', time: new Date().toLocaleTimeString([], { hour12: false }) };
        }
        return log;
      }));
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-300 font-mono p-8 animate-fadeIn flex flex-col gap-8">
      <header className="flex items-center justify-between border-b border-white/5 pb-8">
        <div className="flex items-center gap-6">
          <button 
            onClick={onBack}
            className="flex items-center gap-2 text-slate-500 hover:text-blue-400 transition-colors group text-[10px] font-black uppercase tracking-widest"
          >
            <i className="fas fa-arrow-left group-hover:-translate-x-1 transition-transform"></i>
            Back to Maintenance
          </button>
          <div className="h-4 w-px bg-white/10"></div>
          <div>
            <h1 className="text-xl font-black text-white tracking-tight uppercase">Maintenance Control Center</h1>
            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-1">Live Technical Feed • Terminal v5.0</p>
          </div>
        </div>
        <div className="flex gap-4">
           <div className="px-4 py-2 bg-blue-500/10 border border-blue-500/20 rounded-xl flex items-center gap-3">
              <span className="w-2 h-2 bg-blue-500 rounded-full animate-pulse shadow-[0_0_10px_#3b82f6]"></span>
              <span className="text-[10px] font-black uppercase text-blue-400">NOC Syncing</span>
           </div>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 flex-1">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white/5 border border-white/10 rounded-[2rem] p-8 space-y-8">
            <h3 className="text-xs font-black text-slate-500 uppercase tracking-widest">Execution Pipeline</h3>
            <div className="space-y-4">
              {logs.map((log) => (
                <div key={log.id} className="bg-slate-900/50 p-6 rounded-2xl border border-white/5 flex flex-col gap-4">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-4">
                      <span className="text-[10px] text-slate-600 font-bold">[{log.time}]</span>
                      <p className={`text-sm font-bold ${log.status === 'DONE' ? 'text-emerald-400' : log.status === 'RUN' ? 'text-blue-400' : 'text-slate-500'}`}>
                        {log.task}
                      </p>
                    </div>
                    <span className={`text-[9px] font-black px-2 py-0.5 rounded uppercase ${
                      log.status === 'DONE' ? 'bg-emerald-500/10 text-emerald-500' :
                      log.status === 'RUN' ? 'bg-blue-500/10 text-blue-500' : 'bg-white/5 text-slate-600'
                    }`}>
                      {log.status === 'RUN' ? 'Executing' : log.status === 'DONE' ? 'Success' : 'Queued'}
                    </span>
                  </div>
                  <div className="h-1 w-full bg-white/5 rounded-full overflow-hidden">
                    <div 
                      className={`h-full transition-all duration-1000 rounded-full ${
                        log.status === 'DONE' ? 'bg-emerald-500' : 'bg-blue-600'
                      }`} 
                      style={{ width: `${log.progress}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-8">
          <div className="bg-slate-900 border border-white/10 rounded-[2rem] p-8 space-y-6">
             <h3 className="text-xs font-black text-slate-500 uppercase tracking-widest">Environment Metrics</h3>
             <div className="space-y-6">
                <div>
                   <div className="flex justify-between text-[10px] font-black uppercase mb-2">
                      <span className="text-slate-500">Node Cluster Load</span>
                      <span className="text-white">12%</span>
                   </div>
                   <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                      <div className="h-full bg-blue-500 w-[12%]"></div>
                   </div>
                </div>
                <div>
                   <div className="flex justify-between text-[10px] font-black uppercase mb-2">
                      <span className="text-slate-500">I/O Wait State</span>
                      <span className="text-white">Low</span>
                   </div>
                   <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                      <div className="h-full bg-emerald-500 w-[4%]"></div>
                   </div>
                </div>
             </div>
          </div>

          <div className="bg-blue-600/10 border border-blue-500/20 rounded-[2rem] p-8">
             <div className="flex items-center gap-4 mb-4">
                <i className="fas fa-info-circle text-blue-400"></i>
                <h4 className="text-xs font-black text-blue-300 uppercase">Operator Note</h4>
             </div>
             <p className="text-[11px] leading-relaxed text-blue-200/70">
                System is undergoing planned cluster rotation. Traffic is being rerouted through our redundant DEL-SIN failover nodes. Expected completion: <span className="text-white font-bold">16:30 UTC</span>.
             </p>
          </div>
        </div>
      </div>

      <footer className="mt-auto pt-8 border-t border-white/5 text-center">
         <p className="text-[9px] font-black text-slate-600 uppercase tracking-[0.3em]">SkyBook NOC Terminal • Authorized Personnel View</p>
      </footer>
    </div>
  );
};

export default MaintenanceStatusPage;