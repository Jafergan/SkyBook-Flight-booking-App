
import React, { useState, useMemo } from 'react';
import { BookingStatus } from '../types';
import { MOCK_FLIGHTS, MOCK_BOOKINGS } from '../constants';

interface BookingManagementPageProps {
  onBack: () => void;
}

const AIRLINE_LOGOS: Record<string, string> = {
  'Emirates': 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d0/Emirates_logo.svg/1200px-Emirates_logo.svg.png',
  'IndiGo': 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/af/IndiGo_Airlines_logo.svg/1200px-IndiGo_Airlines_logo.svg.png',
  'Air India': 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Air_India_logo.svg/1200px-Air_India_logo.svg.png',
  'Vistara': 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3f/Vistara_logo.svg/1200px-Vistara_logo.svg.png',
  'flydubai': 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/00/Flydubai_logo.svg/1200px-Flydubai_logo.svg.png',
  'SpiceJet': 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d4/SpiceJet_logo.svg/1200px-SpiceJet_logo.svg.png',
};

const BookingManagementPage: React.FC<BookingManagementPageProps> = ({ onBack }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedAirlines, setSelectedAirlines] = useState<string[]>([]);
  
  // Live Preview States for the "Advanced Graphics" ticket
  const [previewPnr, setPreviewPnr] = useState('PNR-789');
  const [previewPassenger, setPreviewPassenger] = useState('Guest Traveler');
  const [previewAirline, setPreviewAirline] = useState('Emirates');
  const [previewOrigin, setPreviewOrigin] = useState('BOM');
  const [previewDest, setPreviewDest] = useState('DXB');
  const [previewPrice, setPreviewPrice] = useState('0');

  const [localBookings, setLocalBookings] = useState(() => 
    MOCK_BOOKINGS.map(booking => {
      const flight = MOCK_FLIGHTS.find(f => f.id === booking.flightId);
      return {
        id: booking.id,
        pnr: booking.pnr,
        passenger: 'Rahul Verma', 
        route: flight ? `${flight.departure} → ${flight.arrival}` : 'Unknown',
        airline: flight?.airline || 'Unknown',
        logo: flight?.airlineLogo || 'https://cdn-icons-png.flaticon.com/512/984/984233.png',
        date: new Date(booking.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
        amount: `$${booking.totalFare.toLocaleString()}`,
        status: booking.status
      };
    })
  );

  const filteredBookings = useMemo(() => {
    if (selectedAirlines.length === 0) return localBookings;
    return localBookings.filter(b => selectedAirlines.includes(b.airline));
  }, [localBookings, selectedAirlines]);

  const toggleAirline = (airline: string) => {
    setSelectedAirlines(prev => 
      prev.includes(airline) ? prev.filter(a => a !== airline) : [...prev, airline]
    );
  };

  const handleManualTicketSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsProcessing(true);
    
    const newTicket = {
      id: `B-${Date.now()}`,
      pnr: previewPnr.toUpperCase(),
      passenger: previewPassenger,
      route: `${previewOrigin} → ${previewDest}`,
      airline: previewAirline,
      logo: AIRLINE_LOGOS[previewAirline] || 'https://cdn-icons-png.flaticon.com/512/984/984233.png', 
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      amount: `$${previewPrice}`,
      status: BookingStatus.CONFIRMED
    };

    setTimeout(() => {
      setLocalBookings(prev => [newTicket, ...prev]);
      setIsProcessing(false);
      setIsModalOpen(false);
    }, 1500);
  };

  return (
    <div className="px-4 md:px-8 lg:px-10 py-6 md:py-8 lg:py-10 space-y-6 md:space-y-8 animate-fadeIn max-w-[1600px] mx-auto overflow-x-hidden">
      <style>{`
        @media print {
          aside, header, button, .no-print, .filters-sidebar { display: none !important; }
          .print-full { width: 100% !important; margin: 0 !important; padding: 0 !important; border: none !important; box-shadow: none !important; }
          body { background: white !important; }
          .bg-white { background: transparent !important; }
        }
      `}</style>

      <div className="flex flex-col gap-4 no-print">
        <nav className="flex items-center gap-3 text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">
          <button onClick={onBack} className="hover:text-blue-600 transition-colors">Dashboard</button>
          <i className="fas fa-chevron-right text-[8px] opacity-30"></i>
          <span className="text-blue-600">Inventory Management</span>
        </nav>

        <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
          <div className="max-w-2xl">
            <h1 className="text-2xl md:text-3xl lg:text-4xl font-black text-slate-900 tracking-tight leading-none">
              Reservation Ledger
            </h1>
            <p className="text-slate-500 font-medium mt-2 md:mt-3 text-sm md:text-lg">
              Authorized access to global PNR records and live booking statuses.
            </p>
          </div>
          <button 
            onClick={() => setIsModalOpen(true)}
            className="w-full md:w-auto bg-blue-600 text-white px-8 py-4 rounded-2xl font-black uppercase tracking-widest text-[10px] shadow-xl shadow-blue-500/20 hover:bg-blue-700 transition-all flex items-center justify-center gap-3"
          >
            <i className="fas fa-plus"></i> Manual Ticketing
          </button>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Filters Sidebar Section */}
        <aside className="w-full lg:w-72 shrink-0 space-y-6 no-print filters-sidebar">
          <div className="bg-white rounded-[2rem] border border-slate-100 p-8 shadow-sm space-y-8 sticky top-24">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest">Filters</h3>
              <button 
                onClick={() => setSelectedAirlines([])}
                className="text-blue-600 text-[10px] font-black uppercase hover:underline"
              >
                Reset
              </button>
            </div>

            <div className="space-y-6">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">AirLines</p>
              <div className="space-y-4">
                {Object.keys(AIRLINE_LOGOS).map(airline => (
                  <label key={airline} className="flex items-center gap-4 cursor-pointer group">
                    <div 
                      onClick={() => toggleAirline(airline)} 
                      className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-all ${selectedAirlines.includes(airline) ? 'bg-blue-600 border-blue-600' : 'border-slate-200 group-hover:border-blue-300'}`}
                    >
                      {selectedAirlines.includes(airline) && <i className="fas fa-check text-[8px] text-white"></i>}
                    </div>
                    <div className="flex items-center gap-3 flex-1 overflow-hidden">
                      <span className="text-xs font-bold text-slate-600 truncate group-hover:text-slate-900 transition-colors">{airline}</span>
                    </div>
                  </label>
                ))}
              </div>
            </div>
          </div>

          <div className="bg-blue-600 rounded-[2rem] p-8 text-white shadow-xl shadow-blue-500/10">
             <i className="fas fa-shield-halved text-2xl mb-4 opacity-50"></i>
             <h4 className="text-sm font-black uppercase tracking-widest mb-2">Secure Node</h4>
             <p className="text-[10px] font-medium text-blue-100 leading-relaxed">
               Filter results are synchronized directly with the Global Distribution System cache.
             </p>
          </div>
        </aside>

        {/* Main Content Ledger */}
        <div className="flex-1 bg-white rounded-[2.5rem] border border-slate-100 shadow-xl shadow-blue-500/5 overflow-hidden print-full">
          <div className="overflow-x-auto scrollbar-hide">
            <table className="w-full text-left border-collapse min-w-[900px]">
              <thead>
                <tr className="bg-slate-50/50 text-slate-400 text-[9px] font-black uppercase tracking-[0.2em] border-b border-slate-50">
                  <th className="px-8 py-6">Carrier Identity</th>
                  <th className="px-8 py-6">Locator Code</th>
                  <th className="px-8 py-6">Traveler Detail</th>
                  <th className="px-8 py-6">Vector Path</th>
                  <th className="px-8 py-6 text-right">Settlement</th>
                  <th className="px-8 py-6 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {filteredBookings.map((row, i) => (
                  <tr key={i} className="hover:bg-slate-50/80 transition-all group cursor-pointer animate-fadeIn">
                    <td className="px-8 py-6">
                      <div className="flex flex-col">
                        <span className="text-sm font-black text-slate-900 tracking-tight">{row.airline}</span>
                        <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Global GDS</span>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <div className="inline-flex items-center gap-2 bg-blue-50/50 px-3 py-1.5 rounded-lg border border-blue-100 group-hover:bg-blue-600 group-hover:text-white transition-all">
                        <span className="text-xs font-black uppercase tracking-widest">{row.pnr}</span>
                        <i className="fas fa-copy text-[10px] opacity-30 group-hover:opacity-100"></i>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <div className="flex flex-col">
                        <span className="text-sm font-black text-slate-800">{row.passenger}</span>
                        <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">{row.date}</span>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <div className="flex items-center gap-3">
                        <i className="fas fa-plane-departure text-[10px] text-blue-500"></i>
                        <span className="text-xs font-bold text-slate-700 tracking-tight">{row.route}</span>
                      </div>
                    </td>
                    <td className="px-8 py-6 text-right font-black text-slate-900 text-sm">
                      {row.amount}
                    </td>
                    <td className="px-8 py-6 text-center">
                      <span className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-[9px] font-black uppercase border tracking-widest ${
                        row.status === BookingStatus.CONFIRMED ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 
                        row.status === BookingStatus.PENDING ? 'bg-amber-50 text-amber-600 border-amber-100' :
                        'bg-slate-50 text-slate-400 border-slate-100'
                      }`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${
                          row.status === BookingStatus.CONFIRMED ? 'bg-emerald-500' : 
                          row.status === BookingStatus.PENDING ? 'bg-amber-500' : 'bg-slate-300'
                        }`}></span>
                        {row.status}
                      </span>
                    </td>
                  </tr>
                ))}
                {filteredBookings.length === 0 && (
                  <tr>
                    <td colSpan={6} className="px-8 py-20 text-center">
                      <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-200 mx-auto mb-4">
                        <i className="fas fa-search-minus text-2xl"></i>
                      </div>
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">No reservations match selected criteria</p>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row justify-between items-center gap-6 pt-6 no-print">
        <p className="text-[10px] font-black text-slate-300 uppercase tracking-[0.3em]">
          Showing {filteredBookings.length} of {localBookings.length} Global Reservations
        </p>
        <div className="flex gap-4">
           <button onClick={() => {}} className="px-6 py-3 rounded-xl border border-slate-200 text-[10px] font-black uppercase tracking-widest text-slate-500 hover:bg-slate-50 transition-all flex items-center gap-2">
             <i className="fas fa-file-csv text-blue-500"></i> Export CSV
           </button>
           <button onClick={() => window.print()} className="px-6 py-3 rounded-xl border border-slate-200 text-[10px] font-black uppercase tracking-widest text-slate-500 hover:bg-slate-50 transition-all flex items-center gap-2">
             <i className="fas fa-print text-indigo-500"></i> Print Batch
           </button>
        </div>
      </div>

      {/* Manual Ticketing Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-2 sm:p-4">
          <div 
            className="absolute inset-0 bg-slate-950/80 backdrop-blur-xl animate-fadeIn"
            onClick={() => setIsModalOpen(false)}
          ></div>
          <div className="bg-slate-900 w-full max-w-3xl rounded-[1.5rem] sm:rounded-[2rem] shadow-[0_0_80px_rgba(0,0,0,0.5)] relative z-10 animate-slideUp border border-white/10 overflow-hidden flex flex-col md:flex-row max-h-[95vh] sm:max-h-none overflow-y-auto sm:overflow-visible">
             {/* Left Pane: Input Form */}
             <div className="flex-1 p-5 sm:p-6 lg:p-8 space-y-4 sm:space-y-6">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 sm:w-9 sm:h-9 bg-blue-600 rounded-lg sm:rounded-xl flex items-center justify-center shadow-[0_0_15px_rgba(37,99,235,0.4)]">
                      <i className="fas fa-terminal text-white text-[10px] sm:text-xs"></i>
                    </div>
                    <div>
                      <h3 className="text-base sm:text-lg font-black text-white tracking-tight uppercase leading-none">Manual Issue</h3>
                      <p className="text-[7px] sm:text-[8px] font-bold text-blue-400 uppercase tracking-widest mt-0.5">Terminal v5.0.2</p>
                    </div>
                  </div>
                  <button onClick={() => setIsModalOpen(false)} className="md:hidden w-8 h-8 flex items-center justify-center text-slate-500 bg-white/5 rounded-lg">
                    <i className="fas fa-times text-xs"></i>
                  </button>
                </div>

                <form onSubmit={handleManualTicketSubmit} className="space-y-3 md:space-y-3.5">
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[7px] sm:text-[8px] font-black text-slate-500 uppercase tracking-widest px-1">PNR ID</label>
                      <input 
                        required 
                        value={previewPnr}
                        onChange={(e) => setPreviewPnr(e.target.value)}
                        className="w-full bg-white/5 border border-white/10 rounded-lg sm:rounded-xl px-3 py-2 sm:px-4 sm:py-2.5 font-bold text-white outline-none focus:border-blue-500 focus:bg-white/10 transition-all placeholder:text-slate-600 text-[11px] sm:text-xs" 
                        placeholder="e.g. SKY-X2"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[7px] sm:text-[8px] font-black text-slate-500 uppercase tracking-widest px-1">Carrier</label>
                      <select 
                        required 
                        value={previewAirline}
                        onChange={(e) => setPreviewAirline(e.target.value)}
                        className="w-full bg-white/5 border border-white/10 rounded-lg sm:rounded-xl px-3 py-2 sm:px-4 sm:py-2.5 font-bold text-white outline-none focus:border-blue-500 focus:bg-white/10 transition-all text-[11px] sm:text-xs"
                      >
                         <option value="Emirates">Emirates</option>
                         <option value="IndiGo">IndiGo</option>
                         <option value="Air India">Air India</option>
                         <option value="Vistara">Vistara</option>
                         <option value="flydubai">flydubai</option>
                         <option value="SpiceJet">SpiceJet</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[7px] sm:text-[8px] font-black text-slate-500 uppercase tracking-widest px-1">Traveler Name</label>
                    <input 
                      required 
                      value={previewPassenger}
                      onChange={(e) => setPreviewPassenger(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-lg sm:rounded-xl px-3 py-2 sm:px-4 sm:py-2.5 font-bold text-white outline-none focus:border-blue-500 focus:bg-white/10 transition-all placeholder:text-slate-600 text-[11px] sm:text-xs" 
                      placeholder="Full Name"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[7px] sm:text-[8px] font-black text-slate-500 uppercase tracking-widest px-1">Origin</label>
                      <input 
                        required 
                        value={previewOrigin}
                        onChange={(e) => setPreviewOrigin(e.target.value.toUpperCase())}
                        className="w-full bg-white/5 border border-white/10 rounded-lg sm:rounded-xl px-3 py-2 sm:px-4 sm:py-2.5 font-bold text-white outline-none focus:border-blue-500 focus:bg-white/10 transition-all text-center text-[11px] sm:text-xs" 
                        maxLength={3}
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[7px] sm:text-[8px] font-black text-slate-500 uppercase tracking-widest px-1">Destination</label>
                      <input 
                        required 
                        value={previewDest}
                        onChange={(e) => setPreviewDest(e.target.value.toUpperCase())}
                        className="w-full bg-white/5 border border-white/10 rounded-lg sm:rounded-xl px-3 py-2 sm:px-4 sm:py-2.5 font-bold text-white outline-none focus:border-blue-500 focus:bg-white/10 transition-all text-center text-[11px] sm:text-xs" 
                        maxLength={3}
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[7px] sm:text-[8px] font-black text-slate-500 uppercase tracking-widest px-1">Settlement (USD)</label>
                    <input 
                      required 
                      type="number"
                      value={previewPrice}
                      onChange={(e) => setPreviewPrice(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-lg sm:rounded-xl px-3 py-2 sm:px-4 sm:py-2.5 font-bold text-white outline-none focus:border-blue-500 focus:bg-white/10 transition-all text-[11px] sm:text-xs" 
                    />
                  </div>

                  <div className="pt-4 flex gap-3">
                    <button 
                      type="button" 
                      onClick={() => setIsModalOpen(false)}
                      className="flex-1 bg-white/5 text-slate-400 font-black py-3 sm:py-3.5 rounded-lg sm:rounded-xl border border-white/10 uppercase tracking-widest text-[8px] sm:text-[9px] hover:bg-white/10 transition-all"
                    >
                      Abort
                    </button>
                    <button 
                      type="submit" 
                      disabled={isProcessing}
                      className="flex-[1.5] bg-blue-600 text-white font-black py-3 sm:py-3.5 rounded-lg sm:rounded-xl shadow-lg hover:bg-blue-700 transition-all uppercase tracking-[0.2em] text-[8px] sm:text-[9px] flex items-center justify-center gap-2"
                    >
                      {isProcessing ? <i className="fas fa-circle-notch animate-spin"></i> : <><i className="fas fa-check-circle"></i> Initialize</>}
                    </button>
                  </div>
                </form>
             </div>

             {/* Right Pane: Visual Preview */}
             <div className="w-full md:w-[280px] bg-slate-800/40 p-5 sm:p-6 flex flex-col items-center justify-center border-t md:border-t-0 md:border-l border-white/5 relative overflow-hidden shrink-0">
                <div className="absolute inset-0 opacity-5 pointer-events-none">
                  <div className="absolute top-0 left-0 w-full h-full" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, #3b82f6 1px, transparent 0)', backgroundSize: '15px 15px' }}></div>
                </div>
                
                <h4 className="text-[7px] sm:text-[8px] font-black text-blue-400 uppercase tracking-[0.4em] mb-4 sm:mb-6 relative z-10">Live Visual</h4>

                {/* The Ticket Graphic */}
                <div className="w-full max-w-[220px] aspect-[4/6] bg-white rounded-2xl overflow-hidden shadow-[0_15px_35px_rgba(0,0,0,0.4)] relative z-10 flex flex-col transform scale-[0.8] md:scale-90 origin-center">
                  <div className="bg-blue-600 p-4 text-white flex justify-between items-start">
                    <div className="space-y-0.5">
                      <p className="text-[5px] font-black uppercase tracking-widest opacity-60">Identity</p>
                      <p className="text-[9px] font-black uppercase tracking-tighter truncate w-16">{previewAirline}</p>
                    </div>
                    <div className="w-6 h-6 bg-white/20 rounded-md flex items-center justify-center">
                      <i className="fas fa-plane text-white text-[8px]"></i>
                    </div>
                  </div>

                  <div className="flex-1 p-4 space-y-4 relative">
                    <div className="flex justify-between items-center">
                       <div>
                          <p className="text-[5px] font-black text-slate-400 uppercase tracking-widest">Origin</p>
                          <p className="text-lg font-black text-slate-900 leading-none">{previewOrigin || '---'}</p>
                       </div>
                       <i className="fas fa-chevron-right text-[4px] text-slate-200"></i>
                       <div className="text-right">
                          <p className="text-[5px] font-black text-slate-400 uppercase tracking-widest">Dest</p>
                          <p className="text-lg font-black text-slate-900 leading-none">{previewDest || '---'}</p>
                       </div>
                    </div>

                    <div className="space-y-0.5">
                       <p className="text-[5px] font-black text-slate-400 uppercase tracking-widest">Passenger</p>
                       <p className="text-[10px] font-black text-slate-800 tracking-tight leading-tight truncate">{previewPassenger}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <p className="text-[5px] font-black text-slate-400 uppercase tracking-widest">PNR</p>
                        <p className="text-[7px] font-black text-blue-600 uppercase tracking-widest">{previewPnr || '---'}</p>
                      </div>
                      <div>
                        <p className="text-[5px] font-black text-slate-400 uppercase tracking-widest">Status</p>
                        <p className="text-[7px] font-black text-slate-800 uppercase tracking-widest">Confirmed</p>
                      </div>
                    </div>

                    <div className="absolute bottom-4 left-4 right-4 pt-4 border-t border-dashed border-slate-200">
                      <div className="flex justify-between items-end">
                        <div className="space-y-0.5">
                          <p className="text-[5px] font-black text-slate-400 uppercase tracking-widest">Fare</p>
                          <p className="text-base font-black text-slate-900">${previewPrice}</p>
                        </div>
                        <i className="fas fa-qrcode text-2xl opacity-10"></i>
                      </div>
                    </div>
                  </div>

                  <div className="bg-slate-50 px-4 py-2 flex justify-between items-center border-t border-slate-100">
                    <span className="text-[4px] font-black text-slate-400 uppercase tracking-widest italic">GDS Verified Node</span>
                    <div className="flex gap-0.5">
                      <div className="w-0.5 h-0.5 bg-blue-500 rounded-full"></div>
                      <div className="w-0.5 h-0.5 bg-blue-100 rounded-full"></div>
                    </div>
                  </div>
                </div>

                <div className="mt-4 sm:mt-6 flex items-center gap-2 text-slate-600 relative z-10">
                  <i className="fas fa-shield-halved text-blue-500 text-[8px]"></i>
                  <p className="text-[6px] sm:text-[7px] font-bold uppercase tracking-widest">Secure Sync v5</p>
                </div>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BookingManagementPage;
