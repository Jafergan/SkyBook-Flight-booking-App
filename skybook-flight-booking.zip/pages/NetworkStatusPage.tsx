import React, { useState, useEffect } from 'react';

interface NetworkStatusPageProps {
  onBack: () => void;
}

const NetworkStatusPage: React.FC<NetworkStatusPageProps> = ({ onBack }) => {
  const [uptime, setUptime] = useState(99.998);
  const [latency, setLatency] = useState(12);
  const [globalTraffic, setGlobalTraffic] = useState(128450);

  // Simulated live data updates
  useEffect(() => {
    const interval = setInterval(() => {
      setLatency(Math.floor(Math.random() * 5) + 10);
      setGlobalTraffic(prev => prev + Math.floor(Math.random() * 10));
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const nodes = [
    { city: 'New Delhi', code: 'DEL', region: 'Asia-Pacific', ping: '12ms', load: '42%', status: 'Operational' },
    { city: 'Singapore', code: 'SIN', region: 'Asia-Pacific', ping: '18ms', load: '38%', status: 'Operational' },
    { city: 'London', code: 'LHR', region: 'Europe', ping: '24ms', load: '56%', status: 'Operational' },
    { city: 'New York', code: 'JFK', region: 'North America', ping: '32ms', load: '48%', status: 'Operational' },
    { city: 'Dubai', code: 'DXB', region: 'Middle East', ping: '15ms', load: '62%', status: 'Operational' },
    { city: 'Sydney', code: 'SYD', region: 'Oceania', ping: '45ms', load: '22%', status: 'Operational' },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-white font-sans overflow-x-hidden animate-fadeIn">
      {/* Dynamic Background Grid */}
      <div className="fixed inset-0 pointer-events-none opacity-10">
        <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, #3b82f6 1px, transparent 0)', backgroundSize: '40px 40px' }}></div>
      </div>

      <header className="relative z-10 px-12 py-8 flex items-center justify-between border-b border-white/5 bg-slate-950/50 backdrop-blur-xl sticky top-0">
        <div className="flex items-center gap-6">
          <button onClick={onBack} className="flex items-center gap-2 group text-slate-400 hover:text-blue-400 transition-colors">
            <i className="fas fa-arrow-left group-hover:-translate-x-1 transition-transform"></i>
            <span className="text-[10px] font-black uppercase tracking-widest">Exit Monitor</span>
          </button>
          <div className="h-6 w-px bg-white/10"></div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white">
              <i className="fas fa-plane-departure text-sm"></i>
            </div>
            <span className="text-xl font-extrabold tracking-tight text-white">SkyBook <span className="text-blue-500">Live</span></span>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-2 px-4 py-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-full text-[10px] font-black uppercase tracking-widest text-emerald-400">
            <span className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></span> Systems Nominal
          </span>
        </div>
      </header>

      <main className="relative z-10 max-w-7xl mx-auto px-12 py-16 space-y-16">
        {/* Real-time Hero Statistics */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { label: 'Platform Uptime', value: `${uptime}%`, icon: 'fa-shield-check', color: 'blue' },
            { label: 'Global Latency', value: `${latency}ms`, icon: 'fa-bolt', color: 'blue' },
            { label: 'Daily Operations', value: globalTraffic.toLocaleString(), icon: 'fa-chart-network', color: 'blue' },
          ].map((stat, i) => (
            <div key={i} className="bg-white/5 border border-white/10 rounded-[2.5rem] p-10 hover:border-blue-500/50 transition-all group overflow-hidden relative">
              <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
                 <i className={`fas ${stat.icon} text-8xl text-blue-500`}></i>
              </div>
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">{stat.label}</p>
              <p className="text-5xl font-black text-white tracking-tighter">{stat.value}</p>
            </div>
          ))}
        </section>

        {/* Global Infrastructure Map (Conceptual) */}
        <section className="bg-white/5 border border-white/10 rounded-[3.5rem] p-12 relative overflow-hidden">
           <div className="absolute inset-0 opacity-10 pointer-events-none">
              <img src="https://images.unsplash.com/photo-1517400508447-f8dd518b86db?auto=format&fit=crop&q=80&w=2000" className="w-full h-full object-cover" alt="" />
           </div>
           
           <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-8 mb-16">
              <div>
                 <h2 className="text-3xl font-black tracking-tight text-white">Global Edge Network</h2>
                 <p className="text-slate-400 font-medium mt-2">Monitoring operational health across 190+ data centers.</p>
              </div>
              <div className="flex gap-4">
                 <div className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                    <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Mainframes</span>
                 </div>
                 <div className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-emerald-500 rounded-full"></span>
                    <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Edge Nodes</span>
                 </div>
              </div>
           </div>

           <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {nodes.map((node, i) => (
                <div key={i} className="bg-slate-900/50 border border-white/5 rounded-3xl p-6 hover:bg-slate-900 transition-all hover:border-blue-500/30 group">
                   <div className="flex justify-between items-start mb-6">
                      <div className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center font-black text-xs border border-white/10 group-hover:text-blue-400 group-hover:border-blue-400/30 transition-all">
                        {node.code}
                      </div>
                      <span className="text-[8px] font-black uppercase tracking-widest text-emerald-400 bg-emerald-400/10 px-2 py-1 rounded-full">{node.status}</span>
                   </div>
                   <h4 className="font-black text-white text-lg">{node.city}</h4>
                   <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-6">{node.region}</p>
                   
                   <div className="space-y-4">
                      <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest">
                         <span className="text-slate-500">Node Latency</span>
                         <span className="text-blue-400">{node.ping}</span>
                      </div>
                      <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden">
                         <div className="h-full bg-blue-500 rounded-full" style={{ width: node.load }}></div>
                      </div>
                      <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest">
                         <span className="text-slate-500">Infrastructure Load</span>
                         <span className="text-white">{node.load}</span>
                      </div>
                   </div>
                </div>
              ))}
           </div>
        </section>

        {/* Security & Compliance Board */}
        <section className="grid grid-cols-1 lg:grid-cols-2 gap-10">
           <div className="bg-gradient-to-br from-blue-900/40 to-slate-900/40 border border-white/10 rounded-[3rem] p-10 space-y-8">
              <div className="w-16 h-16 bg-blue-500/20 rounded-2xl flex items-center justify-center text-blue-400 text-2xl shadow-inner border border-blue-500/30">
                 <i className="fas fa-shield-halved"></i>
              </div>
              <h3 className="text-2xl font-black text-white tracking-tight">Enterprise Security Matrix</h3>
              <p className="text-slate-400 font-medium leading-relaxed">
                 SkyBook utilizes banking-grade SSL/TLS encryption and is fully compliant with GDPR, PCI-DSS, and IATA security protocols for all global transactions.
              </p>
              <div className="grid grid-cols-2 gap-4">
                 <div className="bg-white/5 p-4 rounded-2xl border border-white/5 flex items-center gap-3">
                    <i className="fas fa-check-circle text-emerald-500 text-xs"></i>
                    <span className="text-[10px] font-black uppercase tracking-widest">End-to-End Encryption</span>
                 </div>
                 <div className="bg-white/5 p-4 rounded-2xl border border-white/5 flex items-center gap-3">
                    <i className="fas fa-check-circle text-emerald-500 text-xs"></i>
                    <span className="text-[10px] font-black uppercase tracking-widest">2FA Multi-layered Auth</span>
                 </div>
              </div>
           </div>

           <div className="bg-slate-900/40 border border-white/10 rounded-[3rem] p-10 space-y-8">
              <div className="flex justify-between items-center">
                 <h3 className="text-2xl font-black text-white tracking-tight">Live Terminal Feed</h3>
                 <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                    <span className="text-[8px] font-black uppercase text-slate-500 tracking-widest">Live Updates</span>
                 </div>
              </div>
              <div className="space-y-4 font-mono text-xs">
                 {[
                   { time: '12:44:02', event: 'Primary Node BOM: Handshake Successful', color: 'text-blue-400' },
                   { time: '12:44:10', event: 'Global Route Cache: Flushed & Rebuilt', color: 'text-slate-500' },
                   { time: '12:44:15', event: 'GDS Integration Hub: Connection Verified', color: 'text-emerald-400' },
                   { time: '12:44:22', event: 'Pricing Engine v5.1: Deployment Complete', color: 'text-blue-400' },
                   { time: '12:44:30', event: 'Neural Search Training: Cycle 824 Started', color: 'text-indigo-400' },
                 ].map((log, i) => (
                   <div key={i} className="flex gap-4 p-3 bg-white/5 rounded-xl border border-white/5">
                      <span className="text-slate-600 font-bold">{log.time}</span>
                      <span className={log.color}>{log.event}</span>
                   </div>
                 ))}
              </div>
           </div>
        </section>
      </main>

      <footer className="relative z-10 py-16 border-t border-white/5 text-center space-y-4">
         <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">© 2025 SkyBook Network Operations Center (NOC)</p>
         <div className="flex justify-center gap-6">
            <i className="fab fa-aws opacity-20 hover:opacity-100 transition-opacity"></i>
            <i className="fab fa-google opacity-20 hover:opacity-100 transition-opacity"></i>
            <i className="fab fa-cloudflare opacity-20 hover:opacity-100 transition-opacity"></i>
         </div>
      </footer>
    </div>
  );
};

export default NetworkStatusPage;