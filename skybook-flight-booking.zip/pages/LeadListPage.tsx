
import React, { useState, useMemo } from 'react';
import { MOCK_USERS, MOCK_FLIGHTS } from '../constants';
import { LeadStatus, UserRole, Lead } from '../types';

interface LeadListPageProps {
  onSelectLead: (leadId: string) => void;
  currentRole: UserRole;
  leads: Lead[];
  onAddLead: (lead: Lead) => void;
  onBack: () => void;
}

const LeadListPage: React.FC<LeadListPageProps> = ({ onSelectLead, currentRole, leads, onAddLead, onBack }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  
  // Form State for New Lead
  const [newLeadName, setNewLeadName] = useState('');
  const [newLeadEmail, setNewLeadEmail] = useState('');
  const [newLeadOrigin, setNewLeadOrigin] = useState('');
  const [newLeadDest, setNewLeadDest] = useState('');

  const itemsPerPage = 8;

  const roleFilteredLeads = useMemo(() => {
    if (currentRole === UserRole.ADMIN) return leads;
    if (currentRole === UserRole.AGENT) return leads.filter(l => l.assignedTo === '2' || l.assignedTo === '3');
    if (currentRole === UserRole.USER) return leads.filter(l => l.email === 'john.d@example.com');
    return [];
  }, [currentRole, leads]);

  const searchedLeads = useMemo(() => {
    return roleFilteredLeads.filter(lead => 
      lead.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lead.route.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [roleFilteredLeads, searchTerm]);

  const paginatedLeads = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return searchedLeads.slice(start, start + itemsPerPage);
  }, [searchedLeads, currentPage]);

  const handleCreateLead = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    const lead: Lead = {
      id: `L-${Date.now()}`,
      customerName: newLeadName,
      email: newLeadEmail,
      phone: '+91 000 000 0000',
      origin: newLeadOrigin,
      destination: newLeadDest,
      route: `${newLeadOrigin} → ${newLeadDest}`,
      date: new Date().toISOString().split('T')[0],
      budget: 50000,
      status: LeadStatus.NEW,
      tripType: 'International',
      passengers: { adults: 1, children: 0 },
      assignedTo: '2',
      notes: ['Quick lead created via Terminal.'],
      activities: [
        { id: `act-${Date.now()}`, type: 'created', content: 'Lead captured via Pipeline Terminal', timestamp: new Date().toISOString() }
      ],
      createdAt: new Date().toISOString(),
    };

    setTimeout(() => {
      onAddLead(lead);
      setIsProcessing(false);
      setIsAddModalOpen(false);
      // Reset fields
      setNewLeadName('');
      setNewLeadEmail('');
      setNewLeadOrigin('');
      setNewLeadDest('');
    }, 1000);
  };

  return (
    <div className="p-4 md:p-8 space-y-6 md:space-y-8 animate-fadeIn max-w-7xl mx-auto overflow-x-hidden">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
        <div>
          <button onClick={onBack} className="mb-4 flex items-center gap-2 text-slate-400 hover:text-blue-600 transition-all font-black text-[10px] uppercase tracking-widest w-fit group">
            <i className="fas fa-arrow-left group-hover:-translate-x-1 transition-transform"></i>
            Back
          </button>
          <h1 className="text-2xl md:text-3xl lg:text-4xl font-black text-slate-900 tracking-tight leading-none">
            {currentRole === UserRole.ADMIN ? 'Pipeline Manager' : 'Active Leads'}
          </h1>
          <p className="text-slate-500 font-medium mt-2 text-sm md:text-base">Real-time inquiries across the global GDS network.</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
          <div className="relative flex-1 sm:w-64">
            <i className="fas fa-search absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 text-xs"></i>
            <input 
              type="text" 
              placeholder="Filter leads..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-white border border-slate-100 rounded-xl pl-10 pr-4 py-3.5 text-xs font-bold outline-none focus:ring-4 focus:ring-blue-500/5 transition-all"
            />
          </div>
          <button 
            onClick={() => setIsAddModalOpen(true)}
            className="bg-blue-600 text-white px-6 py-3.5 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-blue-700 shadow-lg shadow-blue-500/20 flex items-center justify-center gap-2"
          >
            <i className="fas fa-plus"></i> Lead
          </button>
        </div>
      </div>

      <div className="bg-white rounded-[2rem] md:rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto scrollbar-hide">
          <table className="w-full text-left border-collapse min-w-[700px]">
            <thead>
              <tr className="bg-slate-50/50 text-slate-400 text-[10px] font-black uppercase tracking-widest border-b border-slate-50">
                <th className="px-6 md:px-10 py-6">Identity</th>
                <th className="px-6 md:px-10 py-6">Route Vector</th>
                <th className="px-6 md:px-10 py-6">Engagement</th>
                <th className="px-6 md:px-10 py-6 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {paginatedLeads.map((lead) => {
                return (
                  <tr key={lead.id} className="hover:bg-slate-50/80 transition-all cursor-pointer group" onClick={() => onSelectLead(lead.id)}>
                    <td className="px-6 md:px-10 py-6">
                      <div className="flex items-center gap-4">
                        <div className="flex flex-col">
                          <span className="font-black text-slate-900 text-xs md:text-sm">{lead.customerName}</span>
                          <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">{lead.id}</span>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 md:px-10 py-6">
                      <div className="flex flex-col">
                        <span className="text-xs md:text-sm font-bold text-slate-700">{lead.route}</span>
                        <span className="text-[9px] font-bold text-blue-500 uppercase tracking-widest mt-0.5">{lead.tripType}</span>
                      </div>
                    </td>
                    <td className="px-6 md:px-10 py-6">
                       <div className="flex flex-col">
                          <span className="text-xs md:text-sm font-bold text-slate-700">₹{lead.budget.toLocaleString()}</span>
                          <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">{new Date(lead.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}</span>
                       </div>
                    </td>
                    <td className="px-6 md:px-10 py-6 text-center">
                      <span className="text-[9px] font-black uppercase px-3 py-1.5 rounded-full bg-blue-50 text-blue-600 border border-blue-100">
                        {lead.status}
                      </span>
                    </td>
                  </tr>
                );
              })}
              {paginatedLeads.length === 0 && (
                <tr>
                  <td colSpan={4} className="py-24 text-center">
                    <i className="fas fa-inbox text-slate-100 text-5xl mb-4"></i>
                    <p className="text-[10px] font-black text-slate-300 uppercase tracking-widest">No active leads</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Lead Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
           <div 
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-md animate-fadeIn" 
            onClick={() => setIsAddModalOpen(false)}
           ></div>
           <div className="bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl relative z-10 animate-slideUp border border-slate-100 overflow-hidden">
              <div className="bg-blue-600 p-6 flex justify-between items-center text-white">
                 <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                       <i className="fas fa-user-plus"></i>
                    </div>
                    <div>
                       <h3 className="text-lg font-black tracking-tight uppercase leading-none">New Quick Lead</h3>
                       <p className="text-[9px] font-bold text-blue-300 uppercase tracking-widest mt-1">Manual Capture Node</p>
                    </div>
                 </div>
                 <button 
                  onClick={() => setIsAddModalOpen(false)} 
                  className="w-10 h-10 hover:bg-white/10 rounded-xl flex items-center justify-center transition-all"
                 >
                    <i className="fas fa-times"></i>
                 </button>
              </div>
              
              <form onSubmit={handleCreateLead} className="p-6 space-y-5">
                 <div className="space-y-4">
                    <div className="space-y-1.5">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Traveler Name</label>
                       <input 
                        required 
                        value={newLeadName}
                        onChange={(e) => setNewLeadName(e.target.value)}
                        placeholder="e.g. Rahul Verma" 
                        className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 font-bold text-slate-800 outline-none focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 transition-all" 
                       />
                    </div>
                    <div className="space-y-1.5">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Email Address</label>
                       <input 
                        required 
                        type="email"
                        value={newLeadEmail}
                        onChange={(e) => setNewLeadEmail(e.target.value)}
                        placeholder="rahul@example.com" 
                        className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 font-bold text-slate-800 outline-none focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 transition-all" 
                       />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                       <div className="space-y-1.5">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Origin Code</label>
                          <input 
                            required 
                            maxLength={3}
                            value={newLeadOrigin}
                            onChange={(e) => setNewLeadOrigin(e.target.value.toUpperCase())}
                            placeholder="BOM" 
                            className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 font-bold text-slate-800 outline-none text-center focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 transition-all" 
                          />
                       </div>
                       <div className="space-y-1.5">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Dest Code</label>
                          <input 
                            required 
                            maxLength={3}
                            value={newLeadDest}
                            onChange={(e) => setNewLeadDest(e.target.value.toUpperCase())}
                            placeholder="SIN" 
                            className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 font-bold text-slate-800 outline-none text-center focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 transition-all" 
                          />
                       </div>
                    </div>
                 </div>

                 <div className="pt-4 flex gap-4">
                    <button 
                      type="button" 
                      onClick={() => setIsAddModalOpen(false)}
                      className="flex-1 py-4 bg-slate-50 text-slate-500 font-black rounded-2xl border border-slate-100 uppercase tracking-widest text-[10px] hover:bg-slate-100 transition-all"
                    >
                       Discard
                    </button>
                    <button 
                      type="submit"
                      disabled={isProcessing}
                      className="flex-[2] py-4 bg-blue-600 text-white font-black rounded-2xl shadow-xl shadow-blue-500/20 hover:bg-blue-700 transition-all uppercase tracking-widest text-[10px] flex items-center justify-center gap-2"
                    >
                       {isProcessing ? <i className="fas fa-circle-notch animate-spin"></i> : <><i className="fas fa-check-circle"></i> Initialize Lead</>}
                    </button>
                 </div>
              </form>
           </div>
        </div>
      )}
    </div>
  );
};

export default LeadListPage;
