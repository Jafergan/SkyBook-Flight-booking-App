
import React, { useState } from 'react';

interface AdminSettingsPageProps {
  onBack: () => void;
  maintenanceMode: boolean;
  onToggleMaintenance: () => void;
}

const AdminSettingsPage: React.FC<AdminSettingsPageProps> = ({ onBack, maintenanceMode, onToggleMaintenance }) => {
  const [activeTab, setActiveTab] = useState('General');
  const [isSaving, setIsSaving] = useState(false);
  const [taxEngine, setTaxEngine] = useState<'IATA' | 'REGIONAL'>('IATA');
  const [isIataSyncing, setIsIataSyncing] = useState(false);

  // New state for Integrations functionality
  const [selectedIntegration, setSelectedIntegration] = useState<any>(null);
  const [isConnectProtocolOpen, setIsConnectProtocolOpen] = useState(false);
  const [isActionProcessing, setIsActionProcessing] = useState(false);

  const tabs = [
    { id: 'General', icon: 'fa-cog' },
    { id: 'Pricing', icon: 'fa-dollar-sign' },
    { id: 'Integrations', icon: 'fa-puzzle-piece' },
    { id: 'Notifications', icon: 'fa-bell' },
  ];

  const handleSave = () => {
    setIsSaving(true);
    setTimeout(() => setIsSaving(false), 1000);
  };

  const handleIataSync = () => {
    setIsIataSyncing(true);
    setTimeout(() => setIsIataSyncing(false), 2000);
  };

  const handleIntegrationAction = (type: 'settings' | 'connect') => {
    setIsActionProcessing(true);
    setTimeout(() => {
      setIsActionProcessing(false);
      setSelectedIntegration(null);
      setIsConnectProtocolOpen(false);
    }, 1500);
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'General':
        return (
          <div className="bg-white rounded-[3rem] border border-slate-100 shadow-sm p-10 space-y-10 h-fit animate-slideUp">
            <h3 className="text-2xl font-black text-slate-900 tracking-tight">General Preferences</h3>
            <div className="space-y-8">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">System Currency</label>
                <select className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 font-bold text-slate-800 outline-none">
                  <option>INR (₹) - Indian Rupee</option>
                  <option>USD ($) - US Dollar</option>
                </select>
              </div>

              <div className="pt-6 border-t border-slate-50">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <h4 className="text-sm font-black text-slate-900 uppercase">Maintenance Mode</h4>
                    <p className="text-xs font-medium text-slate-400">Force non-admin users to the maintenance page.</p>
                  </div>
                  <button 
                    onClick={onToggleMaintenance}
                    className={`w-14 h-8 rounded-full transition-all relative ${maintenanceMode ? 'bg-orange-500' : 'bg-slate-200'}`}
                  >
                    <div className={`absolute top-1 w-6 h-6 bg-white rounded-full shadow-md transition-all ${maintenanceMode ? 'right-1' : 'left-1'}`}></div>
                  </button>
                </div>
                {maintenanceMode && (
                  <div className="mt-4 p-4 bg-orange-50 rounded-2xl border border-orange-100 flex items-center gap-3 animate-fadeIn">
                    <i className="fas fa-exclamation-triangle text-orange-500 text-sm"></i>
                    <p className="text-[10px] font-bold text-orange-700 uppercase tracking-widest leading-relaxed">
                      Platform is currently locked for all users except administrators.
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        );
      case 'Pricing':
        return (
          <div className="bg-white rounded-[3rem] border border-slate-100 shadow-sm p-10 space-y-10 h-fit animate-slideUp">
            <h3 className="text-2xl font-black text-slate-900 tracking-tight">Financial Controls</h3>
            <div className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Global Service Fee</label>
                  <div className="relative">
                    <span className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400 font-bold">$</span>
                    <input type="number" defaultValue="15" className="w-full bg-slate-50 border border-slate-200 rounded-2xl pl-10 pr-6 py-4 font-bold text-slate-800 outline-none" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Agent Commission (%)</label>
                  <div className="relative">
                    <span className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400 font-bold">%</span>
                    <input type="number" defaultValue="5" className="w-full bg-slate-50 border border-slate-200 rounded-2xl pl-10 pr-6 py-4 font-bold text-slate-800 outline-none" />
                  </div>
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Tax Calculation Engine</label>
                <div className="flex p-1.5 bg-slate-100 rounded-2xl">
                  <button 
                    onClick={() => setTaxEngine('IATA')}
                    className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase transition-all ${taxEngine === 'IATA' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-400'}`}
                  >
                    Standard IATA
                  </button>
                  <button 
                    onClick={() => setTaxEngine('REGIONAL')}
                    className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase transition-all ${taxEngine === 'REGIONAL' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-400'}`}
                  >
                    Custom Regional
                  </button>
                </div>
              </div>

              {taxEngine === 'IATA' && (
                <div className="pt-6 border-t border-slate-100 space-y-6 animate-slideUp">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center text-xs">
                        <i className="fas fa-globe-americas"></i>
                      </div>
                      <h4 className="text-sm font-black text-slate-900 uppercase">Global IATA Standards</h4>
                    </div>
                    <button 
                      onClick={handleIataSync}
                      disabled={isIataSyncing}
                      className="text-[9px] font-black text-blue-600 uppercase tracking-widest hover:underline flex items-center gap-2"
                    >
                      {isIataSyncing ? <i className="fas fa-circle-notch animate-spin"></i> : <i className="fas fa-sync-alt"></i>}
                      {isIataSyncing ? 'Syncing...' : 'Force IATA Sync'}
                    </button>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-5 bg-slate-50 rounded-2xl border border-slate-100">
                      <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Standard Fuel Index (YQ)</p>
                      <p className="text-sm font-black text-slate-800">$12.40 <span className="text-[10px] text-slate-400 font-bold ml-1">/ SECTOR</span></p>
                    </div>
                    <div className="p-5 bg-slate-50 rounded-2xl border border-slate-100">
                      <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Ticketing Fee (YR)</p>
                      <p className="text-sm font-black text-slate-800">$2.50 <span className="text-[10px] text-slate-400 font-bold ml-1">/ PASSENGER</span></p>
                    </div>
                  </div>

                  <div className="p-4 bg-blue-50 rounded-2xl border border-blue-100 flex items-start gap-4">
                     <i className="fas fa-info-circle text-blue-600 mt-0.5"></i>
                     <div className="space-y-1">
                        <p className="text-[9px] font-black text-blue-800 uppercase tracking-widest">Global Clearing House v24.1</p>
                        <p className="text-[10px] font-medium text-blue-700 leading-relaxed">
                          Applying standard IATA BSP (Billing and Settlement Plan) rates for all international GDS ticketing. Currency conversion relies on daily mid-market parity scores.
                        </p>
                     </div>
                  </div>
                </div>
              )}

              {taxEngine === 'REGIONAL' && (
                <div className="pt-6 border-t border-slate-100 space-y-6 animate-slideUp">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center text-xs">
                      <i className="fas fa-map-location-dot"></i>
                    </div>
                    <h4 className="text-sm font-black text-slate-900 uppercase">Regional Tax Overrides</h4>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest">GST (Domestic)</label>
                      <input type="text" defaultValue="18%" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 font-bold text-slate-800 text-xs" />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest">VAT (Intl)</label>
                      <input type="text" defaultValue="5%" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 font-bold text-slate-800 text-xs" />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Local Levy</label>
                      <input type="text" defaultValue="₹250" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 font-bold text-slate-800 text-xs" />
                    </div>
                  </div>
                  <p className="text-[9px] font-bold text-slate-400 uppercase leading-relaxed">
                    Custom rules will prioritize regional node identifiers (e.g., APAC-IND-NODE-01) over global IATA base rates during GDS settlement.
                  </p>
                </div>
              )}
            </div>
          </div>
        );
      case 'Integrations':
        return (
          <div className="bg-white rounded-[3rem] border border-slate-100 shadow-sm p-10 space-y-10 h-fit animate-slideUp">
            <h3 className="text-2xl font-black text-slate-900 tracking-tight">GDS & Node Synchronization</h3>
            <div className="space-y-4">
              {[
                { name: 'Sabre GDS Hub', status: 'Connected', icon: 'fa-satellite-dish', endpoint: 'api.sabre.com/v5', key: '••••••••••••' },
                { name: 'Amadeus Neural Link', status: 'Connected', icon: 'fa-network-wired', endpoint: 'amadeus.node.cluster.net', key: '••••••••••••' },
                { name: 'Travelport Node', status: 'Standby', icon: 'fa-link-slash', endpoint: 'sync.travelport.gds', key: '••••••••••••' },
                { name: 'Stripe Payment Bridge', status: 'Operational', icon: 'fa-credit-card', endpoint: 'api.stripe.com/v1', key: '••••••••••••' },
              ].map((item, idx) => (
                <div key={idx} className="flex items-center justify-between p-6 bg-slate-50 rounded-[2rem] border border-slate-100 group hover:border-blue-200 transition-all">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-blue-600 shadow-sm">
                      <i className={`fas ${item.icon}`}></i>
                    </div>
                    <div>
                      <p className="text-sm font-black text-slate-900">{item.name}</p>
                      <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">Integration Node v5.0.2</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className={`text-[8px] font-black uppercase tracking-widest px-3 py-1 rounded-full ${item.status === 'Standby' ? 'bg-amber-100 text-amber-600' : 'bg-emerald-100 text-emerald-600'}`}>
                      {item.status}
                    </span>
                    <button 
                      onClick={() => setSelectedIntegration(item)}
                      className="w-8 h-8 rounded-lg bg-white border border-slate-200 text-slate-400 flex items-center justify-center hover:text-blue-600 transition-colors"
                    >
                      <i className="fas fa-cog text-[10px]"></i>
                    </button>
                  </div>
                </div>
              ))}
            </div>
            <button 
              onClick={() => setIsConnectProtocolOpen(true)}
              className="w-full py-4 border-2 border-dashed border-slate-200 rounded-[2rem] text-[10px] font-black uppercase text-slate-400 hover:text-blue-600 hover:border-blue-300 transition-all"
            >
              <i className="fas fa-plus mr-2"></i> Connect Custom Protocol
            </button>
          </div>
        );
      case 'Notifications':
        return (
          <div className="bg-white rounded-[3rem] border border-slate-100 shadow-sm p-10 space-y-10 h-fit animate-slideUp">
            <h3 className="text-2xl font-black text-slate-900 tracking-tight">System Broadcasting</h3>
            <div className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {[
                  { title: 'Email Alerts', desc: 'Auto-send booking summaries.' },
                  { title: 'Browser Pushes', desc: 'Real-time fare updates.' },
                  { title: 'Agent SMS', desc: 'Critical lead priority alerts.' },
                  { title: 'Customer Chat', desc: 'AI Concierge notifications.' },
                ].map((n, idx) => (
                  <div key={idx} className="flex items-center justify-between p-5 bg-slate-50 rounded-2xl border border-slate-100">
                    <div className="space-y-0.5">
                      <p className="text-xs font-black text-slate-900 uppercase">{n.title}</p>
                      <p className="text-[10px] font-medium text-slate-400">{n.desc}</p>
                    </div>
                    <button className="w-12 h-6 rounded-full bg-blue-600 relative">
                      <div className="absolute top-1 right-1 w-4 h-4 bg-white rounded-full"></div>
                    </button>
                  </div>
                ))}
              </div>
              <div className="pt-6 border-t border-slate-50 space-y-4">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Global System Message</label>
                <div className="flex gap-2">
                  <input type="text" placeholder="Emergency broadcast message..." className="flex-1 bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 font-bold text-slate-800 outline-none" />
                  <button className="px-8 bg-slate-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-black transition-all">Broadcast</button>
                </div>
              </div>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8 animate-fadeIn">
      <nav className="flex items-center gap-3 text-xs font-black uppercase tracking-widest text-slate-400">
        <button onClick={onBack} className="hover:text-blue-600 transition-colors">Home</button>
        <i className="fas fa-chevron-right text-[8px]"></i>
        <span>Admin</span>
        <i className="fas fa-chevron-right text-[8px]"></i>
        <span className="text-blue-600">Settings</span>
      </nav>

      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <button 
            onClick={onBack}
            className="mb-4 flex items-center gap-2 text-slate-400 hover:text-blue-600 transition-all group font-black text-[10px] uppercase tracking-widest w-fit"
          >
            <i className="fas fa-arrow-left group-hover:-translate-x-1 transition-transform"></i>
            Back to System Hub
          </button>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight leading-none">System Settings</h1>
          <p className="text-slate-500 font-medium mt-3">Configure global application settings and pricing rules.</p>
        </div>
        <button 
          onClick={handleSave}
          className="px-8 py-3 bg-blue-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-blue-500/20 hover:bg-blue-700 transition-all flex items-center gap-2"
        >
          {isSaving ? <i className="fas fa-circle-notch animate-spin"></i> : <i className="fas fa-save"></i>} 
          {isSaving ? 'Synchronizing...' : 'Save Changes'}
        </button>
      </div>

      <div className="flex border-b border-slate-100 gap-8 overflow-x-auto scrollbar-hide">
        {tabs.map(t => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id)}
            className={`flex items-center gap-3 pb-4 text-xs font-black uppercase tracking-widest transition-all relative whitespace-nowrap ${
              activeTab === t.id ? 'text-blue-600' : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <i className={`fas ${t.icon}`}></i>
            {t.id}
            {activeTab === t.id && <div className="absolute bottom-0 left-0 w-full h-1 bg-blue-600 rounded-full animate-fadeIn"></div>}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 pb-20">
        {renderTabContent()}
        
        {/* Help Card */}
        <div className="bg-slate-900 rounded-[3rem] p-10 text-white space-y-6 shadow-2xl relative overflow-hidden h-fit">
           <div className="absolute top-0 right-0 p-8 opacity-10">
              <i className="fas fa-brain text-8xl"></i>
           </div>
           <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center text-xl shadow-lg">
              <i className="fas fa-info-circle"></i>
           </div>
           <div className="space-y-2">
              <h4 className="text-xl font-black tracking-tight uppercase">Admin Guidance</h4>
              <p className="text-slate-400 font-medium text-sm leading-relaxed">
                Changes applied in this terminal affect all regional cluster nodes instantly. Neural Search markups and GDS handshake frequencies are optimized automatically based on system load.
              </p>
           </div>
           <div className="pt-6 border-t border-white/10 flex items-center gap-4">
              <div className="flex -space-x-2">
                 {[1,2,3].map(i => (
                    <img key={i} src={`https://i.pravatar.cc/100?u=${i}`} className="w-8 h-8 rounded-full border-2 border-slate-900 shadow-sm" alt="" />
                 ))}
              </div>
              <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">3 active admins currently monitoring node cluster.</p>
           </div>
        </div>
      </div>

      {/* Integration Settings Modal */}
      {selectedIntegration && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-md animate-fadeIn" onClick={() => setSelectedIntegration(null)}></div>
          <div className="bg-white w-full max-w-xl rounded-[2.5rem] shadow-2xl relative z-10 animate-slideUp border border-slate-100 overflow-hidden">
            <div className="bg-blue-600 p-8 flex justify-between items-center text-white">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                  <i className={`fas ${selectedIntegration.icon}`}></i>
                </div>
                <div>
                  <h3 className="text-xl font-black tracking-tight uppercase leading-none">{selectedIntegration.name}</h3>
                  <p className="text-[9px] font-bold text-blue-300 uppercase tracking-widest mt-1">Configure Node Endpoint</p>
                </div>
              </div>
              <button onClick={() => setSelectedIntegration(null)} className="w-10 h-10 hover:bg-white/10 rounded-xl flex items-center justify-center transition-all">
                <i className="fas fa-times"></i>
              </button>
            </div>
            <div className="p-8 space-y-6">
              <div className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">API Endpoint</label>
                  <input type="text" defaultValue={selectedIntegration.endpoint} className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 font-bold text-slate-800 outline-none focus:ring-4 focus:ring-blue-500/5 transition-all" />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Node Access Key</label>
                  <input type="password" defaultValue={selectedIntegration.key} className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 font-bold text-slate-800 outline-none focus:ring-4 focus:ring-blue-500/5 transition-all" />
                </div>
              </div>
              <div className="flex gap-4">
                <button 
                  onClick={() => setSelectedIntegration(null)}
                  className="flex-1 py-4 bg-slate-50 text-slate-500 font-black rounded-2xl border border-slate-100 uppercase tracking-widest text-[10px] hover:bg-slate-100 transition-all"
                >
                  Cancel
                </button>
                <button 
                  onClick={() => handleIntegrationAction('settings')}
                  disabled={isActionProcessing}
                  className="flex-[2] py-4 bg-blue-600 text-white font-black rounded-2xl shadow-xl shadow-blue-500/20 hover:bg-blue-700 transition-all uppercase tracking-widest text-[10px] flex items-center justify-center gap-2"
                >
                  {isActionProcessing ? <i className="fas fa-circle-notch animate-spin"></i> : 'Update Node'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Connect Custom Protocol Modal */}
      {isConnectProtocolOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-md animate-fadeIn" onClick={() => setIsConnectProtocolOpen(false)}></div>
          <div className="bg-white w-full max-w-xl rounded-[2.5rem] shadow-2xl relative z-10 animate-slideUp border border-slate-100 overflow-hidden">
            <div className="bg-slate-900 p-8 flex justify-between items-center text-white">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center">
                  <i className="fas fa-network-wired"></i>
                </div>
                <div>
                  <h3 className="text-xl font-black tracking-tight uppercase leading-none">New Protocol Node</h3>
                  <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-1">Register External Provider</p>
                </div>
              </div>
              <button onClick={() => setIsConnectProtocolOpen(false)} className="w-10 h-10 hover:bg-white/10 rounded-xl flex items-center justify-center transition-all">
                <i className="fas fa-times"></i>
              </button>
            </div>
            <div className="p-8 space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Provider Name</label>
                  <input type="text" placeholder="e.g. Travelport v2" className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 font-bold text-slate-800 outline-none focus:border-blue-500 transition-all" />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Protocol Type</label>
                  <select className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 font-bold text-slate-800 outline-none appearance-none">
                    <option>JSON REST API</option>
                    <option>XML / SOAP</option>
                    <option>GraphQL Mesh</option>
                    <option>gRPC Node</option>
                  </select>
                </div>
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Base Discovery URL</label>
                <input type="text" placeholder="https://api.provider.com/v1" className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 font-bold text-slate-800 outline-none focus:border-blue-500 transition-all" />
              </div>
              <div className="flex gap-4">
                <button 
                  onClick={() => setIsConnectProtocolOpen(false)}
                  className="flex-1 py-4 bg-slate-50 text-slate-500 font-black rounded-2xl border border-slate-100 uppercase tracking-widest text-[10px] hover:bg-slate-100 transition-all"
                >
                  Discard
                </button>
                <button 
                  onClick={() => handleIntegrationAction('connect')}
                  disabled={isActionProcessing}
                  className="flex-[2] py-4 bg-blue-600 text-white font-black rounded-2xl shadow-xl shadow-blue-500/20 hover:bg-blue-700 transition-all uppercase tracking-widest text-[10px] flex items-center justify-center gap-2"
                >
                  {isActionProcessing ? <i className="fas fa-circle-notch animate-spin"></i> : 'Initialize Connection'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminSettingsPage;
