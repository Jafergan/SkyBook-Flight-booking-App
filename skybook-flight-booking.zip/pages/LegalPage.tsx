import React, { useState, useEffect } from 'react';

interface LegalPageProps {
  onBack: () => void;
  initialTab?: 'Privacy Policy' | 'Terms of Service' | 'Cookie Policy' | 'Compliance';
  isPublic?: boolean;
}

const LegalPage: React.FC<LegalPageProps> = ({ onBack, initialTab, isPublic = false }) => {
  const [activeTab, setActiveTab] = useState<'Privacy Policy' | 'Terms of Service' | 'Cookie Policy' | 'Compliance'>(initialTab || 'Privacy Policy');

  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);

  const policies = {
    'Privacy Policy': [
      { title: '1. Introduction', content: 'Welcome to SkyBook. We respect your privacy and are committed to protecting your personal data.' },
      { title: '2. Data Collection', content: 'We collect information you provide directly to us, such as when you create an account, make a booking, or contact support.' },
      { title: '3. Data Usage', content: 'Your data is used to process transactions, provide customer support, and improve our flight intelligence algorithms.' }
    ],
    'Terms of Service': [
      { title: '1. Service Agreement', content: 'By accessing or using the SkyBook platform, you agree to be bound by these terms.' },
      { title: '2. Booking Rules', content: 'All bookings made through SkyBook are subject to the fare rules and policies of the respective airline carriers.' },
      { title: '3. Liability', content: 'SkyBook acts as an intermediary between travelers and service providers and is not liable for flight delays or cancellations.' }
    ],
    'Cookie Policy': [
      { title: '1. Use of Cookies', content: 'We use cookies to improve your browsing experience and analyze our traffic.' },
      { title: '2. Types of Cookies', content: 'We use essential, analytical, and marketing cookies to provide a seamless travel booking experience.' }
    ],
    'Compliance': [
      { title: '1. IATA Certification', content: 'SkyBook is fully compliant with International Air Transport Association (IATA) standards for ticketing and agent operations.' },
      { title: '2. PCI-DSS Security', content: 'Our payment processing systems are Level 1 PCI-DSS certified, ensuring your credit card data is handled with maximum security.' },
      { title: '3. GDPR & Data Privacy', content: 'We adhere to General Data Protection Regulation (GDPR) standards for all users, providing full control over data deletion and portability.' },
      { title: '4. Anti-Fraud Protocols', content: 'Our v5.0 Neural Engine continuously monitors for suspicious booking patterns to prevent fraudulent transactions.' }
    ]
  };

  return (
    <div className={`min-h-screen ${isPublic ? 'bg-slate-50 py-16' : 'p-8'} animate-fadeIn`}>
      <div className={`max-w-6xl mx-auto space-y-8 ${isPublic ? 'px-6' : ''}`}>
        <div className="space-y-4">
          <button 
            onClick={onBack}
            className="flex items-center gap-2 text-slate-400 hover:text-blue-600 transition-all group font-black text-[10px] uppercase tracking-widest w-fit"
          >
            <i className="fas fa-arrow-left group-hover:-translate-x-1 transition-transform"></i>
            {isPublic ? 'Return to Homepage' : 'Return to Dashboard'}
          </button>
          <div className="flex items-center gap-3">
            {isPublic && (
              <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-lg">
                <i className="fas fa-plane-departure text-sm"></i>
              </div>
            )}
            <h1 className="text-4xl font-black text-slate-900 tracking-tight leading-none">Legal & Compliance</h1>
          </div>
          <p className="text-slate-500 font-medium text-lg leading-relaxed max-w-3xl">Transparency and security are the core pillars of our partnership.</p>
        </div>

        <div className="flex border-b border-slate-200 gap-8 overflow-x-auto scrollbar-hide">
          {Object.keys(policies).map((tab) => (
            <button 
              key={tab} 
              onClick={() => setActiveTab(tab as any)} 
              className={`pb-4 text-sm font-black uppercase tracking-widest transition-all relative whitespace-nowrap ${activeTab === tab ? 'text-blue-600' : 'text-slate-400 hover:text-slate-600'}`}
            >
              {tab}
              {activeTab === tab && <div className="absolute bottom-0 left-0 w-full h-1 bg-blue-600 rounded-full animate-fadeIn"></div>}
            </button>
          ))}
        </div>

        <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-xl shadow-slate-200/50 overflow-hidden p-12 space-y-12">
            {policies[activeTab].map((section, idx) => (
              <div key={idx} className="space-y-4">
                <h2 className="text-2xl font-black text-slate-900 tracking-tight">{section.title}</h2>
                <p className="text-slate-500 font-medium leading-relaxed text-lg">{section.content}</p>
              </div>
            ))}
            
            {activeTab === 'Compliance' && (
              <div className="pt-8 border-t border-slate-50 grid grid-cols-1 md:grid-cols-2 gap-6">
                 <div className="p-6 bg-slate-50 rounded-2xl flex items-center gap-4 border border-slate-100/50">
                    <div className="w-12 h-12 bg-white rounded-xl shadow-sm flex items-center justify-center text-blue-600">
                       <i className="fas fa-certificate"></i>
                    </div>
                    <div>
                       <p className="text-xs font-black text-slate-900 uppercase">ISO 27001 Certified</p>
                       <p className="text-[10px] font-bold text-slate-400">Information Security Management</p>
                    </div>
                 </div>
                 <div className="p-6 bg-slate-50 rounded-2xl flex items-center gap-4 border border-slate-100/50">
                    <div className="w-12 h-12 bg-white rounded-xl shadow-sm flex items-center justify-center text-emerald-600">
                       <i className="fas fa-user-shield"></i>
                    </div>
                    <div>
                       <p className="text-xs font-black text-slate-900 uppercase">SLA 99.99% Guarantee</p>
                       <p className="text-[10px] font-bold text-slate-400">Enterprise Reliability Standard</p>
                    </div>
                 </div>
              </div>
            )}
        </div>

        {isPublic && (
          <div className="text-center pt-12">
            <p className="text-[10px] font-black text-slate-300 uppercase tracking-[0.3em]">
              © 2025 SkyBook Global Operations. All documentation is legally binding.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default LegalPage;