import React, { useState, useRef } from 'react';

interface ProfileSetupPageProps {
  onContinue: (data: { name: string; avatar: string | null }) => void;
}

const ProfileSetupPage: React.FC<ProfileSetupPageProps> = ({ onContinue }) => {
  const [name, setName] = useState('');
  const [avatar, setAvatar] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFile = (file: File) => {
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => setAvatar(e.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center p-6 animate-fadeIn">
      <div className="max-w-md w-full space-y-10">
        <div className="text-center space-y-4">
          <div className="inline-block px-4 py-1.5 bg-blue-50 text-blue-600 rounded-full text-[10px] font-black uppercase tracking-widest border border-blue-100 mb-2">
             Profile Discovery
          </div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight leading-none">Who's flying?</h1>
          <p className="text-slate-500 font-medium">Tell us about yourself to personalize your SkyBook dashboard.</p>
        </div>

        <div className="space-y-8">
          <div className="flex flex-col items-center gap-6">
            <div 
              onClick={() => fileInputRef.current?.click()}
              onDragOver={e => e.preventDefault()}
              onDrop={e => { e.preventDefault(); handleFile(e.dataTransfer.files[0]); }}
              className="w-32 h-32 rounded-[2.5rem] bg-slate-50 border-2 border-dashed border-slate-200 flex items-center justify-center cursor-pointer hover:border-blue-400 transition-all overflow-hidden group relative"
            >
              <input 
                ref={fileInputRef}
                type="file"
                className="hidden"
                accept="image/*"
                onChange={e => e.target.files && handleFile(e.target.files[0])}
              />
              {avatar ? (
                <img src={avatar} className="w-full h-full object-cover" alt="Profile" />
              ) : (
                <div className="text-center">
                  <i className="fas fa-camera text-slate-300 text-xl group-hover:text-blue-500 transition-colors"></i>
                  <p className="text-[8px] font-black text-slate-400 uppercase mt-2">Upload Image</p>
                </div>
              )}
              <div className="absolute inset-0 bg-blue-600/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-sm">
                <p className="text-white text-[9px] font-black uppercase tracking-widest">Click or Drag</p>
              </div>
            </div>
            <p className="text-[9px] font-black text-slate-300 uppercase tracking-widest">Preferred Dimensions: 1:1 Aspect Ratio</p>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Full Legal Name</label>
              <input 
                type="text" 
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="e.g. Alex Johnson"
                className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 font-bold text-slate-800 outline-none focus:ring-4 focus:ring-blue-500/10 transition-all"
              />
            </div>
          </div>

          <button
            onClick={() => onContinue({ name, avatar })}
            disabled={!name}
            className="w-full bg-blue-600 text-white font-black py-5 rounded-2xl shadow-xl shadow-blue-500/20 hover:bg-blue-700 transition-all flex items-center justify-center gap-3 disabled:opacity-50"
          >
            Continue Discovery <i className="fas fa-arrow-right"></i>
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProfileSetupPage;