import React, { useState, useEffect } from 'react';
import { User, UserRole } from '../types';

interface AdminUserManagementPageProps {
  onBack: () => void;
}

const AdminUserManagementPage: React.FC<AdminUserManagementPageProps> = ({ onBack }) => {
  const [users, setUsers] = useState<User[]>([
    { id: '1', name: 'Ankit Patel', email: 'ankit.patel@skybook.com', role: UserRole.AGENT, avatar: '', status: 'Active', lastActive: '2 mins ago' },
    { id: '2', name: 'Sarah Miller', email: 'sarah.m@skybook.com', role: UserRole.ADMIN, avatar: '', status: 'Active', lastActive: '1 hour ago' },
    { id: '3', name: 'John Doe', email: 'john.doe@freelancer.net', role: UserRole.AGENT, avatar: '', status: 'Inactive', lastActive: '2 days ago' },
    { id: '4', name: 'Emily Chen', email: 'emily.chen@skybook.com', role: UserRole.ADMIN, avatar: '', status: 'Active', lastActive: 'Yesterday' },
    { id: '5', name: 'Michael Khan', email: 'm.khan@skybook.com', role: UserRole.AGENT, avatar: '', status: 'Suspended', lastActive: '5 hours ago' },
  ]);

  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  // Form state for new user
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newRole, setNewRole] = useState<UserRole>(UserRole.AGENT);

  useEffect(() => {
    const handleGlobalClick = () => setActiveMenu(null);
    window.addEventListener('click', handleGlobalClick);
    return () => window.removeEventListener('click', handleGlobalClick);
  }, []);

  const handleAction = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setActiveMenu(activeMenu === id ? null : id);
  };

  const handleStatusChange = (id: string, nextStatus: 'Active' | 'Inactive' | 'Suspended') => {
    setUsers(prev => prev.map(u => u.id === id ? { ...u, status: nextStatus } : u));
    setActiveMenu(null);
  };

  const handleDeleteUser = (id: string) => {
    if (window.confirm("Confirm permanent decommissioning of this user node? This action is logged.")) {
      setUsers(prev => prev.filter(u => u.id !== id));
    }
    setActiveMenu(null);
  };

  const handleAddUser = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    
    const newUser: User = {
      id: `U-${Date.now()}`,
      name: newName,
      email: newEmail,
      role: newRole,
      avatar: '', // Maintaining minimalist text-only identity
      status: 'Active',
      lastActive: 'Just now'
    };

    setTimeout(() => {
      setUsers(prev => [newUser, ...prev]);
      setIsProcessing(false);
      setIsAddModalOpen(false);
      setNewName('');
      setNewEmail('');
    }, 1200);
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8 animate-fadeIn relative">
       <nav className="flex items-center gap-3 text-xs font-black uppercase tracking-widest text-slate-400">
        <button onClick={onBack} className="hover:text-blue-600 transition-colors">Home</button>
        <i className="fas fa-chevron-right text-[8px] opacity-30"></i>
        <span>Settings</span>
        <i className="fas fa-chevron-right text-[8px] opacity-30"></i>
        <span className="text-blue-600">Users</span>
      </nav>

      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <button 
            onClick={onBack}
            className="mb-4 flex items-center gap-2 text-slate-400 hover:text-blue-600 transition-all group font-black text-[10px] uppercase tracking-widest w-fit"
          >
            <i className="fas fa-arrow-left group-hover:-translate-x-1 transition-transform"></i>
            Back to Control Center
          </button>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight leading-none">User Management</h1>
          <p className="text-slate-500 font-medium mt-3">Manage team members and access permissions.</p>
        </div>
        <button 
          onClick={() => setIsAddModalOpen(true)}
          className="px-8 py-4 bg-blue-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-blue-500/20 hover:bg-blue-700 transition-all flex items-center gap-2"
        >
          <i className="fas fa-plus"></i> Add New User
        </button>
      </div>

      <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-visible">
        <div className="overflow-x-auto overflow-y-visible">
          <table className="w-full text-left">
            <thead>
              <tr className="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-50">
                <th className="px-10 py-6">User Identity</th>
                <th className="px-10 py-6">Operational Role</th>
                <th className="px-10 py-6">Network Status</th>
                <th className="px-10 py-6 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {users.map((user) => (
                <tr key={user.id} className="hover:bg-slate-50/50 transition-colors group cursor-pointer relative overflow-visible">
                  <td className="px-10 py-7">
                    <div className="flex flex-col">
                       <p className="font-black text-slate-900 text-sm tracking-tight">{user.name}</p>
                       <p className="text-[11px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">{user.email}</p>
                    </div>
                  </td>
                  <td className="px-10 py-7">
                     <div className="flex items-center gap-2">
                        <i className={`fas ${user.role === UserRole.ADMIN ? 'fa-shield-halved text-slate-900' : 'fa-user-tie text-blue-500'} text-[10px]`}></i>
                        <span className="text-sm font-black text-slate-800 uppercase tracking-tighter">{user.role}</span>
                     </div>
                  </td>
                  <td className="px-10 py-7">
                    <span className={`px-4 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest border ${
                      user.status === 'Active' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' :
                      user.status === 'Suspended' ? 'bg-red-50 text-red-600 border-red-100' :
                      'bg-slate-50 text-slate-500 border-slate-100'
                    }`}>
                      {user.status}
                    </span>
                  </td>
                  <td className="px-10 py-7 text-right relative">
                    <button 
                      onClick={(e) => handleAction(e, user.id)}
                      className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${activeMenu === user.id ? 'bg-slate-900 text-white' : 'text-slate-300 hover:bg-slate-100 hover:text-slate-900'}`}
                    >
                      <i className="fas fa-ellipsis-v"></i>
                    </button>

                    {activeMenu === user.id && (
                      <div className="absolute right-10 top-16 w-56 bg-white rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.15)] border border-slate-100 z-50 py-2 animate-slideUp overflow-hidden">
                         <div className="px-4 py-2 border-b border-slate-50">
                            <p className="text-[8px] font-black text-slate-300 uppercase tracking-[0.2em]">Management Node</p>
                         </div>
                         <button 
                          onClick={() => handleStatusChange(user.id, user.status === 'Active' ? 'Suspended' : 'Active')}
                          className="w-full px-4 py-3 text-left hover:bg-blue-50 flex items-center gap-3 transition-colors group"
                         >
                            <i className={`fas ${user.status === 'Active' ? 'fa-pause text-orange-500' : 'fa-play text-emerald-500'} text-[10px]`}></i>
                            <span className="text-[10px] font-black text-slate-700 uppercase tracking-widest group-hover:text-blue-600">
                               {user.status === 'Active' ? 'Suspend Node' : 'Initialize Node'}
                            </span>
                         </button>
                         <button className="w-full px-4 py-3 text-left hover:bg-blue-50 flex items-center gap-3 transition-colors group">
                            <i className="fas fa-key text-blue-400 text-[10px]"></i>
                            <span className="text-[10px] font-black text-slate-700 uppercase tracking-widest group-hover:text-blue-600">Reset Security</span>
                         </button>
                         <div className="h-px bg-slate-50 my-1"></div>
                         <button 
                          onClick={() => handleDeleteUser(user.id)}
                          className="w-full px-4 py-3 text-left hover:bg-red-50 flex items-center gap-3 transition-colors group"
                         >
                            <i className="fas fa-trash-alt text-red-400 text-[10px]"></i>
                            <span className="text-[10px] font-black text-red-600 uppercase tracking-widest">Terminate Access</span>
                         </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add User Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
           <div 
            className="absolute inset-0 bg-slate-950/60 backdrop-blur-md animate-fadeIn" 
            onClick={() => setIsAddModalOpen(false)}
           ></div>
           <div className="bg-white w-full max-w-md rounded-[2.8rem] shadow-[0_30px_90px_rgba(0,0,0,0.3)] relative z-10 animate-slideUp border border-slate-100 overflow-hidden">
              <div className="bg-slate-900 p-8 flex justify-between items-center text-white">
                 <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center shadow-lg border border-blue-500">
                       <i className="fas fa-user-plus text-lg"></i>
                    </div>
                    <div>
                       <h3 className="text-xl font-black tracking-tight uppercase leading-none">Register User</h3>
                       <p className="text-[9px] font-bold text-blue-400 uppercase tracking-[0.2em] mt-1.5">New System Node</p>
                    </div>
                 </div>
                 <button 
                  onClick={() => setIsAddModalOpen(false)} 
                  className="w-10 h-10 hover:bg-white/10 rounded-xl flex items-center justify-center transition-all"
                 >
                    <i className="fas fa-times"></i>
                 </button>
              </div>
              
              <form onSubmit={handleAddUser} className="p-10 space-y-8">
                 <div className="space-y-5">
                    <div className="space-y-1.5">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Full Identity Name</label>
                       <input 
                        required 
                        value={newName}
                        onChange={(e) => setNewName(e.target.value)}
                        placeholder="e.g. Rahul Verma" 
                        className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 font-bold text-slate-800 outline-none focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 transition-all" 
                       />
                    </div>
                    <div className="space-y-1.5">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Operational Email</label>
                       <input 
                        required 
                        type="email"
                        value={newEmail}
                        onChange={(e) => setNewEmail(e.target.value)}
                        placeholder="r.verma@skybook.com" 
                        className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 font-bold text-slate-800 outline-none focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 transition-all" 
                       />
                    </div>
                    <div className="space-y-1.5">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Access Protocol (Role)</label>
                       <div className="flex p-1.5 bg-slate-100 rounded-2xl gap-1">
                          <button 
                            type="button"
                            onClick={() => setNewRole(UserRole.AGENT)}
                            className={`flex-1 py-3 text-[10px] font-black uppercase rounded-xl transition-all ${newRole === UserRole.AGENT ? 'bg-white shadow-sm text-blue-600' : 'text-slate-400'}`}
                          >
                            Agent
                          </button>
                          <button 
                            type="button"
                            onClick={() => setNewRole(UserRole.ADMIN)}
                            className={`flex-1 py-3 text-[10px] font-black uppercase rounded-xl transition-all ${newRole === UserRole.ADMIN ? 'bg-white shadow-sm text-slate-900' : 'text-slate-400'}`}
                          >
                            Admin
                          </button>
                       </div>
                    </div>
                 </div>

                 <div className="pt-4 flex gap-4">
                    <button 
                      type="button" 
                      onClick={() => setIsAddModalOpen(false)}
                      className="flex-1 py-5 bg-slate-50 text-slate-500 font-black rounded-2xl border border-slate-100 uppercase tracking-widest text-[10px] hover:bg-slate-100 transition-all"
                    >
                       Abort
                    </button>
                    <button 
                      type="submit"
                      disabled={isProcessing || !newName || !newEmail}
                      className="flex-[2] py-5 bg-blue-600 text-white font-black rounded-2xl shadow-xl shadow-blue-500/20 hover:bg-blue-700 transition-all uppercase tracking-[0.2em] text-[10px] flex items-center justify-center gap-3 active:scale-95 disabled:opacity-50"
                    >
                       {isProcessing ? <i className="fas fa-circle-notch animate-spin"></i> : <><i className="fas fa-check-circle"></i> Initialize Node</>}
                    </button>
                 </div>
              </form>
              <div className="bg-slate-50 py-4 text-center border-t border-slate-100">
                 <p className="text-[8px] font-black text-slate-300 uppercase tracking-[0.3em]">SkyBook Authentication Layer v5.0.2</p>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default AdminUserManagementPage;