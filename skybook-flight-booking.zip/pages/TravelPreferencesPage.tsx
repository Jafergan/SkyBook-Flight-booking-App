import React, { useState } from 'react';

interface TravelPreferencesPageProps {
  onComplete: () => void;
}

const TravelPreferencesPage: React.FC<TravelPreferencesPageProps> = ({ onComplete }) => {
  const [style, setStyle] = useState('Luxury');
  const [regions, setRegions] = useState<string[]>([]);

  const toggleRegion = (reg: string) => {
    setRegions(prev => prev.includes(reg) ? prev.filter(r => r !== reg) : [...prev, reg]);
  };

  return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center p-6 animate-fadeIn">
      <div className="max-w-2xl w-full space-y-12">
        <div className="text-center space-y-4">
          <div className="inline-block px-4 py-1.5 bg-emerald-50 text-emerald-600 rounded-full text-[10px] font-black uppercase tracking-widest border border-emerald-100 mb-2">
             Final Phase
          </div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight leading-none">Your Travel DNA</h1>
          <p className="text-slate-500 font-medium">Fine-tune the neural search engine for your specific needs.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <div className="space-y-6">
            <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest border-l-4 border-blue-600 pl-4">Travel Style</h3>
            <div className="space-y-3">
              {['Luxury Explorer', 'Efficiency Focused', 'Budget Architect', 'Adventure Seeker'].map(s => (
                <button 
                  key={s}
                  onClick={() => setStyle(s)}
                  className={`w-full p-5 rounded-2xl border-2 transition-all text-left group ${style === s ? 'bg-blue-600 border-blue-600 text-white shadow-lg' : 'bg-slate-50 border-slate-100 text-slate-500 hover:border-blue-200 hover:bg-white'}`}
                >
                  <p className={`text-xs font-black uppercase tracking-widest ${style === s ? 'text-blue-100' : 'text-slate-400 group-hover:text-blue-400'}`}>Mode</p>
                  <p className="text-sm font-bold mt-1">{s}</p>
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-6">
            <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest border-l-4 border-emerald-500 pl-4">Priority Sectors</h3>
            <div className="flex flex-wrap gap-3">
              {['Europe', 'Asia-Pacific', 'Middle East', 'Americas', 'Oceania', 'Africa'].map(r => (
                <button 
                  key={r}
                  onClick={() => toggleRegion(r)}
                  className={`px-6 py-3 rounded-xl border-2 font-bold text-xs transition-all ${regions.includes(r) ? 'bg-emerald-500 border-emerald-500 text-white shadow-md' : 'bg-white border-slate-100 text-slate-500 hover:border-emerald-200'}`}
                >
                  {r}
                </button>
              ))}
            </div>
            <div className="bg-slate-50 p-6 rounded-3xl border border-slate-100 space-y-3">
              <div className="flex items-center gap-3">
                <i className="fas fa-bolt text-blue-500 text-xs"></i>
                <h4 className="text-[10px] font-black text-slate-800 uppercase tracking-widest">Neural Tip</h4>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed font-medium">
                Selecting priority sectors allows our AI to prioritize GDS node syncs for those specific flight paths.
              </p>
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-100 flex flex-col items-center gap-4">
          <button
            onClick={onComplete}
            className="w-full bg-slate-900 text-white font-black py-5 rounded-2xl shadow-2xl hover:bg-black transition-all flex items-center justify-center gap-3 uppercase tracking-[0.2em] text-xs"
          >
            Launch SkyBook Terminal <i className="fas fa-rocket"></i>
          </button>
          <p className="text-[10px] font-bold text-slate-300 uppercase tracking-widest">Initialization sequence complete • v5.0 Active</p>
        </div>
      </div>
    </div>
  );
};

export default TravelPreferencesPage;