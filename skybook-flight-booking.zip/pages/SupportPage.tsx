
import React, { useState, useMemo, useEffect } from 'react';
import { getSupportResolution } from '../services/geminiService';

interface SupportPageProps {
  onBack: () => void;
}

const SupportPage: React.FC<SupportPageProps> = ({ onBack }) => {
  const [expandedId, setExpandedId] = useState<number | null>(0);
  const [isConnecting, setIsConnecting] = useState(false);
  const [connectionStep, setConnectionStep] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [aiAnswer, setAiAnswer] = useState<string | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);
  
  // Technical Wiki States
  const [isWikiOpen, setIsWikiOpen] = useState(false);
  const [activeWikiTab, setActiveWikiTab] = useState('Core API');

  const faqs = [
    { id: 0, q: "How do I process a flight cancellation refund?", a: "Refunds can be initiated from the \"Bookings\" tab. Select the booking ID, click \"Modify,\" and choose \"Cancel & Refund.\"" },
    { id: 1, q: "Why is my lead not showing in the CRM?", a: "Ensure you have the correct filters applied. If newly captured, try refreshing the dashboard." },
    { id: 2, q: "Can I manage multiple agency accounts?", a: "Yes, our Master Admin panel allows for multi-tenant agency management with shared inventory access." },
    { id: 3, q: "What are the API rate limits for GDS syncing?", a: "Standard enterprise accounts are limited to 1,00,000 queries per minute to ensure zero-latency performance." },
    { id: 4, q: "How to update my agency profile details?", a: "Navigate to the Profile page from the top-right menu to update your logo, name, and contact information." },
    { id: 5, q: "Is there a mobile app for SkyBook?", a: "SkyBook is currently a web-first responsive platform, optimized for tablet and mobile browser access." }
  ];

  const filteredFaqs = useMemo(() => {
    if (!searchQuery.trim()) return faqs;
    const lowerQuery = searchQuery.toLowerCase();
    return faqs.filter(faq => 
      faq.q.toLowerCase().includes(lowerQuery) || 
      faq.a.toLowerCase().includes(lowerQuery)
    );
  }, [searchQuery]);

  // AI-Powered Search Effect
  useEffect(() => {
    if (!searchQuery.trim() || searchQuery.length < 4) {
      setAiAnswer(null);
      return;
    }

    const timer = setTimeout(async () => {
      setIsAiLoading(true);
      const resolution = await getSupportResolution(searchQuery);
      setAiAnswer(resolution);
      setIsAiLoading(false);
    }, 800); 

    return () => clearTimeout(timer);
  }, [searchQuery]);

  const handleLiveChat = () => {
    setIsConnecting(true);
    setConnectionStep(1);
    
    setTimeout(() => setConnectionStep(2), 1500);
    setTimeout(() => setConnectionStep(3), 3000);
    setTimeout(() => {
      setIsConnecting(false);
      setConnectionStep(0);
      const chatBtn = document.querySelector('button .fa-brain')?.parentElement;
      if (chatBtn) (chatBtn as HTMLButtonElement).click();
    }, 4500);
  };

  const handleEmailSupport = () => {
    window.location.href = "mailto:concierge@skybook.aero?subject=Urgent Assistance Required - SkyBook Terminal v5.0";
  };

  const handleHotline = () => {
    window.location.href = "tel:+18007592665";
  };

  const contactChannels = [
    { label: 'Live Chat', icon: 'fa-comment-dots', color: 'blue', action: handleLiveChat, desc: 'Average wait: < 1 min' },
    { label: 'Email Support', icon: 'fa-envelope', color: 'indigo', action: handleEmailSupport, desc: 'Response within 2 hours' },
    { label: 'Urgent Hotline', icon: 'fa-phone-alt', color: 'emerald', action: handleHotline, desc: 'Available 24/7/365' },
  ];

  // Wiki Content Database
  const wikiSectors = [
    { 
      id: 'Core API', 
      icon: 'fa-code', 
      title: 'RESTful GDS Bridge',
      desc: 'Interface with the global flight inventory via our v5.0 endpoint architecture.',
      content: `POST /v5/booking/initialize
Content-Type: application/json
Auth: Bearer {TERMINAL_TOKEN}

{
  "origin": "BOM",
  "destination": "LHR",
  "pax_count": 2,
  "cabin_class": "PREMIUM_ECONOMY"
}`
    },
    { 
      id: 'GDS Protocol', 
      icon: 'fa-satellite-dish', 
      title: 'Low-Level Synchronization',
      desc: 'Managing handshake sequences for Sabre, Amadeus, and Travelport nodes.',
      content: `// Handshake Sequence v5.02
SYNC_GDS_NODE(CLUSTER_ID: "IND_01")
  .on("handshake", (e) => VERIFY_CRC(e.checksum))
  .on("ready", () => INITIALIZE_CACHE_REBUILD())`
    },
    { 
      id: 'Security v5', 
      icon: 'fa-user-shield', 
      title: 'Matrix Encryption',
      desc: 'Multi-layer security protocols protecting agent credentials and traveler PII.',
      content: `Standard: ISO 27001 / PCI-DSS Level 1
Encryption: AES-256-GCM (RSA-4096 Hybrid)
TTL: 3600s (Session Expiry)
Scope: Global GDS Data Nodes`
    },
    { 
      id: 'Neural Engine', 
      icon: 'fa-brain', 
      title: 'Predictive Intelligence',
      desc: 'The logic behind SkyBook price forecasting and search optimization.',
      content: `ML Model: Transformer v3.5 (Optimized for Travel)
Weights: [RouteHistory, SeasonalLoad, FuelIndex, CurrencyDelta]
Inference: < 12ms
Accuracy: 98.4% Confidence Interval`
    }
  ];

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-8 md:space-y-12 animate-fadeIn relative">
      <style>{`
        @keyframes neural-pulse {
          0% { box-shadow: 0 0 0 0 rgba(37, 99, 235, 0.4); }
          70% { box-shadow: 0 0 0 15px rgba(37, 99, 235, 0); }
          100% { box-shadow: 0 0 0 0 rgba(37, 99, 235, 0); }
        }
        .ai-glow {
          animation: neural-pulse 2s infinite;
        }
      `}</style>

      {/* Search Header Section */}
      <div className="space-y-8">
        <div className="flex flex-col gap-4">
          <nav className="flex items-center gap-3 text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">
            <button onClick={onBack} className="hover:text-blue-600 transition-colors">Dashboard</button>
            <i className="fas fa-chevron-right text-[8px] opacity-30"></i>
            <span className="text-blue-600">Resource Center</span>
          </nav>
          
          <button 
            onClick={onBack}
            className="flex items-center gap-2 text-slate-400 hover:text-blue-600 transition-all group font-black text-[10px] uppercase tracking-widest w-fit"
          >
            <i className="fas fa-arrow-left group-hover:-translate-x-1 transition-transform"></i>
            Back to Workspace
          </button>
        </div>

        <div className="max-w-3xl space-y-4">
          <h1 className="text-3xl md:text-5xl font-black text-slate-900 tracking-tight leading-none">How can we help?</h1>
          <p className="text-slate-500 font-medium text-lg">Search our global knowledge base or connect with an elite travel strategist.</p>
        </div>

        <div className="relative w-full max-w-3xl group">
           <i className={`fas ${isAiLoading ? 'fa-circle-notch animate-spin' : 'fa-search'} absolute left-7 top-1/2 -translate-y-1/2 ${isAiLoading ? 'text-blue-500' : 'text-slate-300'} group-focus-within:text-blue-500 transition-colors`}></i>
           <input 
            type="text" 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Ask our AI about booking protocols, API documentation, or help articles..." 
            className={`w-full bg-white border border-slate-100 rounded-[2.5rem] py-6 pl-16 pr-8 text-sm font-bold outline-none shadow-xl shadow-blue-500/5 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all ${isAiLoading ? 'ai-glow' : ''}`} 
           />
        </div>
      </div>

      {/* AI Response Area */}
      {(aiAnswer || isAiLoading) && (
        <div className="max-w-3xl animate-slideUp">
           <div className="bg-gradient-to-br from-indigo-900 via-blue-900 to-slate-900 rounded-[3rem] p-10 text-white shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 right-0 p-8 opacity-10">
                <i className="fas fa-brain text-9xl"></i>
              </div>
              <div className="relative z-10 space-y-6">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-white/20 backdrop-blur-xl rounded-xl flex items-center justify-center border border-white/10">
                       <i className="fas fa-bolt text-blue-300"></i>
                    </div>
                    <div>
                      <h4 className="text-sm font-black uppercase tracking-widest">Neural Concierge Intelligence</h4>
                      <p className="text-[9px] font-bold text-blue-300 uppercase tracking-[0.2em]">Protocol v5.0 Live Node</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-full">
                     <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse"></span>
                     <span className="text-[8px] font-black text-emerald-400 uppercase tracking-widest">Real-time Stream</span>
                  </div>
                </div>

                {isAiLoading ? (
                  <div className="space-y-4 py-4">
                    <div className="h-4 bg-white/10 rounded-full w-3/4 animate-pulse"></div>
                    <div className="h-4 bg-white/10 rounded-full w-1/2 animate-pulse"></div>
                  </div>
                ) : (
                  <p className="text-lg font-medium leading-relaxed text-blue-50/90 italic">
                    "{aiAnswer}"
                  </p>
                )}

                <div className="pt-6 border-t border-white/10 flex items-center justify-between">
                   <p className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em]">Generated for your session</p>
                   <div className="flex gap-2">
                      <button className="text-[9px] font-black uppercase tracking-widest px-4 py-2 bg-white/10 rounded-xl hover:bg-white/20 transition-all">Report Error</button>
                      <button className="text-[9px] font-black uppercase tracking-widest px-4 py-2 bg-blue-500 text-white rounded-xl hover:bg-blue-600 transition-all shadow-lg">Copy Resolution</button>
                   </div>
                </div>
              </div>
           </div>
        </div>
      )}

      {/* Main Support Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 md:gap-12">
        {/* Support Channels */}
        <div className="lg:col-span-8 space-y-12">
          <div className="space-y-8">
            <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-6 flex items-center gap-4">
              <span className="w-10 h-px bg-slate-100"></span> Priority Channels
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {contactChannels.map((c, i) => (
                <button 
                  key={i} 
                  onClick={c.action}
                  className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-2xl hover:border-blue-100 transition-all text-center group relative overflow-hidden"
                >
                  <div className={`w-14 h-14 rounded-2xl bg-${c.color}-50 text-${c.color}-600 flex items-center justify-center text-xl mb-6 shadow-inner mx-auto group-hover:bg-${c.color}-600 group-hover:text-white transition-all duration-500`}>
                    <i className={`fas ${c.icon}`}></i>
                  </div>
                  <h4 className="text-lg font-black text-slate-900 mb-2">{c.label}</h4>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-4">{c.desc}</p>
                  <div className="pt-4 border-t border-slate-50 flex items-center justify-center gap-2 text-blue-600 font-black text-[9px] uppercase tracking-widest group-hover:translate-x-2 transition-transform">
                    Connect Now <i className="fas fa-arrow-right"></i>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* FAQs Section */}
          <div className="space-y-8">
            <div className="flex items-center justify-between">
              <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] flex items-center gap-4">
                <span className="w-10 h-px bg-slate-100"></span> {searchQuery ? `Verified Articles (${filteredFaqs.length})` : 'Popular Topics'}
              </h3>
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery('')}
                  className="text-[10px] font-black text-blue-600 uppercase tracking-widest hover:underline"
                >
                  Clear Filter
                </button>
              )}
            </div>

            <div className="space-y-4">
              {filteredFaqs.map((faq) => (
                <div 
                  key={faq.id} 
                  className={`bg-white rounded-3xl border border-slate-100 transition-all overflow-hidden ${expandedId === faq.id ? 'shadow-lg border-blue-100 ring-4 ring-blue-500/5' : 'hover:border-slate-200'}`}
                >
                  <button 
                    onClick={() => setExpandedId(expandedId === faq.id ? null : faq.id)}
                    className="w-full p-6 md:p-8 flex items-center justify-between text-left"
                  >
                    <span className="font-black text-slate-800 text-sm md:text-base leading-tight pr-8">{faq.q}</span>
                    <div className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all ${expandedId === faq.id ? 'bg-blue-600 text-white rotate-180' : 'bg-slate-50 text-slate-400'}`}>
                      <i className="fas fa-chevron-down text-[10px]"></i>
                    </div>
                  </button>
                  {expandedId === faq.id && (
                    <div className="px-8 pb-8 md:px-10 md:pb-10 animate-slideUp">
                      <p className="text-slate-500 font-medium leading-relaxed text-sm md:text-base border-t border-slate-50 pt-6">
                        {faq.a}
                      </p>
                      <div className="mt-6 flex items-center gap-4">
                         <span className="text-[10px] font-bold text-slate-300 uppercase tracking-widest">Was this helpful?</span>
                         <div className="flex gap-2">
                            <button className="w-8 h-8 rounded-lg bg-slate-50 text-slate-400 hover:text-emerald-500 hover:bg-emerald-50 transition-all"><i className="far fa-thumbs-up text-[10px]"></i></button>
                            <button className="w-8 h-8 rounded-lg bg-slate-50 text-slate-400 hover:text-red-500 hover:bg-red-50 transition-all"><i className="far fa-thumbs-down text-[10px]"></i></button>
                         </div>
                      </div>
                    </div>
                  )}
                </div>
              ))}

              {filteredFaqs.length === 0 && (
                <div className="text-center py-20 bg-slate-50/50 rounded-[2.5rem] border border-dashed border-slate-200 space-y-4">
                  <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center text-slate-300 mx-auto shadow-sm">
                    <i className="fas fa-search-minus text-xl"></i>
                  </div>
                  <div className="space-y-1">
                    <h4 className="text-lg font-black text-slate-900">No matches in library</h4>
                    <p className="text-xs font-medium text-slate-500">The Neural Concierge might have an answer above, or you can contact a strategist.</p>
                  </div>
                  <button 
                    onClick={() => setSearchQuery('')}
                    className="mt-4 px-6 py-2 bg-blue-600 text-white rounded-xl font-black text-[9px] uppercase tracking-widest shadow-lg shadow-blue-500/10"
                  >
                    Reset Filter
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Sidebar Cards */}
        <div className="lg:col-span-4 space-y-8">
           <div className="bg-slate-900 rounded-[2.5rem] p-10 text-white space-y-6 shadow-2xl relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:rotate-12 transition-transform duration-700">
                <i className="fas fa-rocket text-8xl"></i>
              </div>
              <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center text-xl shadow-lg relative z-10">
                 <i className="fas fa-book-open"></i>
              </div>
              <div className="space-y-2 relative z-10">
                <h4 className="text-xl font-black tracking-tight">Technical Wiki</h4>
                <p className="text-slate-400 font-medium text-sm leading-relaxed">Access full v5.0 API documentation, GDS terminal commands, and integration guides.</p>
              </div>
              <button 
                onClick={() => setIsWikiOpen(true)}
                className="w-full py-4 bg-white/10 hover:bg-white/20 border border-white/10 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] transition-all relative z-10"
              >
                Open Documentation
              </button>
           </div>

           <div className="bg-blue-50 border border-blue-100 rounded-[2.5rem] p-8 space-y-6">
              <div className="flex items-center gap-3">
                 <i className="fas fa-info-circle text-blue-600"></i>
                 <h4 className="text-[10px] font-black text-blue-900 uppercase tracking-widest">Office Hours</h4>
              </div>
              <div className="space-y-4">
                 <div className="flex justify-between items-center text-xs">
                    <span className="font-bold text-slate-500">Mon - Fri</span>
                    <span className="font-black text-blue-900">08:00 - 22:00 UTC</span>
                 </div>
                 <div className="flex justify-between items-center text-xs">
                    <span className="font-bold text-slate-500">Sat - Sun</span>
                    <span className="font-black text-blue-900">10:00 - 18:00 UTC</span>
                 </div>
              </div>
              <p className="text-[10px] font-medium text-blue-700/60 leading-relaxed italic border-t border-blue-200/50 pt-4">
                "Our global node monitors are active 24/7. Emergency hotlines remain open during all maintenance cycles."
              </p>
           </div>
        </div>
      </div>

      {/* Technical Wiki Modal */}
      {isWikiOpen && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4 sm:p-6 md:p-8">
           <div className="absolute inset-0 bg-slate-950/95 backdrop-blur-xl animate-fadeIn" onClick={() => setIsWikiOpen(false)}></div>
           <div className="bg-slate-900 w-full max-w-5xl h-[90vh] rounded-[3rem] shadow-2xl relative z-10 animate-slideUp border border-white/10 overflow-hidden flex flex-col md:flex-row">
              {/* Wiki Sidebar */}
              <div className="w-full md:w-80 bg-slate-950 border-b md:border-b-0 md:border-r border-white/5 p-8 flex flex-col gap-10">
                 <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-[0_0_20px_rgba(37,99,235,0.3)]">
                       <i className="fas fa-brain"></i>
                    </div>
                    <div>
                       <h3 className="text-lg font-black text-white tracking-tight uppercase leading-none">Neural Wiki</h3>
                       <p className="text-[8px] font-bold text-blue-400 uppercase tracking-widest mt-1">Version 5.0.2-Stable</p>
                    </div>
                 </div>

                 <nav className="space-y-2 flex-1">
                    <p className="text-[9px] font-black text-slate-600 uppercase tracking-[0.3em] mb-4">Architecture Nodes</p>
                    {wikiSectors.map(s => (
                       <button 
                        key={s.id}
                        onClick={() => setActiveWikiTab(s.id)}
                        className={`w-full flex items-center gap-4 px-6 py-4 rounded-2xl transition-all group ${activeWikiTab === s.id ? 'bg-blue-600 text-white shadow-xl' : 'text-slate-400 hover:bg-white/5'}`}
                       >
                          <i className={`fas ${s.icon} text-sm ${activeWikiTab === s.id ? 'text-white' : 'text-slate-600 group-hover:text-blue-400'}`}></i>
                          <span className="text-[11px] font-black uppercase tracking-widest">{s.id}</span>
                       </button>
                    ))}
                 </nav>

                 <button onClick={() => setIsWikiOpen(false)} className="w-full py-4 rounded-2xl border border-white/5 text-[10px] font-black text-slate-500 uppercase tracking-widest hover:bg-red-500 hover:text-white transition-all">
                    Safe Shutdown
                 </button>
              </div>

              {/* Wiki Content */}
              <div className="flex-1 p-8 md:p-16 overflow-y-auto scrollbar-hide space-y-12">
                 {wikiSectors.map(s => s.id === activeWikiTab && (
                    <div key={s.id} className="space-y-10 animate-fadeIn">
                       <div className="space-y-4">
                          <h2 className="text-4xl md:text-5xl font-black text-white tracking-tighter">{s.title}</h2>
                          <p className="text-xl text-slate-400 font-medium leading-relaxed max-w-2xl">{s.desc}</p>
                       </div>

                       <div className="space-y-4">
                          <div className="flex items-center justify-between text-[10px] font-black uppercase tracking-widest text-slate-500 bg-white/5 p-4 rounded-t-2xl border-x border-t border-white/5">
                             <span>Terminal Session: {s.id}</span>
                             <div className="flex gap-2">
                                <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                                <div className="w-2 h-2 rounded-full bg-amber-500"></div>
                                <div className="w-2 h-2 rounded-full bg-red-500"></div>
                             </div>
                          </div>
                          <div className="bg-slate-950 p-8 rounded-b-2xl border border-white/5 shadow-inner">
                             <pre className="text-blue-400 font-mono text-sm leading-loose whitespace-pre-wrap">
                                {s.content}
                             </pre>
                          </div>
                       </div>

                       <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div className="p-6 bg-white/5 rounded-[2rem] border border-white/5">
                             <h4 className="text-[10px] font-black text-white uppercase tracking-widest mb-2">Protocol Dependency</h4>
                             <p className="text-xs text-slate-500 font-medium leading-relaxed">Requires authenticated Bearer Token synced with Regional Cluster Hub. Maximum payload recursion limited to 8 levels.</p>
                          </div>
                          <div className="p-6 bg-white/5 rounded-[2rem] border border-white/5">
                             <h4 className="text-[10px] font-black text-white uppercase tracking-widest mb-2">Integration Status</h4>
                             <div className="flex items-center gap-3">
                                <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
                                <span className="text-xs font-bold text-emerald-500 uppercase tracking-widest">Active Verification</span>
                             </div>
                          </div>
                       </div>
                    </div>
                 ))}
              </div>
           </div>
        </div>
      )}

      {/* Live Chat Connection Overlay */}
      {isConnecting && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center p-6 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
           <div className="bg-white rounded-[3rem] p-12 max-w-md w-full text-center space-y-8 shadow-2xl animate-slideUp overflow-hidden relative">
              <div className="absolute top-0 left-0 w-full h-1 bg-slate-100">
                 <div 
                  className="h-full bg-blue-600 transition-all duration-[4.5s] ease-linear" 
                  style={{ width: `${(connectionStep / 3) * 100}%` }}
                 ></div>
              </div>

              <div className="relative">
                <div className="w-24 h-24 bg-blue-50 rounded-full flex items-center justify-center mx-auto relative">
                   <div className="absolute inset-0 border-4 border-blue-100 rounded-full border-t-blue-600 animate-spin"></div>
                   <i className="fas fa-user-tie text-3xl text-blue-600"></i>
                </div>
              </div>

              <div className="space-y-3">
                 <h3 className="text-2xl font-black text-slate-900 tracking-tight">Initializing Secure Link</h3>
                 <p className="text-slate-500 font-medium text-sm">
                   {connectionStep === 1 && "Verifying session tokens..."}
                   {connectionStep === 2 && "Syncing with Regional GDS node..."}
                   {connectionStep === 3 && "Connecting to Platinum Concierge..."}
                 </p>
              </div>

              <div className="flex justify-center gap-1.5">
                 {[1, 2, 3].map(i => (
                   <div key={i} className={`w-2 h-2 rounded-full transition-all duration-300 ${connectionStep >= i ? 'bg-blue-600 scale-125' : 'bg-slate-200'}`}></div>
                 ))}
              </div>

              <p className="text-[10px] font-black text-slate-300 uppercase tracking-[0.2em]">Protocol v5.0 Secure Connection</p>
           </div>
        </div>
      )}
    </div>
  );
};

export default SupportPage;
