import React, { useState, useEffect, useRef } from 'react';
import { UserRole, Lead, Booking } from '../types';
import { MOCK_FLIGHTS } from '../constants';

interface DashboardProps {
  role: UserRole;
  setActiveTab: (tab: string) => void;
  onSelectLead: (leadId: string) => void;
  leads: Lead[];
  onAddLead: (lead: Lead) => void;
  bookings: Booking[];
  onAddBooking: (booking: Booking) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ 
  role, 
  setActiveTab, 
  onSelectLead, 
  leads, 
  onAddLead, 
  bookings, 
  onAddBooking 
}) => {
  const [showRangePicker, setShowRangePicker] = useState(false);
  const [selectedRange, setSelectedRange] = useState('Last 7 Days');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [selectedKpi, setSelectedKpi] = useState<any>(null);
  const pickerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (pickerRef.current && !pickerRef.current.contains(event.target as Node)) {
        setShowRangePicker(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleRangeChange = (range: string) => {
    setSelectedRange(range);
    setShowRangePicker(false);
    setIsRefreshing(true);
    setTimeout(() => setIsRefreshing(false), 800);
  };

  const handleKpiClick = (kpi: any) => {
    setSelectedKpi(kpi);
  };

  const renderSparkline = (color: string) => {
    const bars = [40, 70, 45, 90, 65, 85, 55];
    const colors: any = {
      blue: 'fill-blue-500',
      emerald: 'fill-emerald-500',
      orange: 'fill-orange-500',
      indigo: 'fill-indigo-500',
      amber: 'fill-amber-500'
    };

    return (
      <svg className="w-16 h-8 overflow-visible" viewBox="0 0 70 30">
        {bars.map((h, i) => (
          <rect
            key={i}
            x={i * 10}
            y={30 - (h / 3.3)}
            width="6"
            height={h / 3.3}
            rx="3"
            className={`${colors[color] || 'fill-slate-200'} opacity-20 group-hover:opacity-100 transition-all duration-500`}
            style={{ transitionDelay: `${i * 50}ms` }}
          />
        ))}
      </svg>
    );
  };

  const renderKPIs = () => {
    const kpis = {
      [UserRole.ADMIN]: [
        { id: 'sales', label: 'Total Sales', value: `$${bookings.reduce((a,b)=>a+b.totalFare,0).toLocaleString()}`, icon: 'fa-dollar-sign', color: 'blue' },
        { id: 'leads', label: 'Active Leads', value: leads.length, icon: 'fa-users', color: 'emerald' },
        { id: 'pnrs', label: 'Pending PNRs', value: '14', icon: 'fa-ticket-alt', color: 'orange' },
        { id: 'load', label: 'System Load', value: '42%', icon: 'fa-microchip', color: 'indigo' },
      ],
      [UserRole.AGENT]: [
        { id: 'pipeline', label: 'My Pipeline', value: leads.length, icon: 'fa-filter', color: 'blue' },
        { id: 'today_sales', label: 'Today\'s Sales', value: '$4,280', icon: 'fa-award', color: 'emerald' },
        { id: 'calls', label: 'Calls Logged', value: '12', icon: 'fa-phone', color: 'indigo' },
        { id: 'commission', label: 'Commission', value: '$840', icon: 'fa-wallet', color: 'amber' },
      ],
      [UserRole.USER]: [
        { id: 'trips', label: 'Total Trips', value: bookings.length, icon: 'fa-plane', color: 'blue' },
        { id: 'miles', label: 'Reward Miles', value: '12,450', icon: 'fa-star', color: 'amber' },
        { id: 'next', label: 'Next Trip', value: 'In 4 days', icon: 'fa-calendar-check', color: 'emerald' },
        { id: 'offer', label: 'Expiring Soon', value: '$25 Offer', icon: 'fa-tag', color: 'indigo' },
      ],
    };

    return kpis[role].map((kpi, i) => (
      <div 
        key={i} 
        onClick={() => handleKpiClick(kpi)}
        className={`bg-white p-6 md:p-8 rounded-[2.8rem] border border-slate-100 shadow-sm hover:shadow-xl hover:-translate-y-1 cursor-pointer transition-all group relative overflow-hidden ${isRefreshing ? 'animate-pulse opacity-50' : ''}`}
      >
        <div className="flex justify-between items-start mb-4 md:mb-6">
          <div className={`w-10 h-10 md:w-12 md:h-12 rounded-2xl bg-${kpi.color}-50 flex items-center justify-center text-${kpi.color}-600 text-base md:text-lg shadow-inner group-hover:scale-110 group-hover:rotate-3 transition-all duration-500`}>
            <i className={`fas ${kpi.icon}`}></i>
          </div>
          <div className="flex flex-col items-end gap-1">
             <span className="text-[9px] font-black text-slate-300 uppercase tracking-widest hidden sm:inline">Live Node</span>
             {renderSparkline(kpi.color)}
          </div>
        </div>
        <p className="text-[9px] md:text-[11px] font-black text-slate-400 uppercase tracking-widest mb-1">{kpi.label}</p>
        <div className="flex items-baseline gap-2">
           <p className="text-xl md:text-2xl lg:text-3xl font-black text-slate-900 tracking-tighter">{kpi.value}</p>
           <i className="fas fa-caret-up text-emerald-500 text-[10px] opacity-0 group-hover:opacity-100 transition-opacity"></i>
        </div>
      </div>
    ));
  };

  const rangeOptions = [
    { label: 'Last 24 Hours', icon: 'fa-clock' },
    { label: 'Last 7 Days', icon: 'fa-calendar-week' },
    { label: 'Last 30 Days', icon: 'fa-calendar-alt' },
    { label: 'Year to Date', icon: 'fa-layer-group' },
  ];

  return (
    <div className="px-4 md:px-8 lg:px-10 py-6 md:py-8 lg:py-10 space-y-6 md:space-y-8 animate-fadeIn max-w-[1600px] mx-auto overflow-x-hidden">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-end gap-6">
        <div className="max-w-2xl w-full">
          <h1 className="text-2xl md:text-3xl lg:text-4xl font-black text-slate-900 tracking-tight leading-none">
            {role === UserRole.ADMIN ? 'Global Hub' : role === UserRole.AGENT ? 'Sales Strategy' : 'My Travel Portal'}
          </h1>
          <p className="text-slate-500 font-medium mt-2 md:mt-3 text-sm md:text-lg">
            Analytics overview for <span className="text-blue-600 font-bold">{new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric' })}</span>.
          </p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-3 w-full lg:w-auto relative" ref={pickerRef}>
          <div className="relative flex-1 sm:flex-none">
            <button 
              onClick={() => setShowRangePicker(!showRangePicker)}
              className={`w-full sm:w-auto px-4 md:px-6 py-3 rounded-xl md:rounded-2xl text-[10px] md:text-xs font-black uppercase tracking-widest transition-all flex items-center justify-center gap-3 border ${
                showRangePicker ? 'bg-slate-900 text-white border-slate-900' : 'bg-white text-slate-700 border-slate-200'
              }`}
            >
              <i className={`${showRangePicker ? 'fas fa-times' : 'far fa-calendar-alt'} text-blue-500`}></i> 
              <span className="truncate">{selectedRange}</span>
            </button>

            {showRangePicker && (
              <div className="absolute left-0 lg:right-0 lg:left-auto top-full mt-3 w-full sm:w-64 bg-white rounded-2xl shadow-2xl border border-slate-100 p-2 z-50 animate-slideUp">
                {rangeOptions.map((opt) => (
                  <button
                    key={opt.label}
                    onClick={() => handleRangeChange(opt.label)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all text-left ${
                      selectedRange === opt.label ? 'bg-blue-50 text-blue-600' : 'text-slate-500 hover:bg-slate-50'
                    }`}
                  >
                    <i className={`fas ${opt.icon} text-sm`}></i>
                    <span className="font-bold text-[10px] md:text-xs uppercase tracking-widest">{opt.label}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          <button 
            onClick={() => setActiveTab('flights')}
            className="flex-1 sm:flex-none bg-blue-600 text-white px-4 md:px-8 py-3 rounded-xl md:rounded-2xl text-[10px] md:text-xs font-black uppercase tracking-widest hover:bg-blue-700 shadow-lg shadow-blue-500/20 flex items-center justify-center gap-2"
          >
            <i className="fas fa-search"></i> New Search
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 lg:gap-8">
        {renderKPIs()}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-10">
        <div className="lg:col-span-12 h-full">
          <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden flex flex-col h-full max-h-[calc(100vh-140px)]">
            <div className="p-6 md:p-8 border-b border-slate-100 flex justify-between items-center bg-white sticky top-0 z-10">
              <h3 className="font-black text-slate-900 text-xs uppercase tracking-widest">Active Pipeline</h3>
              <button onClick={() => setActiveTab(role === UserRole.USER ? 'manage-bookings' : 'leads')} className="text-blue-600 text-[10px] font-black uppercase tracking-widest hover:underline">See All</button>
            </div>
            
            <div className="flex-1 p-6 md:p-8 space-y-6 overflow-y-auto scrollbar-hide">
              {(role === UserRole.USER ? bookings : leads.slice(0, 12)).map((item: any, i) => {
                const flight = role === UserRole.USER ? MOCK_FLIGHTS.find(f => f.id === item.flightId) : null;

                return (
                  <div key={i} className="flex items-center justify-between group cursor-pointer" onClick={() => role === UserRole.USER ? setActiveTab('manage-bookings') : onSelectLead(item.id)}>
                    <div className="flex items-center gap-3 md:gap-4">
                      <div className="max-w-[300px] md:max-w-none">
                        <p className="text-xs md:text-sm font-black text-slate-900 truncate">
                          {role === UserRole.USER ? `Trip to ${flight?.arrival}` : item.customerName}
                        </p>
                        <p className="text-[9px] md:text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-0.5 truncate">
                           {role === UserRole.USER ? `PNR: ${item.pnr}` : item.route}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                       <div className="text-right hidden sm:block mr-2">
                          <p className="text-[10px] font-black text-slate-900 leading-none">
                            {role === UserRole.USER ? `$${item.totalFare}` : `₹${item.budget.toLocaleString()}`}
                          </p>
                          <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">Value</p>
                       </div>
                       <span className={`hidden sm:inline text-[8px] font-black uppercase tracking-widest px-2.5 py-1 rounded-lg border ${role === UserRole.USER ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-blue-50 text-blue-600 border-blue-100'}`}>
                          {role === UserRole.USER ? 'Confirmed' : 'Live Node'}
                       </span>
                       <i className="fas fa-chevron-right text-[9px] text-slate-200 group-hover:text-blue-500 transition-colors ml-2"></i>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="p-6 md:p-8 bg-slate-50 border-t border-slate-100">
               <button onClick={() => setActiveTab('flights')} className="w-full bg-slate-900 text-white font-black py-4 rounded-xl md:rounded-2xl text-[10px] uppercase tracking-widest hover:bg-black transition-all shadow-lg">Initialize New Search</button>
            </div>
          </div>
        </div>
      </div>

      {selectedKpi && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
           <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-md animate-fadeIn" onClick={() => setSelectedKpi(null)}></div>
           <div className="bg-white w-full max-w-md rounded-[3rem] shadow-2xl relative z-10 animate-slideUp border border-slate-100 overflow-hidden">
              <div className={`bg-${selectedKpi.color}-600 p-8 flex justify-between items-center text-white`}>
                 <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-xl border border-white/10 shadow-lg">
                       <i className={`fas ${selectedKpi.icon} text-lg`}></i>
                    </div>
                    <div>
                       <h3 className="text-lg font-black tracking-tight uppercase leading-none">{selectedKpi.label}</h3>
                       <p className="text-[9px] font-bold text-white/60 uppercase tracking-widest mt-1">Neural Node: Active</p>
                    </div>
                 </div>
                 <button onClick={() => setSelectedKpi(null)} className="w-10 h-10 hover:bg-white/10 rounded-xl flex items-center justify-center transition-all">
                    <i className="fas fa-times"></i>
                 </button>
              </div>

              <div className="p-10 space-y-10">
                 <div className="space-y-2 text-center">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Current Register Value</p>
                    <p className={`text-5xl font-black text-slate-900 tracking-tighter`}>{selectedKpi.value}</p>
                 </div>

                 <div className="space-y-4">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Calibration Logic</p>
                    <div className="grid grid-cols-2 gap-4">
                       <button className="flex flex-col items-center gap-3 p-6 bg-slate-50 border border-slate-100 rounded-[2rem] hover:bg-white hover:border-blue-200 transition-all group">
                          <i className="fas fa-sync-alt text-blue-600 text-lg group-hover:rotate-180 transition-transform duration-700"></i>
                          <span className="text-[10px] font-black uppercase tracking-widest">Sync Node</span>
                       </button>
                       <button className="flex flex-col items-center gap-3 p-6 bg-slate-50 border border-slate-100 rounded-[2rem] hover:bg-white hover:border-emerald-200 transition-all group">
                          <i className="fas fa-edit text-emerald-600 text-lg group-hover:scale-110 transition-transform"></i>
                          <span className="text-[10px] font-black uppercase tracking-widest">Adjust Data</span>
                       </button>
                    </div>
                 </div>

                 <button 
                  onClick={() => setSelectedKpi(null)}
                  className="w-full bg-slate-900 text-white font-black py-5 rounded-2xl shadow-xl hover:bg-black transition-all uppercase tracking-widest text-[10px]"
                 >
                    Close Terminal
                 </button>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;