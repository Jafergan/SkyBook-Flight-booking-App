import React from 'react';
import { Lead } from '../types';

interface LeadDetailsPageProps {
  leadId: string;
  leads: Lead[];
  onBack: () => void;
  onSearchFlights: () => void;
}

const LeadDetailsPage: React.FC<LeadDetailsPageProps> = ({ leadId, leads, onBack, onSearchFlights }) => {
  const lead = leads.find(l => l.id === leadId) || leads[0];

  if (!lead) return null;

  return (
    <div className="p-8 space-y-8 animate-fadeIn max-w-7xl mx-auto">
      {/* Breadcrumbs & Actions */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <nav className="flex items-center gap-3 text-sm font-bold">
          <button onClick={onBack} className="text-slate-400 hover:text-blue-600 transition-colors">Leads</button>
          <i className="fas fa-chevron-right text-[10px] text-slate-300"></i>
          <span className="text-slate-900">{lead.customerName}</span>
        </nav>
        <div className="flex items-center gap-3 w-full md:w-auto">
          <button className="flex-1 md:flex-none px-6 py-2.5 rounded-xl bg-white border border-slate-200 text-sm font-bold text-slate-700 hover:bg-slate-50 transition-all">
            Edit Lead
          </button>
          <button 
            onClick={onSearchFlights}
            className="flex-1 md:flex-none px-6 py-2.5 rounded-xl bg-blue-600 text-white text-sm font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-500/20 flex items-center justify-center gap-3"
          >
            <i className="fas fa-plane-departure"></i>
            Search Flights
          </button>
        </div>
      </div>

      <div className="flex items-end gap-4">
        <h1 className="text-3xl font-black text-slate-900">Lead Details: {lead.customerName}</h1>
        <span className="bg-emerald-50 text-emerald-600 px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider mb-1.5 border border-emerald-100">
          {lead.status}
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column - Details */}
        <div className="lg:col-span-2 space-y-8">
          {/* Profile Card */}
          <div className="bg-white rounded-3xl border border-slate-100 shadow-sm p-8 flex flex-col md:flex-row items-center gap-8">
            <div className="relative">
              <div className="w-24 h-24 rounded-[2rem] bg-blue-50 flex items-center justify-center text-3xl font-black text-blue-600 shadow-inner">
                {lead.customerName.split(' ').map(n => n[0]).join('')}
              </div>
              <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-emerald-500 border-4 border-white rounded-full"></div>
            </div>
            
            <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-y-6 gap-x-12">
              <div className="space-y-1">
                <p className="text-xl font-black text-slate-900">{lead.customerName}</p>
                <div className="flex items-center gap-2 text-slate-500 font-bold text-sm">
                  <i className="fas fa-phone-alt text-[10px]"></i>
                  {lead.phone}
                </div>
              </div>
              <div className="flex items-center gap-4 md:justify-end">
                <button className="w-10 h-10 rounded-xl bg-slate-50 border border-slate-100 text-slate-400 hover:bg-blue-600 hover:text-white transition-all">
                  <i className="fas fa-phone-alt"></i>
                </button>
                <button className="w-10 h-10 rounded-xl bg-slate-50 border border-slate-100 text-slate-400 hover:bg-blue-600 hover:text-white transition-all">
                  <i className="fas fa-comment-dots"></i>
                </button>
                <button className="w-10 h-10 rounded-xl bg-slate-50 border border-slate-100 text-slate-400 hover:bg-blue-600 hover:text-white transition-all">
                  <i className="far fa-envelope"></i>
                </button>
              </div>
              <div className="flex items-center gap-2 text-slate-500 font-bold text-sm">
                <i className="far fa-envelope text-[10px]"></i>
                {lead.email}
              </div>
              <div className="flex items-center gap-2 text-slate-500 font-bold text-sm md:justify-end">
                <i className="fas fa-map-marker-alt text-[10px]"></i>
                Mumbai, India
              </div>
            </div>
          </div>

          {/* Trip Requirement Card */}
          <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center text-blue-600">
                  <i className="fas fa-suitcase"></i>
                </div>
                <h3 className="font-black text-slate-800 uppercase tracking-wider text-xs">Trip Requirement</h3>
              </div>
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Ref: #LD-2025-884</span>
            </div>
            
            <div className="p-0 grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-slate-100">
              <div className="p-8 flex items-start gap-4">
                <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center text-blue-500 shrink-0">
                  <i className="fas fa-plane-departure"></i>
                </div>
                <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-1">Origin</p>
                  <p className="text-lg font-black text-slate-900">{lead.origin}</p>
                </div>
              </div>
              <div className="p-8 flex items-start gap-4">
                <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center text-blue-500 shrink-0">
                  <i className="fas fa-plane-arrival"></i>
                </div>
                <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-1">Destination</p>
                  <p className="text-lg font-black text-slate-900">{lead.destination}</p>
                </div>
              </div>
              <div className="p-8 flex items-start gap-4">
                <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center text-slate-400 shrink-0">
                  <i className="far fa-calendar-alt"></i>
                </div>
                <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-1">Travel Date</p>
                  <p className="text-md font-bold text-slate-700">20 Sep 2025</p>
                </div>
              </div>
              <div className="p-8 flex items-start gap-4">
                <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center text-slate-400 shrink-0">
                  <i className="fas fa-users"></i>
                </div>
                <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-1">Passengers</p>
                  <p className="text-md font-bold text-slate-700">{lead.passengers.adults} Adults, {lead.passengers.children} Child</p>
                </div>
              </div>
            </div>

            <div className="p-8 bg-slate-50/50 border-t border-slate-100 flex items-center justify-between">
              <div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-1">Estimated Budget</p>
                <p className="text-2xl font-black text-slate-900">₹{lead.budget.toLocaleString()}</p>
              </div>
              <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center text-emerald-600 font-bold">
                $
              </div>
            </div>
          </div>

          {/* Client Preferences */}
          <div className="bg-amber-50/50 border border-amber-200/50 rounded-3xl p-8 flex gap-6">
            <div className="w-10 h-10 bg-amber-100 rounded-xl flex items-center justify-center text-amber-600 shrink-0">
              <i className="fas fa-sticky-note"></i>
            </div>
            <div>
              <h4 className="font-black text-amber-900 mb-2">Client Preferences</h4>
              <p className="text-amber-800/80 font-medium leading-relaxed">
                {lead.notes[0] || 'No specific preferences recorded.'}
              </p>
            </div>
          </div>
        </div>

        {/* Right Column - Timeline */}
        <div className="space-y-8">
          <div className="bg-white rounded-3xl border border-slate-100 shadow-sm flex flex-col h-full">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h3 className="font-black text-slate-800 text-sm uppercase tracking-wider">Activity Timeline</h3>
              <button className="text-blue-600 text-xs font-bold hover:underline">View All</button>
            </div>
            
            <div className="flex-1 p-8 overflow-y-auto space-y-8 max-h-[500px]">
              {lead.activities.map((activity, i) => (
                <div key={activity.id} className="relative flex gap-4">
                  {i < lead.activities.length - 1 && (
                    <div className="absolute left-[11px] top-6 w-0.5 h-full bg-slate-100"></div>
                  )}
                  <div className={`w-6 h-6 rounded-full border-4 border-white shadow-sm shrink-0 z-10 ${
                    activity.type === 'note' ? 'bg-amber-400' :
                    activity.type === 'call' ? 'bg-emerald-500' :
                    activity.type === 'status_change' ? 'bg-blue-500' : 'bg-slate-300'
                  }`}></div>
                  <div className="flex-1 -mt-1">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">
                      {new Date(activity.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                    <p className="text-sm font-black text-slate-800 mb-2">{activity.content}</p>
                    {activity.type === 'note' && (
                      <div className="bg-slate-50 border border-slate-100 rounded-xl p-4 text-xs font-medium text-slate-500 leading-relaxed">
                        {activity.content}
                      </div>
                    )}
                    {activity.type === 'status_change' && activity.metadata && (
                      <div className="flex items-center gap-3 bg-slate-50 p-3 rounded-xl border border-slate-100 w-fit">
                        <span className="text-[10px] font-bold text-slate-400 uppercase">{activity.metadata.from}</span>
                        <i className="fas fa-arrow-right text-[8px] text-slate-300"></i>
                        <span className="text-[10px] font-bold text-blue-600 uppercase">{activity.metadata.to}</span>
                      </div>
                    )}
                    {activity.type === 'call' && activity.metadata && (
                      <div className="flex items-center gap-2 text-emerald-600 text-xs font-bold">
                        <i className="fas fa-check-circle"></i>
                        Duration: {activity.metadata.duration}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>

            <div className="p-6 border-t border-slate-100 bg-slate-50/30">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Add internal note</p>
              <div className="flex gap-2">
                <input 
                  type="text" 
                  placeholder="Type a note..." 
                  className="flex-1 bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all"
                />
                <button className="w-12 h-12 bg-blue-600 text-white rounded-xl shadow-lg shadow-blue-500/20 hover:bg-blue-700 transition-all flex items-center justify-center shrink-0">
                  <i className="fas fa-paper-plane"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LeadDetailsPage;