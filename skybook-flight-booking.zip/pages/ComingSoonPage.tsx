import React from 'react';

interface ComingSoonPageProps {
  onBack: () => void;
}

const ComingSoonPage: React.FC<ComingSoonPageProps> = ({ onBack }) => {
  return (
    <div className="min-h-[calc(100vh-64px)] p-8 flex items-center justify-center bg-white animate-fadeIn">
      <div className="max-w-5xl w-full">
        {/* Main Banner */}
        <div className="relative w-full h-[600px] rounded-[3.5rem] overflow-hidden shadow-2xl group">
           <img 
            src="https://images.unsplash.com/photo-1436491865332-7a61a109c0f2?auto=format&fit=crop&q=80&w=2000" 
            className="absolute inset-0 w-full h-full object-cover group-hover:scale-110 transition-transform duration-[2s]" 
            alt="Airplane window view"
           />
           <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-[2px]"></div>
           <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent"></div>
           
           <div className="relative z-10 h-full flex flex-col items-center justify-center text-center p-12 space-y-8">
              <div className="bg-blue-600/20 backdrop-blur-md px-6 py-2 rounded-full border border-white/20 flex items-center gap-3">
                 <span className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></span>
                 <span className="text-[10px] font-black text-white uppercase tracking-[0.3em]">Coming Soon</span>
              </div>

              <div className="space-y-4">
                <h1 className="text-6xl md:text-8xl font-black text-white tracking-tighter leading-none">New Heights Await</h1>
                <p className="text-slate-300 font-medium text-lg max-w-2xl mx-auto leading-relaxed">
                  We are putting the finishing touches on our new <span className="text-white font-black">Advanced Analytics Dashboard</span>. Track your flight bookings and lead conversion rates with precision.
                </p>
              </div>

              {/* Countdown */}
              <div className="flex gap-4 md:gap-8 pt-4">
                 {[
                   { val: '14', label: 'Days' },
                   { val: '08', label: 'Hours' },
                   { val: '45', label: 'Minutes' },
                   { val: '12', label: 'Seconds' },
                 ].map((t, i) => (
                   <div key={i} className="flex flex-col items-center">
                      <div className="w-16 h-16 md:w-20 md:h-20 bg-white/10 backdrop-blur-xl rounded-[1.5rem] border border-white/10 flex items-center justify-center text-2xl md:text-3xl font-black text-white mb-2 shadow-2xl">
                         {t.val}
                      </div>
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{t.label}</span>
                   </div>
                 ))}
              </div>

              {/* Notify Form */}
              <div className="w-full max-w-md bg-white p-2 rounded-3xl shadow-2xl flex items-center gap-2 border border-slate-100 mt-8">
                 <div className="flex-1 flex items-center gap-3 px-4">
                    <i className="far fa-envelope text-slate-300"></i>
                    <input type="email" placeholder="Enter your email address" className="bg-transparent border-none outline-none font-bold text-slate-800 text-sm w-full" />
                 </div>
                 <button className="bg-blue-600 text-white px-8 py-3.5 rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg shadow-blue-500/20 hover:bg-blue-700 transition-all shrink-0">
                    Notify Me
                 </button>
              </div>
              <p className="text-[10px] font-bold text-slate-400">We respect your privacy. No spam, ever.</p>
           </div>
        </div>

        <div className="flex justify-center mt-12">
           <button 
            onClick={onBack}
            className="flex items-center gap-3 text-xs font-black text-slate-400 uppercase tracking-[0.2em] hover:text-blue-600 transition-all"
           >
              <i className="fas fa-arrow-left"></i> Return to Dashboard
           </button>
        </div>

        <div className="pt-16 flex justify-center gap-12 text-[10px] font-black text-slate-300 uppercase tracking-widest border-t border-slate-50 mt-16">
           <button className="hover:text-slate-600">Help Center</button>
           <button className="hover:text-slate-600">Privacy Policy</button>
           <button className="hover:text-slate-600">Terms of Service</button>
        </div>
        <p className="text-center text-[10px] font-bold text-slate-200 mt-6">© 2024 SkyBook. All rights reserved.</p>
      </div>
    </div>
  );
};

export default ComingSoonPage;