import React from 'react';

interface NotFoundPageProps {
  onReturn: () => void;
}

const NotFoundPage: React.FC<NotFoundPageProps> = ({ onReturn }) => {
  return (
    <div className="min-h-[calc(100vh-64px)] flex flex-col items-center justify-center p-8 bg-white animate-fadeIn">
      <div className="max-w-2xl w-full text-center space-y-8">
        {/* Error Illustration */}
        <div className="relative mx-auto w-full max-w-md aspect-square bg-slate-50 rounded-[3rem] overflow-hidden border border-slate-100 shadow-inner group">
          <img 
            src="https://images.unsplash.com/photo-1517400508447-f8dd518b86db?auto=format&fit=crop&q=80&w=1000" 
            alt="Plane in clouds" 
            className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-700"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-blue-500/10 to-white/80"></div>
          <div className="absolute inset-0 flex items-center justify-center">
             <div className="bg-white/90 backdrop-blur-md p-8 rounded-[2rem] shadow-2xl border border-white">
                <i className="fas fa-map-marked-alt text-5xl text-blue-600 animate-bounce"></i>
             </div>
          </div>
        </div>

        <div className="space-y-4">
          <h1 className="text-5xl font-black text-slate-900 tracking-tight leading-none">404 - Destination Unknown</h1>
          <p className="text-slate-500 font-medium text-lg max-w-lg mx-auto leading-relaxed">
            We couldn't find the page you were looking for. It might have been moved, deleted, or you may have mistyped the address. Let's get you back on course.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button 
            onClick={onReturn}
            className="w-full sm:w-auto px-10 py-4 bg-blue-600 text-white font-black rounded-2xl shadow-xl shadow-blue-500/20 hover:bg-blue-700 transition-all uppercase tracking-widest text-xs"
          >
            Return to Dashboard
          </button>
          <button 
            onClick={() => window.history.back()}
            className="w-full sm:w-auto px-10 py-4 bg-slate-50 text-slate-900 border border-slate-200 font-black rounded-2xl hover:bg-white transition-all uppercase tracking-widest text-xs"
          >
            Go Back
          </button>
        </div>

        <div className="pt-8">
          <p className="text-[10px] font-black text-slate-300 uppercase tracking-[0.3em]">
            Still stuck? <button className="text-blue-600 hover:underline">Contact Support</button> or <button className="text-blue-600 hover:underline">Report a Bug</button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default NotFoundPage;