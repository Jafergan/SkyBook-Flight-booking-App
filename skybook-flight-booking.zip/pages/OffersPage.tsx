
import React, { useState } from 'react';

interface OffersPageProps {
  onBack: () => void;
}

interface Offer {
  code: string;
  amount: string;
  desc: string;
  status: 'Active' | 'Expiring Soon' | 'Expired';
  expires: string;
  icon: string;
}

const OffersPage: React.FC<OffersPageProps> = ({ onBack }) => {
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isPoolModalOpen, setIsPoolModalOpen] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  const [localOffers, setLocalOffers] = useState<Offer[]>([
    { 
      code: 'FLIGHT25', 
      amount: '₹2,500 OFF', 
      desc: 'Flat discount on domestic flight bookings over ₹10,000. Valid for first-time premium users.', 
      status: 'Active', 
      expires: 'Dec 31, 2026', 
      icon: 'fa-plane' 
    },
    { 
      code: 'FESTIVE26', 
      amount: '15% OFF', 
      desc: 'Grand New Year special. Max discount ₹2,000 on all international routes.', 
      status: 'Active', 
      expires: 'Jan 15, 2026', 
      icon: 'fa-sparkles' 
    },
    { 
      code: 'INTL5000', 
      amount: '₹5,000 OFF', 
      desc: 'Exclusive for international round-trips over ₹50,000. Limited to GDS-verified bookings.', 
      status: 'Active', 
      expires: 'Nov 30, 2026', 
      icon: 'fa-globe' 
    },
    { 
      code: 'EARLYBIRD', 
      amount: '10% OFF', 
      desc: 'Unlock special seasonal rates by booking at least 60 days in advance.', 
      status: 'Expiring Soon', 
      expires: 'Dec 15, 2025', 
      icon: 'fa-clock' 
    },
  ]);

  const copyToClipboard = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const getStatusColor = (status: string) => {
    if (status === 'Active') return 'bg-emerald-50 text-emerald-600 border-emerald-100';
    if (status === 'Expiring Soon') return 'bg-amber-50 text-amber-600 border-amber-100';
    return 'bg-slate-100 text-slate-400 border-slate-200';
  };

  const handleCreatePromo = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsProcessing(true);
    const formData = new FormData(e.currentTarget);
    
    const newOffer: Offer = {
      code: (formData.get('code') as string).toUpperCase(),
      amount: formData.get('amount') as string,
      desc: formData.get('desc') as string,
      status: 'Active',
      expires: formData.get('expires') as string,
      icon: formData.get('icon') as string || 'fa-tag'
    };

    setTimeout(() => {
      setLocalOffers(prev => [newOffer, ...prev]);
      setIsProcessing(false);
      setIsCreateModalOpen(false);
    }, 1200);
  };

  const handlePoolSave = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setIsPoolModalOpen(false);
    }, 1500);
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8 animate-fadeIn">
      <nav className="flex items-center gap-3 text-xs font-black uppercase tracking-widest text-slate-400">
        <button onClick={onBack} className="hover:text-blue-600 transition-colors">Dashboard</button>
        <i className="fas fa-chevron-right text-[8px]"></i>
        <span className="text-blue-600">Offers & Coupons</span>
      </nav>

      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <button 
            onClick={onBack}
            className="mb-4 flex items-center gap-2 text-slate-400 hover:text-blue-600 transition-all group font-black text-[10px] uppercase tracking-widest w-fit"
          >
            <i className="fas fa-arrow-left group-hover:-translate-x-1 transition-transform"></i>
            Return to Dashboard
          </button>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight leading-none">Voucher Marketplace</h1>
          <p className="text-slate-500 font-medium mt-3">Active promotional codes and exclusive 2026 incentives for your travelers.</p>
        </div>
        <button 
          onClick={() => setIsCreateModalOpen(true)}
          className="bg-blue-600 text-white px-8 py-3.5 rounded-2xl font-black uppercase tracking-widest text-xs shadow-xl shadow-blue-500/20 hover:bg-blue-700 transition-all flex items-center gap-3"
        >
          <i className="fas fa-plus"></i> Create New Promo
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {localOffers.map((offer, i) => (
          <div key={i} className={`bg-white rounded-[2.5rem] border border-slate-100 p-8 shadow-sm relative group hover:shadow-xl transition-all ${offer.status === 'Expired' ? 'opacity-60 grayscale-[0.5]' : ''}`}>
             <div className="flex justify-between items-start mb-10">
                <div className="flex flex-col gap-2">
                   <button 
                    onClick={() => copyToClipboard(offer.code)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest border transition-all ${
                      copiedCode === offer.code 
                        ? 'bg-emerald-600 border-emerald-600 text-white' 
                        : 'bg-blue-50 text-blue-600 border-blue-100 hover:bg-blue-600 hover:text-white'
                    }`}
                   >
                      {offer.code} 
                      <i className={`fas ${copiedCode === offer.code ? 'fa-check' : 'fa-copy'} ml-1`}></i>
                      {copiedCode === offer.code && <span className="ml-1">Copied!</span>}
                   </button>
                   <span className={`px-2 py-0.5 rounded-full text-[8px] font-black uppercase tracking-widest border w-fit ${getStatusColor(offer.status)}`}>
                      {offer.status}
                   </span>
                </div>
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-lg ${offer.status === 'Active' ? 'bg-blue-50 text-blue-600' : offer.status === 'Expiring Soon' ? 'bg-amber-50 text-amber-600' : 'bg-slate-50 text-slate-400'}`}>
                   <i className={`fas ${offer.icon}`}></i>
                </div>
             </div>

             <div className="space-y-3 mb-10">
                <h4 className="text-3xl font-black text-slate-900 tracking-tight">{offer.amount}</h4>
                <p className="text-xs font-medium text-slate-500 leading-relaxed pr-8">{offer.desc}</p>
             </div>

             <div className="flex justify-between items-center pt-6 border-t border-slate-50">
                <div>
                   <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">{offer.status === 'Expired' ? 'Expired on' : 'Expires'}</p>
                   <p className="text-xs font-black text-slate-800 uppercase tracking-widest">{offer.expires}</p>
                </div>
                <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                   <button className="p-2 text-slate-300 hover:text-blue-600 transition-colors">
                      <i className="fas fa-edit text-sm"></i>
                   </button>
                   <button 
                    onClick={() => setLocalOffers(prev => prev.filter((_, idx) => idx !== i))}
                    className="p-2 text-slate-300 hover:text-red-500 transition-colors"
                   >
                      <i className="fas fa-trash-alt text-sm"></i>
                   </button>
                </div>
             </div>
          </div>
        ))}
      </div>

      <div className="bg-blue-50 rounded-[2.5rem] p-10 flex flex-col md:flex-row items-center justify-between gap-8 border border-blue-100">
         <div className="space-y-2 text-center md:text-left">
            <h3 className="text-2xl font-black text-blue-900">Custom Corporate Rates</h3>
            <p className="text-sm font-medium text-blue-700 max-w-xl">Setting up a corporate account? Generate dedicated voucher pools for employees with custom spend limits and policy enforcement.</p>
         </div>
         <button 
          onClick={() => setIsPoolModalOpen(true)}
          className="bg-white text-blue-600 px-8 py-4 rounded-2xl font-black uppercase tracking-widest text-xs shadow-md hover:shadow-lg transition-all border border-blue-200"
         >
            Configure Pools
         </button>
      </div>

      {/* Create Promo Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm animate-fadeIn" onClick={() => setIsCreateModalOpen(false)}></div>
          <div className="bg-white w-full max-w-xl rounded-[2.5rem] shadow-2xl relative z-10 animate-slideUp border border-slate-100 overflow-hidden">
             <div className="bg-blue-600 p-8 flex justify-between items-center text-white">
                <div className="flex items-center gap-4">
                   <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                      <i className="fas fa-tag"></i>
                   </div>
                   <h3 className="text-xl font-black tracking-tight uppercase">New Global Voucher</h3>
                </div>
                <button onClick={() => setIsCreateModalOpen(false)} className="w-10 h-10 hover:bg-white/10 rounded-xl flex items-center justify-center">
                   <i className="fas fa-times"></i>
                </button>
             </div>
             
             <form onSubmit={handleCreatePromo} className="p-8 space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Promo Code</label>
                    <input required name="code" type="text" placeholder="e.g. SKYNEW" className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 font-bold text-slate-800 outline-none focus:border-blue-500 transition-all" />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Offer Value</label>
                    <input required name="amount" type="text" placeholder="e.g. ₹1,000 OFF" className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 font-bold text-slate-800 outline-none focus:border-blue-500 transition-all" />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Full Description</label>
                  <textarea required name="desc" rows={3} placeholder="Detailed terms and conditions..." className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 font-bold text-slate-800 outline-none focus:border-blue-500 transition-all resize-none" />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Expiry Date</label>
                    <input required name="expires" type="text" placeholder="Dec 31, 2026" className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 font-bold text-slate-800 outline-none focus:border-blue-500 transition-all" />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Icon Category</label>
                    <select name="icon" className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 font-bold text-slate-800 outline-none appearance-none">
                       <option value="fa-plane">Flights</option>
                       <option value="fa-globe">International</option>
                       <option value="fa-hotel">Hotels</option>
                       <option value="fa-taxi">Cab/Transfer</option>
                       <option value="fa-sparkles">Special Event</option>
                    </select>
                  </div>
                </div>

                <button 
                  type="submit" 
                  disabled={isProcessing}
                  className="w-full bg-blue-600 text-white font-black py-5 rounded-2xl shadow-xl hover:bg-blue-700 transition-all uppercase tracking-[0.2em] text-[10px] flex items-center justify-center gap-3"
                >
                  {isProcessing ? <i className="fas fa-circle-notch animate-spin"></i> : <><i className="fas fa-cloud-upload-alt"></i> Deploy Voucher</>}
                </button>
             </form>
          </div>
        </div>
      )}

      {/* Configure Pools Modal */}
      {isPoolModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm animate-fadeIn" onClick={() => setIsPoolModalOpen(false)}></div>
          <div className="bg-white w-full max-w-2xl rounded-[2.5rem] shadow-2xl relative z-10 animate-slideUp border border-slate-100 overflow-hidden">
             <div className="bg-slate-900 p-8 flex justify-between items-center text-white">
                <div className="flex items-center gap-4">
                   <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center">
                      <i className="fas fa-users-cog"></i>
                   </div>
                   <div>
                      <h3 className="text-xl font-black tracking-tight uppercase">Corporate Pool Config</h3>
                      <p className="text-[9px] font-black text-blue-400 uppercase tracking-widest">Enterprise Access Panel</p>
                   </div>
                </div>
                <button onClick={() => setIsPoolModalOpen(false)} className="w-10 h-10 hover:bg-white/10 rounded-xl flex items-center justify-center">
                   <i className="fas fa-times"></i>
                </button>
             </div>
             
             <form onSubmit={handlePoolSave} className="p-8 space-y-8">
                <div className="space-y-4">
                   <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Organization</label>
                        <input required type="text" defaultValue="Global Tech Solutions" className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 font-bold text-slate-800 outline-none" />
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Pool Budget Limit</label>
                        <input required type="text" defaultValue="₹5,00,000" className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 font-bold text-slate-800 outline-none" />
                      </div>
                   </div>

                   <div className="space-y-3">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Allocation Strategy</p>
                      <div className="grid grid-cols-3 gap-3">
                         {['Departmental', 'Individual', 'Open Pool'].map((strategy) => (
                           <button key={strategy} type="button" className={`px-4 py-3 rounded-xl border text-[9px] font-black uppercase tracking-widest transition-all ${strategy === 'Departmental' ? 'bg-blue-600 border-blue-600 text-white' : 'bg-white border-slate-100 text-slate-400 hover:border-blue-200'}`}>
                              {strategy}
                           </button>
                         ))}
                      </div>
                   </div>
                </div>

                <div className="space-y-4">
                   <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Active Departmental Pools</p>
                   <div className="space-y-3">
                      {[
                        { name: 'Engineering', limit: '₹2,00,000', used: '₹45,000' },
                        { name: 'Sales & Marketing', limit: '₹1,50,000', used: '₹88,000' },
                        { name: 'Leadership', limit: 'Unlimited', used: '₹12,400' }
                      ].map((dept, i) => (
                        <div key={i} className="flex items-center justify-between p-4 bg-slate-50 border border-slate-200 rounded-2xl">
                           <div className="flex items-center gap-3">
                              <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center text-blue-600 border border-slate-100 shadow-sm">
                                 <i className="fas fa-briefcase text-xs"></i>
                              </div>
                              <div>
                                 <p className="text-xs font-black text-slate-900">{dept.name}</p>
                                 <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Limit: {dept.limit}</p>
                              </div>
                           </div>
                           <div className="text-right">
                              <p className="text-[9px] font-black text-blue-600 uppercase tracking-widest">Utilized: {dept.used}</p>
                              <div className="w-24 h-1 bg-slate-200 rounded-full mt-1 overflow-hidden">
                                 <div className="h-full bg-blue-500 w-1/3"></div>
                              </div>
                           </div>
                        </div>
                      ))}
                   </div>
                </div>

                <div className="flex gap-4">
                   <button 
                    type="button" 
                    onClick={() => setIsPoolModalOpen(false)}
                    className="flex-1 bg-slate-50 text-slate-500 font-black py-5 rounded-2xl border border-slate-200 uppercase tracking-[0.2em] text-[10px] hover:bg-slate-100 transition-all"
                   >
                     Cancel
                   </button>
                   <button 
                    type="submit" 
                    disabled={isProcessing}
                    className="flex-[2] bg-blue-600 text-white font-black py-5 rounded-2xl shadow-xl hover:bg-blue-700 transition-all uppercase tracking-[0.2em] text-[10px] flex items-center justify-center gap-3"
                   >
                     {isProcessing ? <i className="fas fa-circle-notch animate-spin"></i> : 'Apply Configurations'}
                   </button>
                </div>
             </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default OffersPage;
