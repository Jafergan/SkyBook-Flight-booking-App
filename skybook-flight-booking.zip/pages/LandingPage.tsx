import React, { useState, useEffect } from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { User } from '../types';

const demoData = [
  { name: 'Mon', spend: 4000, bookings: 24, velocity: 85, accuracy: 98 },
  { name: 'Tue', spend: 3000, bookings: 13, velocity: 88, accuracy: 99 },
  { name: 'Wed', spend: 2000, bookings: 98, velocity: 92, accuracy: 99.5 },
  { name: 'Thu', spend: 2780, bookings: 39, velocity: 84, accuracy: 98 },
  { name: 'Fri', spend: 1890, bookings: 48, velocity: 90, accuracy: 99 },
  { name: 'Sat', spend: 2390, bookings: 38, velocity: 94, accuracy: 99.5 },
  { name: 'Sun', spend: 3490, bookings: 43, velocity: 98, accuracy: 99.9 },
];

interface LandingPageProps {
  currentUser: User | null;
  onLogout: () => void;
  onGoDashboard: () => void;
  onGetStarted: () => void;
  onLogin: () => void;
  onOffers: () => void;
  onWhySkyBook: () => void;
  onNetworkStatus: () => void;
  onLegal: (tab: any) => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ 
  currentUser, 
  onLogout, 
  onGoDashboard,
  onGetStarted, 
  onLogin, 
  onOffers, 
  onWhySkyBook, 
  onNetworkStatus, 
  onLegal 
}) => {
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeMetric, setActiveMetric] = useState<'spend' | 'bookings' | 'velocity' | 'accuracy'>('spend');
  const [isRefreshing, setIsRefreshing] = useState(false);

  const copyToClipboard = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const handleMetricToggle = (metric: any) => {
    setIsRefreshing(true);
    setActiveMetric(metric);
    setTimeout(() => setIsRefreshing(false), 500);
  };

  const scrollToSearch = () => {
    const element = document.getElementById('search');
    element?.scrollIntoView({ behavior: 'smooth' });
    setIsMobileMenuOpen(false);
  };

  /**
   * Refined Mobile Logout Protocol
   */
  const handleMobileLogout = () => {
    // Close menu UI immediately to prevent focus traps during confirmation
    setIsMobileMenuOpen(false);
    // Execute global purge
    onLogout();
  };

  const getMetricColor = () => {
    switch(activeMetric) {
      case 'spend': return '#3b82f6';
      case 'bookings': return '#6366f1';
      case 'velocity': return '#f59e0b';
      case 'accuracy': return '#10b981';
      default: return '#3b82f6';
    }
  };

  const currentOffers = [
    { code: 'SKYFIRST25', title: 'New Traveler Bonus', desc: 'Get flat $25 off your very first international booking. Valid for all new SkyBook accounts.', badge: 'Most Popular', color: 'blue' },
    { code: 'GLOBE15', title: 'Seasonal Escape', desc: 'Enjoy a 15% reduction on base fares for all flights to Europe and SE Asia this month.', badge: 'Limited Time', color: 'emerald' },
    { code: 'PREMIUMUP', title: 'Luxury Upgrade', desc: 'Apply this code for a complimentary lounge access pass on your next Business Class flight.', badge: 'Exclusive', color: 'amber' }
  ];

  return (
    <div className="min-h-screen bg-white font-sans text-slate-900 overflow-x-hidden relative">
      {/* Mobile Navigation Column */}
      <div className={`fixed inset-0 z-[100] transition-opacity duration-300 lg:hidden ${isMobileMenuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`}>
         <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => setIsMobileMenuOpen(false)}></div>
         <div className={`absolute left-0 top-0 bottom-0 w-80 bg-white shadow-2xl transition-transform duration-500 transform ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'} flex flex-col`}>
            <div className="p-8 flex items-center justify-between border-b border-slate-50">
               <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white">
                    <i className="fas fa-plane-departure text-sm"></i>
                  </div>
                  <span className="text-xl font-extrabold tracking-tight">SkyBook</span>
               </div>
               <button onClick={() => setIsMobileMenuOpen(false)} className="w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center text-slate-400">
                  <i className="fas fa-times"></i>
               </button>
            </div>
            
            <nav className="flex-1 p-8 space-y-8 overflow-y-auto">
               <div className="space-y-4">
                  <p className="text-[10px] font-black text-slate-300 uppercase tracking-widest">Main Links</p>
                  <div className="space-y-2">
                     <button onClick={scrollToSearch} className="w-full text-left py-3 px-4 rounded-xl hover:bg-slate-50 font-bold text-slate-700 transition-all flex items-center gap-3">
                        <i className="fas fa-search text-blue-600"></i> Book Now
                     </button>
                     <button onClick={() => { onWhySkyBook(); setIsMobileMenuOpen(false); }} className="w-full text-left py-3 px-4 rounded-xl hover:bg-slate-50 font-bold text-slate-700 transition-all flex items-center gap-3">
                        <i className="fas fa-info-circle text-blue-600"></i> Why SkyBook
                     </button>
                     <button onClick={() => { onOffers(); setIsMobileMenuOpen(false); }} className="w-full text-left py-3 px-4 rounded-xl hover:bg-slate-50 font-bold text-slate-700 transition-all flex items-center gap-3">
                        <i className="fas fa-tags text-blue-600"></i> Offers
                     </button>
                  </div>
               </div>

               <div className="space-y-4">
                  <p className="text-[10px] font-black text-slate-300 uppercase tracking-widest">Legal & Policy</p>
                  <div className="space-y-2">
                     <button onClick={() => { onLegal('Privacy Policy'); setIsMobileMenuOpen(false); }} className="w-full text-left py-3 px-4 rounded-xl hover:bg-slate-50 font-bold text-slate-700 transition-all flex items-center gap-3">
                        <i className="fas fa-shield-alt text-slate-400"></i> Privacy Policy
                     </button>
                     <button onClick={() => { onLegal('Terms of Service'); setIsMobileMenuOpen(false); }} className="w-full text-left py-3 px-4 rounded-xl hover:bg-slate-50 font-bold text-slate-700 transition-all flex items-center gap-3">
                        <i className="fas fa-file-contract text-slate-400"></i> Terms of Service
                     </button>
                  </div>
               </div>
            </nav>

            <div className="p-8 border-t border-slate-50 space-y-4">
               {currentUser ? (
                  <>
                     <button onClick={() => { onGoDashboard(); setIsMobileMenuOpen(false); }} className="w-full py-4 bg-blue-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-blue-500/20">Go to Dashboard</button>
                     <button onClick={handleMobileLogout} className="w-full py-4 bg-red-50 text-red-600 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-3">
                        <i className="fas fa-sign-out-alt"></i> Log Out
                     </button>
                  </>
               ) : (
                  <>
                     <button onClick={() => { onLogin(); setIsMobileMenuOpen(false); }} className="w-full py-4 bg-white border border-slate-200 text-slate-700 rounded-2xl font-black text-xs uppercase tracking-widest">Sign In</button>
                     <button onClick={() => { onGetStarted(); setIsMobileMenuOpen(false); }} className="w-full py-4 bg-blue-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-blue-500/20">Get Started</button>
                  </>
               )}
            </div>
         </div>
      </div>

      <nav className="flex items-center justify-between px-6 md:px-12 py-6 max-w-7xl mx-auto z-50 relative">
        <div className="flex items-center gap-6">
          <button onClick={() => setIsMobileMenuOpen(true)} className="lg:hidden w-10 h-10 flex items-center justify-center text-slate-700 bg-slate-50 rounded-xl">
             <i className="fas fa-bars"></i>
          </button>
          <div className="flex items-center gap-2 cursor-pointer group" onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})}>
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white transition-transform group-hover:rotate-12">
              <i className="fas fa-plane-departure text-sm"></i>
            </div>
            <span className="text-xl font-extrabold tracking-tight text-slate-900">SkyBook</span>
          </div>
        </div>
        
        <div className="hidden lg:flex items-center gap-8 text-sm font-semibold text-slate-600">
          <button onClick={scrollToSearch} className="hover:text-blue-600 transition-colors uppercase tracking-widest text-[10px] font-black">Book Now</button>
          <button onClick={onWhySkyBook} className="hover:text-blue-600 transition-colors uppercase tracking-widest text-[10px] font-black">Why SkyBook</button>
          <button onClick={onOffers} className="hover:text-blue-600 transition-colors uppercase tracking-widest text-[10px] font-black">Offers</button>
        </div>

        <div className="hidden md:flex items-center gap-2 md:gap-4">
          {currentUser ? (
             <>
               <button onClick={onGoDashboard} className="px-4 md:px-5 py-2 text-[10px] md:text-xs font-black uppercase tracking-widest text-slate-700 hover:text-blue-600 transition-colors border border-slate-200 rounded-xl">Dashboard</button>
               <button onClick={onLogout} className="px-4 md:px-6 py-2.5 text-[10px] md:text-xs font-black uppercase tracking-widest bg-slate-900 text-white rounded-xl shadow-lg hover:bg-black transition-all flex items-center gap-2">
                  <i className="fas fa-sign-out-alt"></i> Log Out
               </button>
             </>
          ) : (
             <>
               <button onClick={onLogin} className="px-4 md:px-5 py-2 text-[10px] md:text-xs font-black uppercase tracking-widest text-slate-700 hover:text-blue-600 transition-colors border border-slate-200 rounded-xl">Login</button>
               <button onClick={onGetStarted} className="px-4 md:px-6 py-2.5 text-[10px] md:text-xs font-black uppercase tracking-widest bg-blue-600 text-white rounded-xl shadow-lg shadow-blue-200 hover:bg-blue-700 transition-all">Join</button>
             </>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen lg:h-[90vh] flex items-center px-4 md:px-6 overflow-hidden py-12 lg:py-24">
        <div className="absolute inset-0 z-0">
          <img src="https://images.unsplash.com/photo-1517400508447-f8dd518b86db?auto=format&fit=crop&q=80&w=2000" alt="Commercial airplane" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-900/60 via-slate-900/40 to-slate-900/20 lg:to-transparent"></div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto w-full flex flex-col-reverse lg:grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-white space-y-6 animate-fadeInLeft w-full lg:max-w-xl">
            <button onClick={onNetworkStatus} className="inline-flex items-center gap-3 px-4 py-2 bg-blue-600/20 backdrop-blur-xl rounded-full border border-blue-400/30 mb-2 hover:bg-blue-600/40 transition-all shadow-2xl">
              <span className="block w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></span>
              <span className="text-[8px] md:text-[10px] font-black uppercase tracking-widest text-white">Network Live Monitoring</span>
            </button>
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-black leading-tight drop-shadow-2xl">
              Travel the <br className="hidden md:block"/> 
              <span className="text-blue-400">World</span> with Ease.
            </h1>
            <p className="text-base md:text-xl text-slate-100 font-medium leading-relaxed opacity-95">The simplest way to search, compare, and book flights instantly. Luxury and reliability in every journey.</p>
            <div className="flex items-center gap-6 pt-2">
               <div className="flex flex-col">
                 <span className="text-xl md:text-2xl font-black">500+</span>
                 <span className="text-[9px] uppercase font-bold text-slate-300">Airlines</span>
               </div>
               <div className="w-[1px] h-8 bg-white/20"></div>
               <div className="flex flex-col">
                 <span className="text-xl md:text-2xl font-black">24/7</span>
                 <span className="text-[9px] uppercase font-bold text-slate-300">Support</span>
               </div>
            </div>
            <button onClick={onWhySkyBook} className="mt-2 flex items-center gap-3 text-xs md:text-sm font-black uppercase tracking-widest text-blue-400 hover:text-white transition-colors group">
              Explore Our Excellence <i className="fas fa-arrow-right group-hover:translate-x-2 transition-transform"></i>
            </button>
          </div>

          <div id="search" className="animate-fadeInRight delay-200 w-full max-w-md lg:ml-auto">
            <div className="bg-white rounded-[2rem] md:rounded-[2.5rem] shadow-2xl p-2 border border-slate-100">
              <div className="bg-slate-50/50 rounded-[1.8rem] md:rounded-[2.2rem] p-6 md:p-8 relative overflow-hidden">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg md:text-xl font-black text-slate-900 tracking-tight">Quick Search</h3>
                  <i className="fas fa-plane-departure text-blue-600/10 text-2xl"></i>
                </div>
                <div className="space-y-4">
                  <div className="space-y-1">
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] px-1">Origin</label>
                    <div className="flex items-center gap-3 bg-white p-3.5 md:p-4 rounded-xl md:rounded-2xl border border-slate-200 h-[54px]">
                      <i className="fas fa-map-marker-alt text-slate-300 text-sm"></i>
                      <input type="text" defaultValue="Delhi (DEL)" className="bg-transparent font-extrabold text-slate-800 w-full outline-none text-xs md:text-sm" />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] px-1">Destination</label>
                    <div className="flex items-center gap-3 bg-white p-3.5 md:p-4 rounded-xl md:rounded-2xl border border-slate-200 h-[54px]">
                      <i className="fas fa-map-pin text-slate-300 text-sm"></i>
                      <input type="text" defaultValue="Dubai (DXB)" className="bg-transparent font-extrabold text-slate-800 w-full outline-none text-xs md:text-sm" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] px-1">Date</label>
                      <div className="bg-white p-3.5 md:p-4 rounded-xl md:rounded-2xl border border-slate-200 h-[54px]">
                        <input type="text" defaultValue="15 Aug" className="bg-transparent font-extrabold text-slate-800 w-full outline-none text-xs md:text-sm text-center" />
                      </div>
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] px-1">Travelers</label>
                      <div className="bg-white p-3.5 md:p-4 rounded-xl md:rounded-2xl border border-slate-200 h-[54px]">
                        <input type="text" defaultValue="2" className="bg-transparent font-extrabold text-slate-800 w-full outline-none text-xs md:text-sm text-center" />
                      </div>
                    </div>
                  </div>
                  <button onClick={onGetStarted} className="w-full h-[58px] md:h-[64px] bg-blue-600 text-white font-black rounded-xl md:rounded-2xl shadow-xl hover:bg-blue-700 transition-all flex items-center justify-center gap-3 active:scale-95 mt-2">
                    <span className="uppercase tracking-widest text-[10px] md:text-xs">Explore Flights</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Interactive CRM Engine Preview */}
      <section className="py-24 bg-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
            <div className="space-y-10">
              <div className="space-y-4">
                <span className="text-blue-600 font-black text-[10px] uppercase tracking-[0.3em]">Platform Sovereignty</span>
                <h2 className="text-4xl md:text-6xl font-black text-slate-900 leading-tight tracking-tight">The Core of <br/> <span className="text-blue-600">Intelligence.</span></h2>
                <p className="text-lg text-slate-500 font-medium leading-relaxed max-w-xl">Experience the power of our v5.0 Neural Engine. Toggle between operational functions below to see how SkyBook analyzes global data in real-time.</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                 {[
                   { id: 'velocity', label: 'Velocity', icon: 'fa-bolt', color: 'amber' },
                   { id: 'accuracy', label: 'Accuracy', icon: 'fa-bullseye', color: 'emerald' },
                   { id: 'spend', label: 'My Spend', icon: 'fa-coins', color: 'blue' },
                   { id: 'bookings', label: 'Bookings', icon: 'fa-plane', color: 'indigo' },
                 ].map((m) => (
                   <button 
                    key={m.id}
                    onClick={() => handleMetricToggle(m.id)}
                    className={`p-6 rounded-[2rem] border transition-all text-left group ${activeMetric === m.id ? `bg-${m.color}-50 border-${m.color}-200 shadow-lg` : 'bg-slate-50 border-slate-100 hover:bg-white hover:border-slate-200'}`}
                   >
                     <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-6 transition-all ${activeMetric === m.id ? `bg-${m.color}-500 text-white` : 'bg-white text-slate-400 group-hover:text-blue-600'}`}>
                        <i className={`fas ${m.icon} text-lg`}></i>
                     </div>
                     <p className={`text-[10px] font-black uppercase tracking-widest ${activeMetric === m.id ? `text-${m.color}-600` : 'text-slate-400'}`}>{m.label}</p>
                     <p className="text-sm font-bold text-slate-900 mt-1">Initialize Function</p>
                   </button>
                 ))}
              </div>
            </div>

            <div className="relative group">
               <div className="absolute -inset-10 bg-blue-600/5 rounded-full blur-[100px] pointer-events-none group-hover:bg-blue-600/10 transition-all"></div>
               <div className="bg-slate-900 rounded-[3rem] p-1 border border-white/10 shadow-2xl overflow-hidden relative z-10">
                  <div className="bg-slate-950 rounded-[2.8rem] p-10 space-y-10">
                     <div className="flex justify-between items-start">
                        <div className="space-y-2">
                           <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white text-xs">
                                 <i className="fas fa-microchip"></i>
                              </div>
                              <h4 className="text-white font-black text-lg">CRM Analysis</h4>
                           </div>
                           <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest pl-11">Function: {activeMetric}</p>
                        </div>
                        <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-full">
                           <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
                           <span className="text-[8px] font-black text-emerald-500 uppercase tracking-widest">Live Node</span>
                        </div>
                     </div>

                     <div className="h-[250px] w-full relative">
                        {isRefreshing && (
                          <div className="absolute inset-0 z-20 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm">
                             <i className="fas fa-circle-notch animate-spin text-blue-500 text-2xl"></i>
                          </div>
                        )}
                        <ResponsiveContainer width="100%" height="100%">
                           <AreaChart data={demoData}>
                              <defs>
                                 <linearGradient id="landingColor" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor={getMetricColor()} stopOpacity={0.3}/>
                                    <stop offset="95%" stopColor={getMetricColor()} stopOpacity={0}/>
                                 </linearGradient>
                              </defs>
                              <CartesianGrid strokeDasharray="5 5" vertical={false} stroke="#ffffff08" />
                              <XAxis dataKey="name" hide />
                              <Tooltip 
                                contentStyle={{ backgroundColor: '#020617', border: 'none', borderRadius: '12px', fontSize: '10px' }}
                                itemStyle={{ fontWeight: '900', textTransform: 'uppercase' }}
                              />
                              <Area type="monotone" dataKey={activeMetric} stroke={getMetricColor()} strokeWidth={4} fillOpacity={1} fill="url(#landingColor)" animationDuration={1000} />
                           </AreaChart>
                        </ResponsiveContainer>
                     </div>

                     <div className="pt-6 border-t border-white/5 grid grid-cols-2 gap-6">
                        <div>
                           <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest mb-1">Efficiency Delta</p>
                           <p className="text-xl font-black text-white">+12.4%</p>
                        </div>
                        <div>
                           <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest mb-1">Operational Latency</p>
                           <p className="text-xl font-black text-blue-400">1.2ms</p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why SkyBook Section */}
      <section className="max-w-7xl mx-auto px-6 py-20 md:py-32">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <div className="space-y-6 md:space-y-8">
            <div>
              <span className="text-blue-600 font-black text-[10px] md:text-xs uppercase tracking-[0.3em] mb-3 block">Unmatched Quality</span>
              <h2 className="text-3xl md:text-5xl font-black text-slate-900 leading-tight">
                Experience the <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">Standard</span> of Modern Travel.
              </h2>
            </div>
            <p className="text-slate-500 font-medium text-base md:text-lg leading-relaxed">SkyBook combines industry-leading AI intelligence with a deep commitment to hospitality.</p>
            <div className="flex flex-col sm:flex-row gap-4 pt-2">
              <button onClick={onWhySkyBook} className="px-8 py-3.5 bg-slate-900 text-white rounded-xl font-black text-[10px] uppercase tracking-widest shadow-xl hover:bg-slate-800 transition-all">Learn More</button>
              <button onClick={onGetStarted} className="px-8 py-3.5 bg-white border border-slate-200 text-slate-900 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-slate-50 transition-all text-center">Start Now</button>
            </div>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-6">
            {[
              { icon: 'fa-bolt', title: 'Instant Booking', desc: 'Real-time GDS integration for zero-wait.' },
              { icon: 'fa-headset', title: 'Elite Support', desc: 'Concierge-level assistance for every traveler.' },
              { icon: 'fa-shield-alt', title: 'Secure Gateway', desc: 'Banking-grade security for transactions.' },
              { icon: 'fa-percentage', title: 'True Pricing', desc: 'No hidden surcharges. What you see is what you pay.' },
            ].map((f, i) => (
              <div key={i} className={`bg-slate-50 p-6 md:p-8 rounded-[2rem] border border-slate-100 transition-all hover:bg-white hover:shadow-xl ${i % 2 !== 0 ? 'lg:mt-8' : ''}`}>
                <div className="w-10 h-10 md:w-12 md:h-12 bg-blue-100 rounded-xl flex items-center justify-center text-blue-600 mb-6">
                  <i className={`fas ${f.icon} text-sm`}></i>
                </div>
                <h4 className="font-black text-slate-900 mb-2 text-sm md:text-base">{f.title}</h4>
                <p className="text-slate-500 text-xs font-medium leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Offers Section */}
      <section id="offers" className="bg-slate-50 py-20 md:py-32 scroll-mt-20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16 md:mb-24 space-y-4">
            <span className="text-blue-600 font-black text-[10px] md:text-xs uppercase tracking-[0.3em]">Exclusive Privileges</span>
            <h2 className="text-3xl md:text-5xl font-black text-slate-900 tracking-tight">World-Class Savings.</h2>
            <p className="text-slate-500 font-medium text-base md:text-lg max-w-2xl mx-auto leading-relaxed">Unlock extraordinary value on your next journey with our curated selection of traveler rewards and seasonal incentives.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-10">
            {currentOffers.map((offer, i) => (
              <div key={i} className="group relative bg-white rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-2xl transition-all duration-500 overflow-hidden flex flex-col">
                <div className="p-8 md:p-10 flex-1 space-y-6">
                  <div className="flex justify-between items-start">
                    <div className={`w-14 h-14 rounded-2xl bg-${offer.color}-50 flex items-center justify-center text-${offer.color}-600 text-xl shadow-inner group-hover:scale-110 transition-transform`}>
                      <i className={`fas ${i === 0 ? 'fa-user-plus' : i === 1 ? 'fa-sun' : 'fa-crown'}`}></i>
                    </div>
                    <span className={`text-[9px] font-black px-3 py-1.5 rounded-full uppercase tracking-widest bg-${offer.color}-100 text-${offer.color}-700 border border-${offer.color}-200`}>
                      {offer.badge}
                    </span>
                  </div>

                  <div>
                    <h3 className="text-2xl font-black text-slate-900 tracking-tight mb-2">{offer.title}</h3>
                    <p className="text-sm font-medium text-slate-500 leading-relaxed">{offer.desc}</p>
                  </div>
                </div>

                <div className="relative overflow-hidden">
                  <div className="absolute inset-x-0 top-0 border-t-2 border-dashed border-slate-100 -translate-y-px"></div>
                  <div className="absolute -left-3 top-0 -translate-y-1/2 w-6 h-6 bg-slate-50 rounded-full border border-slate-100"></div>
                  <div className="absolute -right-3 top-0 -translate-y-1/2 w-6 h-6 bg-slate-50 rounded-full border border-slate-100"></div>
                  
                  <div className="p-8 bg-slate-50/50 flex flex-col items-center gap-4">
                    <div className="flex items-center gap-2 bg-white px-6 py-3 rounded-2xl border border-slate-200 shadow-sm w-full justify-between group/code">
                      <span className="text-sm font-black text-slate-900 tracking-widest">{offer.code}</span>
                      <button 
                        onClick={() => copyToClipboard(offer.code)}
                        className={`text-[10px] font-black uppercase tracking-widest transition-all ${copiedCode === offer.code ? 'text-emerald-600' : 'text-blue-600 hover:text-blue-700'}`}
                      >
                        {copiedCode === offer.code ? 'Copied' : 'Copy'}
                      </button>
                    </div>
                    <button onClick={onGetStarted} className="text-[10px] font-black text-slate-400 uppercase tracking-widest hover:text-blue-600 transition-colors">
                      View Eligibility Details <i className="fas fa-chevron-right text-[8px] ml-1"></i>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-16 text-center space-y-4">
             <button onClick={onGetStarted} className="px-12 py-5 bg-blue-600 text-white rounded-2xl font-black text-sm uppercase tracking-[0.2em] shadow-2xl shadow-blue-500/20 hover:bg-blue-700 transition-all active:scale-95">
               Unlock Full Inventory Catalog
             </button>
             <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Join 50,000+ travelers accessing exclusive GDS-only inventory and private regional fares.</p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-50 border-t border-slate-200 py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8">
          <div className="space-y-6">
            <div className="flex items-center gap-2">
               <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white">
                 <i className="fas fa-plane-departure text-sm"></i>
               </div>
               <span className="text-xl font-extrabold tracking-tight text-slate-900">SkyBook</span>
            </div>
            <p className="text-slate-400 text-sm font-medium leading-relaxed">Redefining the global travel experience through neural intelligence and elite hospitality standards.</p>
            <div className="flex gap-4">
               {['facebook', 'twitter', 'linkedin', 'instagram'].map(s => (
                 <a key={s} href="#" className="w-8 h-8 rounded-full bg-white border border-slate-200 flex items-center justify-center text-slate-400 hover:text-blue-600 hover:border-blue-600 transition-all">
                    <i className={`fab fa-${s} text-xs`}></i>
                 </a>
               ))}
            </div>
          </div>

          <div className="space-y-6 lg:ml-auto">
             <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-900">Experience</h4>
             <ul className="space-y-3">
                <li><button onClick={scrollToSearch} className="text-xs font-bold text-slate-500 hover:text-blue-600 transition-colors">Book a Flight</button></li>
                <li><button onClick={onWhySkyBook} className="text-xs font-bold text-slate-500 hover:text-blue-600 transition-colors">Why SkyBook</button></li>
                <li><button onClick={onOffers} className="text-xs font-bold text-slate-500 hover:text-blue-600 transition-colors">Special Offers</button></li>
                <li><button onClick={onNetworkStatus} className="text-xs font-bold text-slate-500 hover:text-blue-600 transition-colors">Network Status</button></li>
             </ul>
          </div>

          <div className="space-y-6 lg:ml-auto">
             <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-900">Legal & Policy</h4>
             <ul className="space-y-3">
                <li><button onClick={() => onLegal('Privacy Policy')} className="text-xs font-bold text-slate-500 hover:text-blue-600 transition-colors">Privacy Policy</button></li>
                <li><button onClick={() => onLegal('Terms of Service')} className="text-xs font-bold text-slate-500 hover:text-blue-600 transition-colors">Terms of Service</button></li>
                <li><button onClick={() => onLegal('Cookie Policy')} className="text-xs font-bold text-slate-500 hover:text-blue-600 transition-colors">Cookie Policy</button></li>
                <li><button onClick={() => onLegal('Compliance')} className="text-xs font-bold text-slate-500 hover:text-blue-600 transition-colors">Compliance Board</button></li>
             </ul>
          </div>

          <div className="space-y-6 lg:ml-auto">
             <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-900">Terminal Access</h4>
             <div className="space-y-3">
                {currentUser ? (
                   <>
                      <button onClick={onGoDashboard} className="w-full py-3 bg-blue-600 text-white rounded-xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-blue-200">Go to App</button>
                      <button onClick={onLogout} className="w-full py-3 bg-white border border-slate-200 text-red-600 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-red-50 transition-colors flex items-center justify-center gap-2">
                         <i className="fas fa-sign-out-alt"></i> Log Out
                      </button>
                   </>
                ) : (
                   <button onClick={onLogin} className="w-full py-3 bg-slate-900 text-white rounded-xl font-black text-[10px] uppercase tracking-widest shadow-xl hover:bg-black transition-all">Sign In to Workspace</button>
                )}
                <p className="text-[10px] font-bold text-slate-400 mt-4">© 2025 SkyBook Global Operations.</p>
             </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;