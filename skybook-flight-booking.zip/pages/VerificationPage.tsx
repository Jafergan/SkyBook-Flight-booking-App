import React, { useState, useRef, useEffect } from 'react';

interface VerificationPageProps {
  onVerify: () => void;
  onBack: () => void;
  email: string;
}

const VerificationPage: React.FC<VerificationPageProps> = ({ onVerify, onBack, email }) => {
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [timeLeft, setTimeLeft] = useState(120);
  const [isVerifying, setIsVerifying] = useState(false);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    inputRefs.current[0]?.focus();
    const timer = setInterval(() => {
      setTimeLeft(prev => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleChange = (index: number, value: string) => {
    if (isNaN(Number(value))) return;
    const newOtp = [...otp];
    newOtp[index] = value.substring(value.length - 1);
    setOtp(newOtp);
    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handleVerify = () => {
    setIsVerifying(true);
    setTimeout(() => {
      setIsVerifying(false);
      onVerify();
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center p-6 animate-fadeIn">
      <div className="max-w-md w-full space-y-10">
        <div className="text-center space-y-4">
          <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mx-auto shadow-inner">
            <i className="fas fa-shield-alt text-2xl"></i>
          </div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight">Security Check</h1>
          <p className="text-slate-500 font-medium leading-relaxed">
            We've transmitted a secure 6-digit code to <span className="text-blue-600 font-bold">{email}</span>. Please verify your identity.
          </p>
        </div>

        <div className="flex gap-2 justify-center">
          {otp.map((digit, i) => (
            <input
              key={i}
              ref={el => inputRefs.current[i] = el}
              type="text"
              maxLength={1}
              value={digit}
              onChange={e => handleChange(i, e.target.value)}
              onKeyDown={e => handleKeyDown(i, e)}
              className="w-12 h-16 text-center text-2xl font-black bg-slate-50 border-2 border-slate-100 rounded-xl focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-500/10 outline-none transition-all"
            />
          ))}
        </div>

        <div className="space-y-6">
          <button
            onClick={handleVerify}
            disabled={otp.some(d => !d) || isVerifying}
            className="w-full bg-blue-600 text-white font-black py-5 rounded-2xl shadow-xl shadow-blue-500/20 hover:bg-blue-700 transition-all flex items-center justify-center gap-3 disabled:opacity-50"
          >
            {isVerifying ? <i className="fas fa-circle-notch animate-spin"></i> : 'Verify & Synchronize'}
          </button>
          
          <div className="flex justify-between items-center px-2">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
              Expires in <span className="text-blue-600">{Math.floor(timeLeft / 60)}:{String(timeLeft % 60).padStart(2, '0')}</span>
            </p>
            <button className="text-[10px] font-black text-blue-600 uppercase tracking-widest hover:underline">Resend Code</button>
          </div>
        </div>
        
        <button onClick={onBack} className="w-full text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] hover:text-slate-600 transition-colors text-center">
          <i className="fas fa-arrow-left mr-2"></i> Use different email
        </button>
      </div>
    </div>
  );
};

export default VerificationPage;