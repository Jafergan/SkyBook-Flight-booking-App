
import React, { useState, useRef, useEffect } from 'react';
import { chatWithAssistant } from '../services/geminiService';

const Chatbot: React.FC = () => {
  const initialMessage = { role: 'model' as const, text: "Welcome to SkyBook Intelligence v5.0. 🌐 I can analyze fares, forecast weather, and manage your travel pipeline with precision. How shall we proceed?" };
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<{ role: 'user' | 'model', text: string, type?: 'text' | 'flight_card' | 'offer' | 'analysis' }[]>([initialMessage]);
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = async (customMsg?: string) => {
    const userMsg = customMsg || input;
    if (!userMsg.trim()) return;

    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsTyping(true);

    const history = messages.map(m => ({ role: m.role, parts: [{ text: m.text }] }));
    const aiResponse = await chatWithAssistant(userMsg, history);
    
    // Logic for specialized analysis types
    if (userMsg.toLowerCase().includes('compare') || userMsg.toLowerCase().includes('price')) {
      setMessages(prev => [...prev, 
        { role: 'model', text: "Analysis Complete: Route BOM-DXB is seeing a 15% price surge next week. Recommendation: Book now.", type: 'analysis' },
        { role: 'model', text: aiResponse || 'Calculation complete.' }
      ]);
    } else {
      setMessages(prev => [...prev, { role: 'model', text: aiResponse || 'I encountered an error during analysis.' }]);
    }
    setIsTyping(false);
  };

  return (
    <div className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-[100]">
      {isOpen ? (
        <div className="bg-white w-[calc(100vw-32px)] sm:w-[380px] h-[calc(100vh-100px)] sm:h-[620px] max-h-[calc(100vh-40px)] sm:max-h-[calc(100vh-80px)] rounded-[2rem] sm:rounded-[2.5rem] shadow-[0_30px_90px_rgba(0,0,0,0.2)] flex flex-col border border-slate-100 overflow-hidden animate-slideUp origin-bottom-right">
          {/* AI v5.0 Header */}
          <div className="bg-gradient-to-r from-blue-700 to-indigo-800 p-4 sm:p-5 flex justify-between items-center text-white shrink-0">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 sm:w-10 sm:h-10 bg-white/10 backdrop-blur-xl rounded-[1rem] sm:rounded-[1.2rem] flex items-center justify-center text-base sm:text-lg border border-white/20 shadow-xl">
                <i className="fas fa-brain animate-pulse"></i>
              </div>
              <div>
                <p className="font-black text-xs sm:text-sm tracking-tight">SkyBook Intelligence <span className="text-[8px] sm:text-[9px] font-bold bg-white/20 px-1.5 py-0.5 rounded ml-1">v5.0</span></p>
                <p className="text-[9px] sm:text-[10px] font-bold text-blue-200 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full shadow-[0_0_8px_rgba(52,211,153,0.8)]"></span> Neural Engine Active
                </p>
              </div>
            </div>
            <div className="flex items-center gap-1 sm:gap-2">
              <button onClick={() => setMessages([initialMessage])} className="w-7 h-7 sm:w-8 sm:h-8 hover:bg-white/10 rounded-lg transition-all flex items-center justify-center" title="Reset Session"><i className="fas fa-undo-alt text-[10px] sm:text-[11px]"></i></button>
              <button onClick={() => setIsOpen(false)} className="w-7 h-7 sm:w-8 sm:h-8 hover:bg-white/10 rounded-lg transition-all flex items-center justify-center"><i className="fas fa-times text-[10px] sm:text-[11px]"></i></button>
            </div>
          </div>

          {/* Messages Area */}
          <div ref={scrollRef} className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4 sm:space-y-5 bg-slate-50/80 scrollbar-hide">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'} animate-fadeIn`}>
                <div className="flex gap-2 sm:gap-3 max-w-[95%] sm:max-w-[90%]">
                  {m.role === 'model' && (
                    <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg sm:rounded-xl bg-white border border-slate-100 flex items-center justify-center text-blue-600 text-[9px] sm:text-[10px] shrink-0 mt-1 shadow-sm">
                      <i className="fas fa-bolt"></i>
                    </div>
                  )}
                  <div className="space-y-3 w-full">
                    {m.type === 'analysis' ? (
                      <div className="bg-gradient-to-br from-indigo-900 to-blue-900 p-4 sm:p-5 rounded-[1.2rem] sm:rounded-[1.5rem] text-white shadow-xl border border-white/10 space-y-3">
                        <div className="flex items-center gap-2">
                          <i className="fas fa-chart-pie text-blue-300 text-xs"></i>
                          <p className="text-[9px] sm:text-[10px] font-black uppercase tracking-widest text-blue-200">System Insight</p>
                        </div>
                        <p className="text-xs sm:text-[13px] font-bold leading-relaxed">{m.text}</p>
                        <div className="h-1 w-full bg-white/10 rounded-full overflow-hidden">
                           <div className="h-full bg-blue-400 w-3/4 animate-pulse"></div>
                        </div>
                      </div>
                    ) : (
                      <div className={`p-3 sm:p-4 rounded-[1.2rem] sm:rounded-[1.4rem] text-xs sm:text-[13px] leading-relaxed font-semibold ${
                        m.role === 'user' 
                          ? 'bg-blue-600 text-white rounded-br-none shadow-xl shadow-blue-500/20' 
                          : 'bg-white text-slate-700 border border-slate-200 rounded-bl-none shadow-sm'
                      }`}>
                        {m.text}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex justify-start gap-2 sm:gap-3">
                <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg sm:rounded-xl bg-white border border-slate-100 flex items-center justify-center text-blue-600 text-[9px] sm:text-[10px] shrink-0 shadow-sm">
                  <i className="fas fa-bolt animate-spin"></i>
                </div>
                <div className="bg-white p-3 sm:p-4 rounded-[1.2rem] sm:rounded-[1.4rem] rounded-bl-none border border-slate-200 shadow-sm flex gap-1.5 items-center">
                  <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce"></div>
                  <div className="w-1.5 h-1.5 bg-blue-600 rounded-full animate-bounce delay-100"></div>
                  <div className="w-1.5 h-1.5 bg-indigo-600 rounded-full animate-bounce delay-200"></div>
                </div>
              </div>
            )}
          </div>

          {/* Footer & Advanced Actions */}
          <div className="p-4 sm:p-5 border-t bg-white space-y-3 sm:space-y-4 shrink-0">
            <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1">
               <button onClick={() => handleSend("Compare prices for SIN")} className="px-3 py-1.5 sm:px-4 sm:py-2 bg-blue-50 text-blue-700 border border-blue-100 rounded-lg sm:rounded-xl text-[9px] sm:text-[10px] font-black whitespace-nowrap uppercase tracking-widest hover:bg-blue-100 transition-all flex items-center gap-2">
                 <i className="fas fa-chart-line"></i> Price Compare
               </button>
               <button onClick={() => handleSend("Weather forecast for London")} className="px-3 py-1.5 sm:px-4 sm:py-2 bg-amber-50 text-amber-700 border border-amber-100 rounded-lg sm:rounded-xl text-[9px] sm:text-[10px] font-black whitespace-nowrap uppercase tracking-widest hover:bg-amber-100 transition-all flex items-center gap-2">
                 <i className="fas fa-cloud-sun"></i> Weather
               </button>
               <button onClick={() => handleSend("Baggage rules")} className="px-3 py-1.5 sm:px-4 sm:py-2 bg-slate-50 text-slate-600 border border-slate-200 rounded-lg sm:rounded-xl text-[9px] sm:text-[10px] font-black whitespace-nowrap uppercase tracking-widest hover:bg-slate-100 transition-all">Baggage policy</button>
            </div>
            <div className="flex gap-2 sm:gap-3 items-center">
              <button className="w-9 h-9 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl bg-slate-50 text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition-all border border-slate-100 flex items-center justify-center shrink-0">
                <i className="fas fa-paperclip text-xs sm:text-sm"></i>
              </button>
              <div className="flex-1 relative group">
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="Ask SkyBook AI..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-[1rem] sm:rounded-[1.2rem] px-4 py-2.5 sm:px-5 sm:py-3 text-[11px] sm:text-xs focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all font-bold pr-10"
                />
                <button 
                  onClick={() => handleSend()}
                  className="absolute right-1.5 top-1/2 -translate-y-1/2 bg-blue-600 text-white w-7 h-7 sm:w-8 sm:h-8 rounded-lg sm:rounded-xl flex items-center justify-center shadow-lg hover:scale-110 active:scale-95 transition-all"
                >
                  <i className="fas fa-paper-plane text-[9px] sm:text-[10px]"></i>
                </button>
              </div>
            </div>
            <div className="flex items-center justify-center gap-2 opacity-30 grayscale pointer-events-none pb-1">
              <span className="text-[7px] sm:text-[8px] font-black text-slate-900 uppercase tracking-widest">Powered by Gemini Neural Engine</span>
              <div className="w-1 h-1 bg-slate-900 rounded-full"></div>
              <span className="text-[7px] sm:text-[8px] font-black text-slate-900 uppercase tracking-widest">v5.0 Enterprise</span>
            </div>
          </div>
        </div>
      ) : (
        <button 
          onClick={() => setIsOpen(true)}
          className="bg-gradient-to-tr from-blue-600 to-indigo-700 text-white w-14 h-14 sm:w-16 sm:h-16 rounded-[1.5rem] sm:rounded-[2rem] flex items-center justify-center shadow-[0_15px_40px_rgba(37,99,235,0.4)] hover:scale-110 transition-all duration-500 relative group overflow-hidden"
        >
          <div className="absolute inset-0 bg-white/20 opacity-0 group-hover:opacity-100 transition-opacity"></div>
          <i className="fas fa-brain text-xl sm:text-2xl group-hover:scale-125 transition-transform duration-500"></i>
          <span className="absolute top-2 right-2 w-3 h-3 sm:w-4 sm:h-4 bg-emerald-500 border-[3px] sm:border-[4px] border-white rounded-full shadow-sm"></span>
        </button>
      )}
    </div>
  );
};

export default Chatbot;
