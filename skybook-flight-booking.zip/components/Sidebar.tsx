import React from 'react';
import { UserRole } from '../types';

interface SidebarProps {
  currentRole: UserRole;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isOpen?: boolean;
  onLogout: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentRole, activeTab, setActiveTab, isOpen, onLogout }) => {
  const sections = [
    {
      title: 'Main Menu',
      items: [
        { id: 'dashboard', label: 'Dashboard', icon: 'fa-chart-line', roles: [UserRole.ADMIN, UserRole.AGENT, UserRole.USER] },
        { id: 'leads', label: 'Leads Pipeline', icon: 'fa-users', roles: [UserRole.ADMIN, UserRole.AGENT] },
        { id: 'manage-bookings', label: currentRole === UserRole.USER ? 'My Bookings' : 'Bookings', icon: 'fa-plane', roles: [UserRole.ADMIN, UserRole.AGENT, UserRole.USER] },
      ]
    },
    {
      title: 'Travel Tools',
      items: [
        { id: 'travel-info', label: 'Travel Insights', icon: 'fa-cloud-sun', roles: [UserRole.ADMIN, UserRole.AGENT, UserRole.USER] },
        { id: 'offers', label: 'Special Offers', icon: 'fa-tags', roles: [UserRole.ADMIN, UserRole.AGENT, UserRole.USER] },
        { id: 'reports', label: 'Performance', icon: 'fa-chart-bar', roles: [UserRole.ADMIN, UserRole.AGENT] },
      ]
    },
    {
      title: 'System & Help',
      items: [
        { id: 'help-support', label: 'Help Center', icon: 'fa-question-circle', roles: [UserRole.ADMIN, UserRole.AGENT, UserRole.USER] },
        { id: 'legal', label: 'Legal & Privacy', icon: 'fa-shield-halved', roles: [UserRole.ADMIN, UserRole.AGENT, UserRole.USER] },
        { id: 'admin-settings', label: 'Admin Settings', icon: 'fa-cog', roles: [UserRole.ADMIN] },
        { id: 'admin-users', label: 'User Control', icon: 'fa-user-shield', roles: [UserRole.ADMIN] },
      ]
    }
  ];

  return (
    <aside className={`fixed inset-y-0 left-0 lg:sticky lg:top-0 w-64 bg-white border-r border-slate-100 h-screen transition-transform duration-300 z-[60] shrink-0 flex flex-col ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
      <div className="p-8 flex items-center gap-3 shrink-0">
        <div className="w-10 h-10 bg-blue-600 rounded-2xl flex items-center justify-center text-white font-black text-xl shadow-lg shadow-blue-500/20">
          <i className="fas fa-plane-departure text-sm"></i>
        </div>
        <span className="text-2xl font-black text-slate-900 tracking-tighter">SkyBook</span>
      </div>

      <div className="px-6 mb-6 shrink-0">
         <div className="bg-slate-50 rounded-[2rem] p-4 flex items-center gap-4 border border-slate-100 shadow-sm">
            <img src="https://i.pravatar.cc/100?u=agency" className="w-12 h-12 rounded-[1.2rem] border-2 border-white shadow-md" alt="" />
            <div className="overflow-hidden">
               <p className="text-xs font-black text-slate-900 leading-none truncate">Global Travels</p>
               <p className="text-[9px] font-bold text-slate-400 mt-1 uppercase tracking-tighter">
                 {currentRole === UserRole.ADMIN ? 'Master' : currentRole === UserRole.AGENT ? 'Agent' : 'Member'}
               </p>
            </div>
         </div>
      </div>

      {/* Main scrollable nav area */}
      <nav className="flex-1 px-4 space-y-8 overflow-y-auto scrollbar-hide pb-8">
        {sections.map((section, idx) => {
          const visibleItems = section.items.filter(item => item.roles.includes(currentRole));
          if (visibleItems.length === 0) return null;

          return (
            <div key={idx} className="space-y-2">
              <p className="px-6 text-[10px] font-black text-slate-300 uppercase tracking-[0.2em] mb-3">{section.title}</p>
              <div className="space-y-1">
                {visibleItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center gap-4 px-6 py-3.5 rounded-2xl transition-all duration-200 group ${
                      activeTab === item.id 
                        ? 'bg-blue-50 text-blue-600 border border-blue-100 shadow-sm' 
                        : 'text-slate-500 hover:bg-slate-50 hover:text-slate-900'
                    }`}
                  >
                    <i className={`fas ${item.icon} w-5 text-center text-sm ${activeTab === item.id ? 'text-blue-600' : 'text-slate-300 group-hover:text-blue-600'}`}></i>
                    <span className="font-bold text-sm tracking-tight">{item.label}</span>
                    {activeTab === item.id && <div className="ml-auto w-1.5 h-1.5 bg-blue-600 rounded-full"></div>}
                  </button>
                ))}
              </div>
            </div>
          );
        })}
      </nav>

      {/* Dedicated Fixed Bottom Area for Log Out */}
      <div className="p-4 border-t border-slate-100 bg-white shrink-0">
        <button 
          onClick={(e) => {
            e.stopPropagation();
            onLogout();
          }}
          className="w-full flex items-center gap-4 px-6 py-4 rounded-2xl text-red-500 hover:bg-red-50 transition-all group font-black uppercase tracking-widest text-[11px] shadow-sm border border-transparent hover:border-red-100"
        >
          <i className="fas fa-sign-out-alt w-5 text-center text-sm group-hover:rotate-180 transition-transform duration-500"></i>
          <span>Terminal Log Out</span>
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;